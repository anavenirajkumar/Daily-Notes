﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;
using WebAPI.Core.Interfaces;
using WebAPI.Core.Specifications;
using WebAPI.DTO;
using WebAPI.Errors;
using WebAPI.Helpers;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        //private readonly IProductRepository _repo;
        public IProductRepository _repo { get; set; } // must public

        private readonly IGenericRepository<Product> _productRepo;
        private readonly IGenericRepository<ProductBrand> _productBrandRepo;
        private readonly IGenericRepository<ProductType> _productTypeRepo;
        private readonly IMapper _mapper;

        public ProductsController(IGenericRepository<Product> productRepo,
            IGenericRepository<ProductBrand> productBrandRepo,
            IGenericRepository<ProductType> productTypeRepo,
            IMapper mapper,
            IProductRepository repo
            )
        {
            _productRepo = productRepo;
            _productBrandRepo = productBrandRepo;
            _productTypeRepo = productTypeRepo;
            _mapper = mapper;
            _repo = repo;
        }

        // Brands
        [HttpPost("AddBrand")]
        public ProductBrand AddBrand(ProductBrand modal)
        {
            return _repo.AddBrand(modal);
        }
        [HttpGet("brand/{id}")]

        public IActionResult GetBrand(int id)
        {
            var item = _repo.GetBrand(id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }


        [HttpPut("UpdateBrand/{id}")]
        public ProductBrand PutBrand(ProductBrand modal)
        {
            var brand = _repo.UpdateBrand(modal);
            return brand;
        }

        [HttpDelete("DeleteBrand/{id}")]
        public ProductBrand DeleteBrand(int id)
        {
            var brand = _repo.DeleteBrand(id);
            return brand;

        }

        [HttpGet("brands")]
        public async Task<ActionResult<IReadOnlyList<ProductBrand>>> GetBrands()
        {
            return Ok(await _productBrandRepo.ListAllAsync());
        }


        // Types
        [HttpGet("types")]
        public async Task<ActionResult<IReadOnlyList<ProductBrand>>> GetTypes()
        {
            return Ok(await _productTypeRepo.ListAllAsync());
        }

        [HttpPost("AddType")]
        public ProductType AddType(ProductType modal)
        {
            return _repo.AddType(modal);
        }

        [HttpGet("type/{id}")]
        public IActionResult GetType(int id)
        {
            var item = _repo.GetType(id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }


        [HttpPut("UpdateType/{id}")]
        public ProductType PutType(ProductType modal)
        {
            var brand = _repo.UpdateType(modal);
            return brand;
        }

        [HttpDelete("DeleteType/{id}")]
        public ProductType DeleteType(int id)
        {
            var brand = _repo.DeleteType(id);
            return brand;
        }



        [HttpGet]
        //  public async Task<ActionResult<IReadOnlyList<ProductToReturnDto>>> GetProducts(string sort, int? brandId, int ? typeId)
        // sort for 'Products' Assending and Dessending -> https://localhost:44358/api/products?sort=priceAsc or priceDsc
        // Filter for 'Brands' -> https://localhost:44358/api/products?brandId=2
        // Filter for 'TypeId' -> https://localhost:44358/api/products?typeId=2&brandId=2
        // Filter using 'Brands' and 'TypeId' -> https://localhost:44358/api/products?typeId=2
        // Pagination -> https://localhost:44358/api/products?pageSize=3&pageIndex=1 or pageSize=6&pageIndex=2
        // Pagination -> https://localhost:44358/api/products?typeId=2&brandId=2&sort=priceDsc&pageIndex=1&pageSize=2
        // Search Functionality ->  https://localhost:44358/api/products?search=iphone&sort=priceDsc
        public async Task<ActionResult<Pagination<ProductToReturnDto>>> GetProducts([FromQuery] ProductSpecParams productParams)

        {
            /* var spec = new ProductsWithTypesAndBrandsSpecification();  // example 1
             var products = await _productRepo.ListAsync(spec);
             return Ok(products);*/

            /*            var spec = new ProductsWithTypesAndBrandsSpecification(); // example 2
                        var products = await _productRepo.ListAsync(spec); 
                        return products.Select(product => new ProductToReturnDto // using DTO Return Product Responce Format
                        {
                            Id = product.Id,
                            Name = product.Name,
                            Description = product.Description,
                            PictureUrl = product.PictureUrl,
                            Price = product.Price,
                            ProductBrand = product.ProductBrand.Name,
                            ProductType = product.ProductType.Name
                        }).ToList();*/

            // var spec = new ProductsWithTypesAndBrandsSpecification(sort, brandId, typeId); 
            var spec = new ProductsWithTypesAndBrandsSpecification(productParams); // example 3 using AutoMapper
            var countSpec = new ProductsWithFiltersForCountSpecification(productParams); // for Pagination
            var totalItems = await _productRepo.CountAsync(countSpec);
            var products = await _productRepo.ListAsync(spec);
            var data = _mapper.Map<IReadOnlyList<ProductToReturnDto>>(products);

            return Ok(new Pagination<ProductToReturnDto>(productParams.PageIndex,
                productParams.PageSize, totalItems, data));
        }

        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)] // responce code
        [ProducesResponseType(typeof(ApiResponse), StatusCodes.Status404NotFound)] // responce code notfound

        public async Task<ActionResult<ProductToReturnDto>> GetProduct(int id) //<Product> example 1
        {
            /* var spec = new ProductsWithTypesAndBrandsSpecification(id); // example 1
             return await _productRepo.GetEntityWithSpec(spec);*/

            /*  var spec = new ProductsWithTypesAndBrandsSpecification(id); // example 2 with DTOS
              var product = await _productRepo.GetEntityWithSpec(spec);
              return new ProductToReturnDto // using DTO Return Product Responce Format
              {
                  Id = product.Id,
                  Name = product.Name,
                  Description = product.Description,
                  PictureUrl = product.PictureUrl,
                  Price = product.Price,
                  ProductBrand = product.ProductBrand.Name,
                  ProductType = product.ProductType.Name
              };*/

            var spec = new ProductsWithTypesAndBrandsSpecification(id); // example 3 AutoMapper
            var product = await _productRepo.GetEntityWithSpec(spec);
            if (product == null) return NotFound(new ApiResponse(404)); // for Error Handling
            return _mapper.Map<Product, ProductToReturnDto>(product);

        }


        [HttpPost("AddProduct")]
        public Product AddProduct(Product modal)
        {
            return _repo.AddProduct(modal);
        }

        [HttpPut("UpdateProduct/{id}")]
        public Product UpdateProduct(Product modal)
        {
            var brand = _repo.UpdateProduct(modal);
            return brand;
        }

        [HttpDelete("DeleteProduct/{id}")]
        public Product DeleteProduct(int id)
        {
            var product = _repo.DeleteProduct(id);
            return product;

        }


    }
}
