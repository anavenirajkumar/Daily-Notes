﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Core.Entities
{
    public class ProductType : BaseEntity
    {
        public string Name { get; set; }
    }
}
