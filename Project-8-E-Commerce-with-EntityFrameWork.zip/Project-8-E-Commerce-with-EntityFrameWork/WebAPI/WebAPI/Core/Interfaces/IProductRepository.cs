﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;

namespace WebAPI.Core.Interfaces
{
    public interface IProductRepository
    {
        // brands
        ProductBrand AddBrand(ProductBrand request);
        ProductBrand GetBrand(int id);
        ProductBrand UpdateBrand(ProductBrand request);
        ProductBrand DeleteBrand(int brandId);

        // types
        ProductType AddType(ProductType request);
        ProductType GetType(int id);
        ProductType UpdateType(ProductType request);
        ProductType DeleteType(int brandId);

        // Products
        Product AddProduct(Product request);
        Product UpdateProduct(Product request);
        Product DeleteProduct(int productId);


        Task<Product> GetProductByIdAsync(int id);
        Task<IReadOnlyList<Product>> GetProductsAsync();
        Task<IReadOnlyList<ProductBrand>> GetProductBrandsAsync();
        Task<IReadOnlyList<ProductType>> GetProductTypesAsync();
    }
}
