﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;
using WebAPI.DTO;

namespace WebAPI.Helpers
{
    public class MappingProfiles : Profile
    {
        public MappingProfiles()
        {
            CreateMap<Product, ProductToReturnDto>()
             .ForMember(d => d.ProductBrand, o => o.MapFrom(s => s.ProductBrand.Name)) // for show with Product Brand in 'Responce' using AutoMapper
             .ForMember(d => d.ProductType, o => o.MapFrom(s => s.ProductType.Name)); // for show with Product Type in 'Responce' using AutoMapper
             /*.ForMember(d => d.PictureUrl, o => o.MapFrom<ProductUrlResolver>()); // for Product Images => https://localhost:44358/images/products/apple.jpg
            CreateMap<Address, AddressDto>().ReverseMap();
            CreateMap<CustomerBasketDto, CustomerBasket>();
            CreateMap<BasketItemDto, BasketItem>();*/
        }
    }
}
