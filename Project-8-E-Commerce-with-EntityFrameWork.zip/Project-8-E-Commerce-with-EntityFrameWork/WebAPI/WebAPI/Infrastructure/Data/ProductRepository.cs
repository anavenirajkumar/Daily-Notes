﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;
using WebAPI.Core.Interfaces;

namespace WebAPI.Infrastructure.Data
{
    public class ProductRepository : IProductRepository
    {
        private readonly StoreContext _context;
        public ProductRepository(StoreContext context)
        {
            _context = context;
        }

        // Brands
        public ProductBrand AddBrand(ProductBrand request)
        {
            var brand = new ProductBrand()
            {
                Id = request.Id,
                Name = request.Name
            };
            _context.ProductBrands.Add(brand);
            _context.SaveChanges();
            return brand;
        }
        public ProductBrand GetBrand(int id)
        {
            var query = from u in _context.ProductBrands
                        where u.Id == id
                        select u;
            var user = query.FirstOrDefault();
            var model = new ProductBrand()
            {
                Id = user.Id,
                Name = user.Name
            };
            return model;
        }
        public ProductBrand UpdateBrand(ProductBrand request)
        {
            ProductBrand brandData = _context.ProductBrands.Where(u => u.Id == request.Id).SingleOrDefault();
            brandData.Name = request.Name;
            _context.SaveChanges();
            return brandData;
        }

        public ProductBrand DeleteBrand(int brandId)
        {
            ProductBrand brand = _context.ProductBrands.Where(u => u.Id == brandId).SingleOrDefault();
            _context.ProductBrands.Remove(brand);
            _context.SaveChanges();
            return brand;
        }



        // Types
        public ProductType AddType(ProductType request)
        {
            var type = new ProductType()
            {
                Id = request.Id,
                Name = request.Name
            };
            _context.ProductTypes.Add(type);
            _context.SaveChanges();
            return type;
        }
        public ProductType GetType(int id)
        {
            var query = from u in _context.ProductTypes
                        where u.Id == id
                        select u;
            var user = query.FirstOrDefault();
            var model = new ProductType()
            {
                Id = user.Id,
                Name = user.Name
            };
            return model;
        }
        public ProductType UpdateType(ProductType request)
        {
            ProductType typeData = _context.ProductTypes.Where(u => u.Id == request.Id).SingleOrDefault();
            typeData.Name = request.Name;
            _context.SaveChanges();
            return typeData;
        }

        public ProductType DeleteType(int typeId)
        {
            ProductType type = _context.ProductTypes.Where(u => u.Id == typeId).SingleOrDefault();
            _context.ProductTypes.Remove(type);
            _context.SaveChanges();
            return type;
        }




        public async Task<IReadOnlyList<ProductBrand>> GetProductBrandsAsync()
        {
            return await _context.ProductBrands.ToListAsync();
        }

        public async Task<Product> GetProductByIdAsync(int id)
        {
            return await _context.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductBrand)
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IReadOnlyList<Product>> GetProductsAsync()
        {
            return await _context.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductBrand)
                .ToListAsync();
        }

        public async Task<IReadOnlyList<ProductType>> GetProductTypesAsync()
        {
            return await _context.ProductTypes.ToListAsync();
        }


        public Product AddProduct(Product request)
        {
            var brand = new Product()
            {
                Id = request.Id,
                Name = request.Name,
                Description = request.Description,
                Price = request.Price,
                PictureUrl = request.PictureUrl,
                ProductType = request.ProductType,
                ProductBrand = request.ProductBrand,
            };
            _context.Products.Add(brand);
            _context.SaveChanges();
            return brand;
        }


        public Product UpdateProduct(Product request)
        {
            Product product = _context.Products.Where(u => u.Id == request.Id).SingleOrDefault();
            product.Name = request.Name;
            product.Description = request.Description;
            product.Price = request.Price;
            product.PictureUrl = request.PictureUrl;
            product.ProductType = request.ProductType;
            product.ProductBrand = request.ProductBrand;
            _context.SaveChanges();
            return product;
        }


        public Product DeleteProduct(int productId)
        {
            Product product = _context.Products.Where(u => u.Id == productId).SingleOrDefault();
            _context.Products.Remove(product);
            _context.SaveChanges();
            return product;
        }
    }
}
