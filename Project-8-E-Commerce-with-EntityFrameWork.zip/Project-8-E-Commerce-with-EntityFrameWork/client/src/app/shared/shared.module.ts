import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { PagingHeaderComponent } from './components/paging-header/paging-header.component';
import { PagerComponent } from './components/pager/pager.component'; // step 1 Pagination
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrderTotalsComponent } from './components/order-totals/order-totals.component';
import { BasketSummaryComponent } from './components/basket-summary/basket-summary.component';
import { RouterModule } from '@angular/router';

// pagination documentation url -> https://valor-software.com/ngx-bootstrap/#/components/pagination?tab=api

@NgModule({
  declarations: [
    PagingHeaderComponent,
    PagerComponent,
    OrderTotalsComponent,
    BasketSummaryComponent
  ],
  imports: [
    CommonModule,
    PaginationModule.forRoot(), // step 2 Pagination
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports: [
    PaginationModule, // step 3 Pagination
    PagingHeaderComponent,
    PagerComponent,
    OrderTotalsComponent,
    BasketSummaryComponent
  ]
})
export class SharedModule { }
