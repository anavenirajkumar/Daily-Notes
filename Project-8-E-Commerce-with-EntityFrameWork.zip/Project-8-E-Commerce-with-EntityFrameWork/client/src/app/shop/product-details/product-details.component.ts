import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BasketService } from 'src/app/basket/services/basket.service';
import { IProduct } from 'src/app/shared/models/product';
import { ShopService } from '../services/shop.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {

  // example 1
  // product:any;
  // quantity = 1;

  // example 2
  public productId:any;
  public product:any;

  constructor(
    private shopService: ShopService, 
    private activatedRoute: ActivatedRoute,
    private basketService: BasketService
   ) {}

   public quantity = 1;

  ngOnInit(): void {
     // example 1
    // this.shopService.getProduct(this.activatedRoute.snapshot.paramMap.get('id')).subscribe((product:any) => {
    //   this.product = product;
    // }, error => {
    //   console.log(error);
    // })

    this.activatedRoute.paramMap.subscribe((id)=> {
      this.productId = id.get('id');
      console.log(this.productId);
    });
    this.shopService.getProduct(this.productId).subscribe((data)=> {
      this.product = data;
      console.log(this.product);
    })

  }

  addItemToBasket() {
    this.basketService.addItemToBasket(this.product, this.quantity);
  }

  incrementQuantity() {
    this.quantity++;
  }

  decrementQuantity() {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }
}
