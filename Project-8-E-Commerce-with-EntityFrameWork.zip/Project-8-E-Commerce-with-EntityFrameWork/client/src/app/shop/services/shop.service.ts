import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { IPagination } from 'src/app/shared/models/pagination';
import { IBrand } from 'src/app/shared/models/brand';
import { IType } from 'src/app/shared/models/productType';
import { map, of } from 'rxjs';
import { ShopParams } from 'src/app/shared/models/shopParams';
import { IProduct } from 'src/app/shared/models/product';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ShopService {

  baseUrl = environment.apiUrl;

 // productCache = new Map();

  constructor(private http : HttpClient) { }

  // getProducts(brandId?: number, typeId?:number, sort?:string){ example 1

  getProducts(shopParams : ShopParams){ 

    let params = new HttpParams();

    if(shopParams.brandId !== 0){ // brandId
      params = params.append('brandId', shopParams.brandId.toString()); // https://localhost:44358/api/products?brandId=1
    }

    if(shopParams.typeId !== 0){
      params = params.append('typeId', shopParams.typeId.toString());
    }

    // if(shopParams.sort){
    //   params = params.append('sort', shopParams.sort);
    // }

    if(shopParams.search){
      params = params.append('search', shopParams.search);
    }
    params = params.append('sort', shopParams.sort);
    params = params.append('pageIndex', shopParams.pageNumber.toString());
    params = params.append('pageIndex', shopParams.pageSize.toString());

    return this.http.get<IPagination>(this.baseUrl + 'products', {observe: 'response', params})  // response
    .pipe(
      map(response => {
        return response.body;
      })
    );
  }

  getBrands(){
   return this.http.get<IBrand>(this.baseUrl + 'products/brands');
  }

  getTypes(){
   return this.http.get<IType>(this.baseUrl + 'products/types');
  }

  // example 1
  // getProduct(id: number | any) {
  //   let product: IProduct | any;
  //   this.productCache.forEach((products: IProduct[] | any) => {
  //     console.log(product);
  //     product = products.find((p:any) => p.id === id);
  //   })

  //   if (product) {
  //     return of(product);
  //   }

  //   return this.http.get<IProduct>(this.baseUrl + 'products/' + id);
  // }


  // example 2
  getProduct(getId:any){
    return this.http.get<IProduct>(this.baseUrl + 'products/' + getId)
  }
  
}
