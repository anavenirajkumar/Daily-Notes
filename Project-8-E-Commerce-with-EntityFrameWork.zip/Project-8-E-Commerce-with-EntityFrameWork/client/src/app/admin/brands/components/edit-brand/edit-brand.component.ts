import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-brand',
  templateUrl: './edit-brand.component.html',
  styleUrls: ['./edit-brand.component.scss']
})
export class EditBrandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
