import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-brand',
  templateUrl: './add-brand.component.html',
  styleUrls: ['./add-brand.component.scss']
})
export class AddBrandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
