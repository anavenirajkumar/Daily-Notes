import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddBrandComponent } from './brands/components/add-brand/add-brand.component';
import { BrandsComponent } from './brands/brands.component';
import { EditBrandComponent } from './brands/components/edit-brand/edit-brand.component';
import { AdminRoutingModule } from './admin-routing.module';



@NgModule({
  declarations: [
    AddBrandComponent,
    BrandsComponent,
    EditBrandComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule // adding lazy loading routing
  ]
})
export class AdminModule { }
