import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BrandsComponent } from './brands/brands.component';

const routes: Routes = [
  {path : '', component : BrandsComponent}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes) // adding lazy loading routing
  ],
  exports : [RouterModule] // adding lazy loading routing
})
export class AdminRoutingModule { }
