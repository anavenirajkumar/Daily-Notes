import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentsComponent } from './departments/departments.component';
import { EmployeesComponent } from './employees/employees.component';
import { DepartmentComponent } from './inline-table/department/department.component';
import { EmployeeComponent } from './inline-table/employee/employee.component';
import { DeptComponent } from './paramMap-Edit/dept/dept.component';
import { IdComponent } from './paramMap-Edit/dept/id/id.component';
import { EmpIdComponent } from './paramMap-Edit/emp/emp-id/emp-id.component';
import { EmpComponent } from './paramMap-Edit/emp/emp.component';

const routes: Routes = [
  {path : 'employees', component : EmployeesComponent},
  {path : 'departments', component : DepartmentsComponent},
  {path : 'departments-inline', component : DepartmentComponent},
  {path : 'employees-inline', component : EmployeeComponent},
  {path : 'dept', component : DeptComponent},
  {path : 'dept/:id', component : IdComponent},
  {path : 'emp', component : EmpComponent},
  {path : 'emp/:id', component : EmpIdComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
