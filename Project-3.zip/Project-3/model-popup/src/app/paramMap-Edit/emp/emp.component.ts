import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-emp',
  templateUrl: './emp.component.html',
  styleUrls: ['./emp.component.css']
})
export class EmpComponent implements OnInit {

public employees:any[] = [];

  constructor(private empService:EmployeeService) { }

  ngOnInit(){
    this.getAllEmployees();
  }

  getAllEmployees(){
    this.empService.getEmpList().subscribe((data) => {
      this.employees = data;
      console.log(this.employees);
    })
  }

}
