import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-emp-id',
  templateUrl: './emp-id.component.html',
  styleUrls: ['./emp-id.component.css']
})
export class EmpIdComponent implements OnInit {

  public employeId:any;

  public employee:any = {
    EmployeeId : '',
    EmployeeName : '',
    Department : '',
    DateOfJoining : '',
    PhotoFileName : '',
    department: {
      DepartmentId: '',
      DepartmentName: ''
    },
  }

  public departments:any;

  constructor(private empId:ActivatedRoute,
              private empService:EmployeeService,
              private router:Router
             ) { }

  ngOnInit(){
    this.empId.paramMap.subscribe((id)=> {
      this.employeId = id.get('id');
      console.log(this.employeId);
      if(this.employeId){
        this.empService.getEmployee(this.employeId).subscribe((data) => {
           this.employee = data[0];
           //this.employee.DateOfJoining = new Date().toISOString().substring(0, 10);
           console.log(this.employee);
        })
      }
      this.getAllDepartments();
    })
  }

  getAllDepartments(){
    this.empService.getDepList().subscribe((data)=>{
      this.departments = data;
      console.log(this.departments);
    })
  }

   
   

  

  updateEmployee(){
    console.log(this.employee);
    if(this.employeId){
      this.empService.updateEmployee(this.employee).subscribe((data)=> {
        console.log(data);
         this.router.navigate(['/emp']);
      })
    }
  }

    // selectProductImage
    public selectProductImage(event:any){
      let image = event.target.files[0];
      //console.log(image);
      let imageFile:FormData = new FormData();
      imageFile.append('uploadImage', image, image.name);
      this.empService.UploadPhoto(imageFile).subscribe((data) => {
        this.employee.PhotoFileName = data.toString();
        //console.log(this.employee.PhotoFileName);
        this.employee.PhotoFileName = this.empService.PhotoUrl+this.employee.PhotoFileName;
        //console.log(image,this.employee.PhotoFileName);
        //console.log(this.employee.PhotoFileName);
        this.employee.PhotoFileName = this.employee.PhotoFileName;
         //console.log(this.employee.PhotoFileName);
 
      })
      }
    }
