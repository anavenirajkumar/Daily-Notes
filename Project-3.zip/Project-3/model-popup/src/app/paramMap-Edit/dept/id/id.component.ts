import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-id',
  templateUrl: './id.component.html',
  styleUrls: ['./id.component.css']
})
export class IdComponent implements OnInit {

  categoryId : any;

  public category:any = {
    DepartmentId : '',
    DepartmentName : ''
  }
  constructor(private router:ActivatedRoute,
              private depService:EmployeeService,
              private route:Router) { }

  ngOnInit(): void {
    this.router.paramMap.subscribe((id)=> {
      this.categoryId = id.get('id');
      console.log(this.categoryId);
      if(this.categoryId){
         this.depService.getDepartment(this.categoryId).subscribe((data) => {
           this.category = data[0]; // Data Coming from Array of Object i'm taking index object
           console.log(this.category.DepartmentId);
           console.log(this.category.DepartmentName);

         })
      }
    })
  }

  updateCategory(){
    console.log(this.category);
    this.depService.updateDepartment(this.category).subscribe((data) => {
      console.log(data);
      this.route.navigate(['/dept']);
    })
  }

}
