import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-dept',
  templateUrl: './dept.component.html',
  styleUrls: ['./dept.component.css']
})
export class DeptComponent implements OnInit {

  public departments:any[] = [];
  
  constructor(private depService:EmployeeService) { }

  ngOnInit(): void {
     this.getAllDepartments();
  }

  deleteDepartment(dep:any){
    this.depService.deleteDepartment(dep.DepartmentId).subscribe((data)=>{
      console.log(data);
      this.getAllDepartments();
    })
  }
  getAllDepartments(){
    this.depService.getDepList().subscribe((data)=>{
      this.departments = data;
    })
  }

}
