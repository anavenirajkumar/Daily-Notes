import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { IDepartment } from '../interfaces/IDepartment';
import { IEmployee } from '../interfaces/IEmployee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-departments',
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent implements OnInit {

  public departments:any[] = [];
  public exform : any;
  showAdd! :boolean; 
  showUpdate! : boolean;

  public title:any;

  public categoryObj:IDepartment = new IDepartment()

  constructor(private service: EmployeeService) { }

  ngOnInit(): void {
    this.getDepartments();
    this.exform = new FormGroup({
      DepartmentName : new FormControl('',[Validators.required])
    })
  }

  public DepartmentName(){
    return this.exform.get('DepartmentName')
  }

  public getDepartments(){
    this.service.getDepList().subscribe((responce)=>{
      this.departments = responce;
      console.log(this.departments);
    })
  }

  public addCategory(){
    this.exform.markAllAsTouched();
    if(this.exform.valid){
      this.categoryObj.DepartmentName = this.exform.value.DepartmentName; 
       this.service.addDepartment(this.categoryObj).subscribe((res)=>{
        alert('Department Creation Sucessfully Submited');
        let ref = document.getElementById('cancel');
        ref?.click();
        this.exform.reset();
        this.getDepartments();
      },err=>{
       alert('Something Went Wrong')
      })
    }
  }

 

  deleteCategory(emp:any){
    this.service.deleteDepartment(emp.DepartmentId).subscribe(res=>{
      alert('Employee Deleted');
      this.getDepartments();
    })
 }

 public editCategory(emp:any){
   this.title = "Edit Category";
  this.showAdd = false;
  this.showUpdate = true;
  this.categoryObj.DepartmentId = emp.DepartmentId;
  this.exform.controls['DepartmentName'].setValue(emp.DepartmentName);
}


  public updateEmployee(){
    if(this.exform.valid){
      this.categoryObj.DepartmentName = this.exform.value.DepartmentName;
      this.service.updateDepartment(this.categoryObj).subscribe((res) => {
        alert('Updated Sucessfully');
        let ref = document.getElementById('cancel');
        ref?.click();
        this.exform.reset();
        this.getDepartments();
      })
    }
  }

  openPopup(){
    this.title = "Add Category";
    this.exform.reset();
    this.showAdd = true;
    this.showUpdate = false;

  }
}