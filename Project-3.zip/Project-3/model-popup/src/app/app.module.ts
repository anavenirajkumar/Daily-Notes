import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { DepartmentsComponent } from './departments/departments.component';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { DepartmentComponent } from './inline-table/department/department.component';
import { EmployeeComponent } from './inline-table/employee/employee.component';
import { DeptComponent } from './paramMap-Edit/dept/dept.component';
import { EmpComponent } from './paramMap-Edit/emp/emp.component';
import { IdComponent } from './paramMap-Edit/dept/id/id.component';
import { EmployeeService } from './services/employee.service';
import { EmpIdComponent } from './paramMap-Edit/emp/emp-id/emp-id.component';
@NgModule({
  declarations: [
    AppComponent,
    EmployeesComponent,
    DepartmentsComponent,
    DepartmentComponent,
    EmployeeComponent,
    DeptComponent,
    EmpComponent,
    IdComponent,
    EmpIdComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
