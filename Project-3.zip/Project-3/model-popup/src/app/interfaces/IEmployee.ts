export class IEmployee {
        EmployeeId: number = 0;
		EmployeeName: string = '';
		Department: string = '';
		DateOfJoining: string = '';
		PhotoFileName: string = '';
}

export class IImage{
	PhotoPath : string ='';
}