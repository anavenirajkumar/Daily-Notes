export class IDepartment {
        DepartmentId: number = 0;
		DepartmentName: string =''
}