import { Component, OnInit } from '@angular/core';
import { IEmployee, IImage } from 'src/app/interfaces/IEmployee';
import { EmployeeService } from 'src/app/services/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  public employees:any = [];
  public departments:any = [];
  public employee:IEmployee = new IEmployee(); // for Create Employee

  public PhotoFile:any; // for photo

  public employeeIndex:any;

  constructor(private empService:EmployeeService) { }
  ngOnInit(): void {
      this.getAllEmployees();
      this.getAllDepartments();

  }

  addEmployee(){
    // console.log(this.employee);
    if(this.employee.Department === '0' || this.employee.Department === '' && this.employee.EmployeeName === '' && this.employee.DateOfJoining === ''){
     return;
    } else {
      if(this.employee.Department.length > 0  && this.employee.EmployeeName !== '' && this.employee.DateOfJoining !== ''){
          console.log(this.employee);
          this.empService.addEmployee(this.employee).subscribe((responce) => {
            console.log(responce);
            this.employee.EmployeeName = '';
            this.employee.Department = '';
            this.employee.DateOfJoining = '';
            this.employee.PhotoFileName = '';
            this.PhotoFile = '';
            this.getAllEmployees();
          });
      }
    }
   
  }

  getAllEmployees(){
    this.empService.getEmpList().subscribe((responce)=> {
      this.employees = responce;
      console.log(this.employees);
    })
  }

  getAllDepartments(){
    this.empService.getDepList().subscribe((data) => {
      this.departments = data;
    })
  }

  uploadPhoto(event:any){
     let image = event.target.files[0];
     console.log(image);
     let imageFile:FormData = new FormData();
     imageFile.append('uploadImage', image, image.name);
     this.empService.UploadPhoto(imageFile).subscribe((data) => {
       this.PhotoFile = data.toString();
       this.PhotoFile = this.empService.PhotoUrl+this.PhotoFile;
       console.log(image,this.PhotoFile);
       console.log(this.PhotoFile);
       this.employee.PhotoFileName = this.PhotoFile;
       console.log(this.employee.PhotoFileName);

     })
  }

  editEmployee(emp:any){
    console.log(emp);
     this.employeeIndex = emp.EmployeeId;
  }

  updateEmployee(employee:any){
    console.log(employee);
    this.employee.EmployeeId = employee.EmployeeId;
    this.employee.EmployeeName = employee.EmployeeName;
    this.employee.Department = employee.Department;
    this.employee.DateOfJoining = employee.DateOfJoining;
    this.employee.PhotoFileName = this.PhotoFile;
    //this.PhotoFile = this.PhotoFile;
    this.empService.updateEmployee(this.employee).subscribe((data) => {
      console.log(data);
      console.log(this.employee);
      this.employeeIndex = null;

      this.employee.EmployeeName = '';
      this.employee.DateOfJoining = '';
      this.employee.PhotoFileName = '';
      this.PhotoFile = '';
      
      this.getAllDepartments();
      this.getAllEmployees();
    })
  }

  calcelEmployee(){
    this.employeeIndex = null;
  }

  deleteEmployee(empId:any){
    this.empService.deleteEmployee(empId.EmployeeId).subscribe((data) => {
       console.log(data);
       this.getAllEmployees();
    })
  }
}
