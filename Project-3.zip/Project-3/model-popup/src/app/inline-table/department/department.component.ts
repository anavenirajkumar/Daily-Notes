import { Component, OnInit } from '@angular/core';
import { EmployeeService } from 'src/app/services/employee.service';
import { IDepartment} from '../../interfaces/IDepartment';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {
 
  public departments:any[]=[]
  public enableEditIndex:any;

  public category:IDepartment = new IDepartment(); // for Create

  public objCategory:IDepartment = new IDepartment()

  constructor(private depService:EmployeeService) { }

  ngOnInit(): void {
      this.getAllDepartments();
  }
 
  getAllDepartments(){
    this.depService.getDepList().subscribe((data)=>{
      this.departments = data;
    })
  }

  addCategory(){
     if(this.category.DepartmentName.length > 3){
      console.log(this.category);
      this.depService.addDepartment(this.category).subscribe((data)=>{
        console.log(data);
        this.category.DepartmentName = '';
        this.getAllDepartments();
      })
     }
  }
  
  editEmployee(emp:any) {
    console.log(emp);
    this.enableEditIndex = emp.DepartmentId;
    

  }

  updateEmployee(emp:any) {
    //console.log(emp);
    this.enableEditIndex = null;
    this.objCategory.DepartmentId = emp.DepartmentId;
    this.objCategory.DepartmentName = emp.DepartmentName;
    console.log(this.objCategory);
    this.depService.updateDepartment(this.objCategory).subscribe((data)=> {
       console.log(data);
       this.getAllDepartments();
    })
  }

  calcelEmployee() {
    this.enableEditIndex = null;
  }

  deleteEmployee(emp:any){
    this.depService.deleteDepartment(emp.DepartmentId).subscribe((data)=> {
      console.log(data);
      this.getAllDepartments();
    })
  }

}
