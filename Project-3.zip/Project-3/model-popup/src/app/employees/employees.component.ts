import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { IEmployee, IImage } from '../interfaces/IEmployee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  public exform : FormGroup | any;
  employees:any[] =[]; 

  departments:any[] = [];

  public objEmployee:IEmployee = new IEmployee();
  //public objImage:IImage = new IImage();

  public photoFilePath:any;

  public showAddEmployee: boolean = false;
  public showUpdateEmployee: boolean = false;

  public title:any;
  

  constructor(private empService: EmployeeService) { }

  ngOnInit() {
    this.getAllEmployees();
    this.getAllDepartments()
    this.exform = new FormGroup({
      EmployeeName : new FormControl('',[Validators.required]),
      Department : new FormControl('',[Validators.required]),
      DateOfJoining : new FormControl(''),
      PhotoFileName : new FormControl('',[Validators.required,Validators.minLength(10)]),
      photoFilePath : new FormControl(''),
    })
   
  }

  public getAllEmployees(){
    this.empService.getEmpList().subscribe((responce)=>{
      this.employees = responce;
      console.log(this.employees);
    })
  }

  getAllDepartments(){
    this.empService.getDepList().subscribe((responce)=> {
      this.departments = responce;
      console.log(this.departments);
    })
  }


  public EmployeeName(){
    return this.exform.get('EmployeeName')
  }
  public Department(){
    return this.exform.get('Department')
  }
  public DateOfJoining(){
    return this.exform.get('DateOfJoining')
  }
  public PhotoFileName(){
    return this.exform.get('PhotoFileName')
  }


  openPopup(){
    this.title = "Add Employee";
    this.exform.reset();
    this.photoFilePath = '';
     this.getAllDepartments();
     this.showAddEmployee = true;
     this.showUpdateEmployee = false;

  }

  addEmployee(){
    //console.log(this.exform);
    this.objEmployee.EmployeeName = this.exform.value.EmployeeName;
    this.objEmployee.Department = this.exform.value.Department;
    this.objEmployee.DateOfJoining = this.exform.value.DateOfJoining;
    this.objEmployee.PhotoFileName = this.photoFilePath;
    this.empService.addEmployee(this.objEmployee).subscribe((responce)=>{
      alert('Employee Creation Sucessfully Submited');
      let ref = document.getElementById('cancel');
      ref?.click();
      this.exform.reset();
      this.getAllEmployees();
    },err=>{
     alert('Something Went Wrong')
    })
  }

  uploadPhoto(e:any){
    let file = e.target.files[0];
    let fileData:FormData = new FormData();
    fileData.append('uploaded',file, file.name);
    this.empService.UploadPhoto(fileData).subscribe((data:any)=>{
      this.photoFilePath = data.toString();
      this.photoFilePath = this.empService.PhotoUrl+this.photoFilePath;
      console.log(file);
    })
  }

  editEmployee(emp:any){
    this.title = "Edit Employee";
    this.showUpdateEmployee = true;
    this.showAddEmployee = false;
    //console.log(emp);
    this.objEmployee.EmployeeId = emp.EmployeeId;
    this.objEmployee.EmployeeName = emp.EmployeeName;
    this.objEmployee.DateOfJoining = emp.DateOfJoining;
    this.objEmployee.Department = emp.Department;
    this.objEmployee.PhotoFileName = emp.PhotoFileName;
    this.photoFilePath = emp.PhotoFileName;
    //this.objImage.PhotoPath = emp.PhotoFileName;
    this.exform.controls['EmployeeName'].setValue(emp.EmployeeName);
    this.exform.controls['DateOfJoining'].setValue(emp.DateOfJoining);
    this.exform.controls['Department'].setValue(emp.Department);
    this.exform.controls['PhotoFileName'].setValue(emp.PhotoFileName);
    console.log(emp);

  }

  updateEmployee(){
        console.log(this.exform);
        this.objEmployee.EmployeeId = this.objEmployee.EmployeeId;
        this.objEmployee.EmployeeName = this.exform.value.EmployeeName;
        this.objEmployee.DateOfJoining = this.exform.value.DateOfJoining;
        this.objEmployee.Department = this.exform.value.Department;
        this.objEmployee.PhotoFileName = this.photoFilePath;
        console.log(this.photoFilePath);
        console.log(this.objEmployee);
        this.empService.updateEmployee(this.objEmployee).subscribe((data)=>{
        console.log(this.objEmployee);
        this.getAllEmployees();
        let ref = document.getElementById('cancel');
        ref?.click();
        this.exform.reset();
      },err=>{
       alert('Something Went Wrong')
    })
  }
  deleteEmployee(emp:any){
    this.empService.deleteEmployee(emp.EmployeeId).subscribe(data=>{
      alert(data.toString());
      this.getAllEmployees();
    })
  }
  }




