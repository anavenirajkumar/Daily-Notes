import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IDepartment } from '../interfaces/IDepartment';
import { IEmployee } from '../interfaces/IEmployee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  readonly APIUrl="http://localhost:44464/api"; // http://localhost:44464/ or 58830
  readonly PhotoUrl = "http://localhost:44464/Photos/"; // http://localhost:44464/ 58830
  
    constructor(private http:HttpClient) { }
  
    // Departments
    getDepList():Observable<IDepartment[]>{
      return this.http.get<IDepartment[]>(this.APIUrl+'/department');
    }
  
    addDepartment(val:IDepartment):Observable<IDepartment>{
      return this.http.post<IDepartment>(this.APIUrl+'/Department',val);
    }
  
    updateDepartment(val:IDepartment):Observable<IDepartment>{
      return this.http.put<IDepartment>(this.APIUrl+'/Department',val);
    }
  
    deleteDepartment(depId:any){
      return this.http.delete(this.APIUrl+'/Department/'+depId);
    }

    getDepartment(depId: string): Observable<any> {
      return this.http.get<any>(this.APIUrl + '/Department/' + depId);
    }
  
  
    // Employees
    getEmpList():Observable<IEmployee[]>{
      return this.http.get<IEmployee[]>(this.APIUrl+'/Employee');
    }

    getEmployee(empId:any):Observable<any> {
      return this.http.get<any>(this.APIUrl +'/Employee/' + empId);
    }
  
    addEmployee(val:IEmployee):Observable<IEmployee>{
      return this.http.post<IEmployee>(this.APIUrl+'/Employee',val);
    }
  
    updateEmployee(val:IEmployee):Observable<IEmployee>{
      return this.http.put<IEmployee>(this.APIUrl+'/Employee',val);
    }
  
    deleteEmployee(val:any){
      return this.http.delete(this.APIUrl+'/Employee/'+val);
    }
  
  
    UploadPhoto(val:any){
      return this.http.post(this.APIUrl+'/Employee/SaveFile',val);
    }
  
    getAllDepartmentNames():Observable<any[]>{
      return this.http.get<any[]>(this.APIUrl+'/Employee/GetAllDepartmentNames');
    }
}
