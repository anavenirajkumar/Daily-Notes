﻿using Dapper;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Services
{
    public class UserService : IUser
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        public UserService(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);
        }

        // Register User
        public async Task<RegisterUserResponse> RegisterUser(RegisterUserRequest request)
        {


            RegisterUserResponse response = new RegisterUserResponse();
            response.IsSuccess = true;
            response.Message = "SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (request.Password != request.ConfirmPassword)
                {
                    response.IsSuccess = false;
                    response.Message = "Password Not Match";
                    return response;
                }

                // Check Register Email is Already Exist Query
                string Sql = @"SELECT Email  
                                    FROM registerUser
                                    WHERE Email=@Email";

                string alreadyEmail; //

                UserLoginResponse responseUser = new UserLoginResponse();

                using (SqlCommand sqlCommand = new SqlCommand(Sql, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            responseUser.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                            alreadyEmail = responseUser.Email; //
                            response.IsSuccess = false;
                            response.Message = "User Is Already Registered";

                        }
                        else
                        {
                            alreadyEmail = null;
                        }
                    }

                }


                if (alreadyEmail == null) // if null Create New Register User
                {
                    request.Password = BCrypt.Net.BCrypt.HashPassword(request.Password);

                    string SqlQuery = @"INSERT INTO  registerUser 
                                    (UserName, PassWord, Role, Email) Values 
                                    (@UserName, @PassWord, @Role, @Email);";

                    using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                    {
                        sqlCommand.CommandType = System.Data.CommandType.Text;
                        sqlCommand.CommandTimeout = 180;
                        sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                        sqlCommand.Parameters.AddWithValue("@PassWord", request.Password);
                        sqlCommand.Parameters.AddWithValue("@Role", request.Role);
                        sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                        int Status = await sqlCommand.ExecuteNonQueryAsync();
                        if (Status <= 0)
                        {
                            response.IsSuccess = false;
                            response.Message = "Register Query Not Executed";
                            return response;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Login User
        public async Task<UserLoginResponse> UserLogin(UserLoginRequest request)
        {
            UserLoginResponse response = new UserLoginResponse();
            response.IsSuccess = true;
            response.Message = "Login SuccessFul";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT UserId, UserName, Role, Village, Mandal, District, Email, Password
                                    FROM registerUser
                                    WHERE Email=@Email";

                // bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, SqlQuery);
                /* if (isValidPassword) { 

                 }*/

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                    sqlCommand.Parameters.AddWithValue("@PassWord", request.Password);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = "Login Successful";
                            /*                            response.data = new UserLoginInformation();
                            */
                            response.UserID = dataReader["UserId"] != DBNull.Value ? Convert.ToString(dataReader["UserId"]) : string.Empty;
                            response.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                            response.Role = dataReader["Role"] != DBNull.Value ? Convert.ToString(dataReader["Role"]) : string.Empty;
                            response.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                            response.Password = dataReader["Password"] != DBNull.Value ? Convert.ToString(dataReader["Password"]) : string.Empty;
                            response.Village = dataReader["Village"] != DBNull.Value ? Convert.ToString(dataReader["Village"]) : string.Empty;
                            response.Mandal = dataReader["Mandal"] != DBNull.Value ? Convert.ToString(dataReader["Mandal"]) : string.Empty;
                            response.District = dataReader["District"] != DBNull.Value ? Convert.ToString(dataReader["District"]) : string.Empty;
                            bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, response.Password);
                            if (isValidPassword)
                            {
                                response.Token = GenerateJwt(response.UserID, response.UserName, response.Role);
                                return response;
                            }
                            else
                            {
                                response = null;
                            }
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.Message = "Login Unsuccessful";
                            return response;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Update User Address
        public async Task<UserAddressResponce> UserDetails(UserLoginResponse user)
        {
            var UserID = Int16.Parse(user.UserID);
            string UserName = user.UserName;

            UserAddressResponce response = new UserAddressResponce();
            //response.IsSuccess = true;
            response.Message = "Address Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (UserID == null)
                {
                    return null;
                }

                /* string SqlQuery = @" SELECT UserId from registerUser WHERE UserId=UserId AND INSERT INTO registerUser
                                     (Village, Mandal, District) Values 
                                     (@Village, @Mandal, @District)";*/

                string SqlQuery = @"UPDATE registerUser SET Village = @Village, Mandal = @Mandal, District = @District WHERE UserId = @UserID";



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserId", UserID);
                    sqlCommand.Parameters.AddWithValue("@Village", user.Village);
                    sqlCommand.Parameters.AddWithValue("@Mandal", user.Mandal);
                    sqlCommand.Parameters.AddWithValue("@District", user.District);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.IsSuccess = false;
                        response.Message = "Address Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                //response. = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;

        }

        // Upload Users
        public async Task<AddInformationResponse> AddInformation(AddInformationRequest request)
        {
            AddInformationResponse response = new AddInformationResponse();
            ///response.IsSuccess = true;
            response.Message = "User Created SuccessFul";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                // Married, DesignationId, uploadedDate, updatedDate
                string SqlQuery = @"INSERT INTO userInformation 
                                    (UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate) Values
                                    (@UserName, @EmailID, @MobileNumber, @Salary, @Gender, @Married, @DesignationId, @uploadedDate, @updatedDate)";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    //UserName, EmailID, MobileNumber, Salary, Gender
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                    sqlCommand.Parameters.AddWithValue("@EmailID", request.EmailID);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", request.MobileNumber);
                    sqlCommand.Parameters.AddWithValue("@Salary", request.Salary);
                    sqlCommand.Parameters.AddWithValue("@Gender", request.Gender);
                    sqlCommand.Parameters.AddWithValue("@Married", request.Marrried);
                    sqlCommand.Parameters.AddWithValue("@DesignationId", request.DesignationId);
                    sqlCommand.Parameters.AddWithValue("@uploadedDate", request.uploadedDate);
                    sqlCommand.Parameters.AddWithValue("@updatedDate", request.updatedDate);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.IsSuccess = false;
                        response.Message = "AddInformation Query Not Executed";
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Get All Users
        public async Task<GetInformationResponse> GetInformation()
        {
            GetInformationResponse response = new GetInformationResponse();
            response.IsSuccess = true;
            response.Message = "SuccessFul";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM userInformation";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.getInformation = new List<GetInformation>();

                            while (await dataReader.ReadAsync())
                            {
                                GetInformation data = new GetInformation();
                                //Married, DesignationId, uploadedDate, updatedDate
                                data.UserId =  Convert.ToInt32(dataReader["UserId"]);
                                data.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                                data.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                                data.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                data.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                                data.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                data.Marrried = dataReader["Married"] != DBNull.Value ? Convert.ToBoolean(dataReader["Married"]) : false;
                                data.DesignationId =  Convert.ToInt32(dataReader["DesignationId"]);
                                data.uploadedDate = dataReader["uploadedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["uploadedDate"]).ToString("dd/MM/yyyy") : null;
                                data.updatedDate = dataReader["updatedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["updatedDate"]).ToString("hh:mm tt") : null;
                                //data.IsActive = dataReader["IsActive"] != DBNull.Value ? Convert.ToBoolean(dataReader["IsActive"]) : false;

                                response.getInformation.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // GET By User ID
        public async Task<GetInformation> GetUserInfo(int id)
        {
            GetInformation response = new GetInformation();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT UserId, UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate FROM userInformation WHERE UserId = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            //response.Message = "Get Brand Successful";
                            response.UserId = Convert.ToInt32(dataReader["UserId"]);
                            response.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                            response.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                            response.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                            response.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                            response.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                            response.Marrried = dataReader["Married"] != DBNull.Value ? Convert.ToBoolean(dataReader["Married"]) : false;
                            response.DesignationId =  Convert.ToInt32(dataReader["DesignationId"]);
                            response.uploadedDate = dataReader["uploadedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["uploadedDate"]).ToString("dd/MM/yyyy") : null;
                            response.updatedDate = dataReader["updatedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["updatedDate"]).ToString("hh:mm tt") : null;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Update User Infomation
        public async Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation request)
        {
            var userId = request.UserId;

            UpdateUserInformation response = new UpdateUserInformation();
            //response.Message = "ProductBrand Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (userId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE userInformation SET UserName = @UserName, EmailID = @EmailID, MobileNumber = @MobileNumber, Salary = @Salary, Gender = @Gender, Married= @Married, DesignationId = @DesignationId, uploadedDate = @uploadedDate, updatedDate = @updatedDate WHERE UserId = " + userId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserId", userId);
                    sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                    sqlCommand.Parameters.AddWithValue("@EmailID", request.EmailID);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", request.MobileNumber);
                    sqlCommand.Parameters.AddWithValue("@Salary", request.Salary);
                    sqlCommand.Parameters.AddWithValue("@Gender", request.Gender);
                    sqlCommand.Parameters.AddWithValue("@Married", request.Married);
                    sqlCommand.Parameters.AddWithValue("@DesignationId", request.DesignationId);
                    sqlCommand.Parameters.AddWithValue("@uploadedDate", request.uploadedDate); // DateTime.Now.ToString("MMMM, dd-MM-yyyy"));
                    sqlCommand.Parameters.AddWithValue("@updatedDate", request.updatedDate); //DateTime.Now.ToString("MMMM, dd-MM-yyyy HH:mm tt"));


                    response.UserId = userId;
                    response.UserName = request.UserName;
                    response.EmailID = request.EmailID;
                    response.MobileNumber = request.MobileNumber;
                    response.Salary = request.Salary;
                    response.Gender = request.Gender;
                    response.Married = request.Married;
                    response.DesignationId = response.DesignationId;
                    response.uploadedDate = request.uploadedDate;
                    response.updatedDate = request.updatedDate;


                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.Message = "Brand Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }


        public async Task<AddUser> AddUser(AddUser request)
        {
            int insertedId = 0;
            //response.IsSuccess = true;
            //response.Message = "User Created SuccessFul";

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    insertedId = await con.QuerySingleAsync<int>(@"INSERT INTO UserData ( Name, Age, Address, City, Country) VALUES ( @Name, @Age, @Address, @City, @Country)
                    SELECT CAST(SCOPE_IDENTITY() AS INT)", request);
                    request.Id = insertedId;
                    // example 1
                   /*  foreach(var image in request.userImages) {
                        string uploadImageQuery = "";
                        image.Id = insertedId;
                        uploadImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                        await con.ExecuteAsync(uploadImageQuery, image);
                    }*/

                    // example 2
                    request.userImages.ToList().ForEach(e => {
                        e.Id = insertedId;
                    });
                   await con.ExecuteAsync(@"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)", request.userImages);

                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return request;
        }


        // Get All Users
       

        // JWT Token Generation
        public string GenerateJwt(string UserID, string Email, string Role)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            //claim is used to add identity to JWT token
            var claims = new[] {
         new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
         new Claim(JwtRegisteredClaimNames.Sid, UserID),
         new Claim(JwtRegisteredClaimNames.Email, Email),
         new Claim(ClaimTypes.Role,Role),
         new Claim("Date", DateTime.Now.ToString()),
         };

            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
              _configuration["Jwt:Audiance"],
              claims,    //null original value
              expires: DateTime.Now.AddMinutes(1), // 120

              //notBefore:
              signingCredentials: credentials);

            string Data = new JwtSecurityTokenHandler().WriteToken(token); //return access token 
            return Data;
        }

        public async Task<GetUsers> GetUsers()
        {
            GetUsers responce = new GetUsers();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    responce.users = (List<Users>)await con.QueryAsync<Users>(@" SELECT * FROM UserData");
                    responce.userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages");
                    responce.IsSuccess = true;
                    responce.Message = "Get Users Successfully";
                    return responce;
                }
            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
                return null;
            }
        }

        public async Task<GetUser> GetUserById(int id)
        {
            GetUser responce = new GetUser();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    var user = await con.QuerySingleAsync<Users>(@" SELECT * FROM UserData WHERE Id = " + id);
                    responce.Id = user.Id;
                    responce.Name = user.Name;
                    responce.Age = user.Age;
                    responce.Address = user.Address;
                    responce.City = user.City;
                    responce.Country = user.Country;
                    responce.userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages WHERE UserId = " + id);
                    //responce.Message = "Get User Successfully";
                    //responce.Id = user.id;
                    return responce;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<AddUser> UpdateUser(AddUser request)
        {
            //AddUser response = new AddUser();
            //response.IsSuccess = true;
            //response.Message = "User Created SuccessFul";

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    await con.ExecuteAsync(@"UPDATE  [dbo].[UserData] SET [Name] = @Name, [Age] = @Age, [Address] = @Address, [City] = @City, [Country] = @Country WHERE [Id] = @Id", request);
                    var userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages WHERE UserId = @Id",request);
                    foreach (var image in request.userImages) // 2
                    {
                        /* string newImageQuery = "";
                         image.Id = request.Id;
                         newImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                         await con.ExecuteAsync(newImageQuery, image);*/

                        if (userImages.Count > 0)
                        {
                            foreach (var existimage in userImages)
                            {
                                if (existimage.ImageId != image.ImageId && existimage.Name != image.Name)
                                {
                                    string newImageQuery = "";
                                    image.Id = request.Id;
                                    newImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                                    await con.ExecuteAsync(newImageQuery, image);
                                }
                            }
                        }
                        else {
                            string newImageQuery = "";
                            image.Id = request.Id;
                            newImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                            await con.ExecuteAsync(newImageQuery, image);
                        }

                    }
                    // await con.ExecuteAsync(@"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)", request.Images);

                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return request;
        }

        public async Task<UserAddressResponce> DeleteUserById(int id)
        {
            UserAddressResponce responce = new UserAddressResponce();
            using (var con = new SqlConnection(_SqlConnection.ConnectionString)) {
                    await con.OpenAsync();
                try {
                    if(id != 0) {
                        await con.ExecuteAsync(@"DELETE FROM UserData WHERE Id = @Id", new { @Id = id });
                    }
                    var userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages WHERE UserId = " + id);
                    foreach(var del in userImages) {
                        if (del.ImageId != 0) {
                            await con.ExecuteAsync(@"DELETE FROM UserImages WHERE UserId = " + id);
                        }
                    }
                    responce.Message = "Record Successfully Deleted";
                    return responce;
                }
                catch(Exception ex) {
                    responce.Message = ex.Message;
                    Console.WriteLine(ex);
                    return responce;
                }
            }
        }

        public async Task<bool> DeleteSpecificImage(int id)
        {
            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                await con.OpenAsync();
                try
                {
                    await con.ExecuteAsync(@"DELETE FROM UserImages WHERE ImageId = " + id);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    return false;
                }
            }
        }
    }
}
