﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface IUser
    {
        public Task<RegisterUserResponse> RegisterUser(RegisterUserRequest request);
        public Task<UserLoginResponse> UserLogin(UserLoginRequest request);
        public Task<UserAddressResponce> UserDetails(UserLoginResponse user);
        public Task<AddInformationResponse> AddInformation(AddInformationRequest request);
        public Task<GetInformationResponse> GetInformation();
        public Task<GetInformation> GetUserInfo(int id);
        public Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation updateUser);

         // for User Multiple Images Upload
        public Task<AddUser> AddUser(AddUser request);
        public Task<GetUsers> GetUsers();
        public Task<GetUser> GetUserById(int id);
        public Task<AddUser> UpdateUser(AddUser request);
        public Task<UserAddressResponce> DeleteUserById(int id);

        public Task<bool> DeleteSpecificImage(int id);






    }
}
