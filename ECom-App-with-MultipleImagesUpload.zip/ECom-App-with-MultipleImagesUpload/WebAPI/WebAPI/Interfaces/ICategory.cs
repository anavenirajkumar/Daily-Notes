﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface ICategory
    {

        // CREATE Methods
        public Task<CategoryResponce> Category(Category category);
        public Task<SubCategoryResponce> SubCategory(SubCategory subcategory);
        public Task<CategoryProductResponce> Product(CategoryProduct product);

        // GET Methods
        public Task<CategoryResponce> GetCategories();
        public Task<SubCategoryResponce> GetSubCategories();

        public Task<CategoryProductResponce> GetProducts();

        /*public Task<SubCategoryResponce> GetSubCategoriesById(int categoryId);*/


        // GET By ID Methods
        public Task<CategoryResponce> GetCategory(int categoryId);
        public Task<SubCategoryResponce> GetSubCategory(int subcategoryId);
        public Task<CategoryProductResponce> GetProduct(int productId);

        // Update Methods
        public Task<CategoryResponce> UpdateCategory(Category category);
        public Task<SubCategoryResponce> UpdateSubCategory(SubCategory subcategory);
        public Task<CategoryProductResponce> UpdateProduct(CategoryProduct product);

        // Delete By ID Methods
        public Task<CategoryResponce> DeleteCategory(int categoryId);
        public Task<SubCategoryResponce> DeleteSubCategory(int subcategoryId);
        public Task<CategoryProductResponce> DeleteProduct(int productId);


    }
}
