﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;
using WebAPI.Interfaces;

namespace WebAPI.Services
{
    public class ProductRepository : IProductRepository
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        string connectionString = "Server=SBSLPT-34; Initial Catalog=MiniProject; user id=sa; password=sql@123;";


        public ProductRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);

        }
        public async Task<ProductBrand> AddBrand(ProductBrand request)
        {
            ProductBrand responce = new ProductBrand();
/*            responce.Message = "ProductBrand Created Successfully";
*/            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO ProductBrands (Name,ProductTypeId) Values (@Name, @ProductTypeId)";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Name", request.Name);
                    sqlCommand.Parameters.AddWithValue("@ProductTypeId", request.ProductTypeId);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    responce.Name = request.Name;
                    responce.ProductTypeId = request.ProductTypeId;
                    if (status <= 0)
                    {
                        //responce.Message = "ProductBrand Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;

        }
        public async Task<ProductBrandResponce> GetBrand(int id)
        {
            ProductBrandResponce response = new ProductBrandResponce();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT Id, Name, ProductTypeId FROM ProductBrands WHERE Id = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            //response.Message = "Get Brand Successful";
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.ProductTypeId = Convert.ToInt32(dataReader["ProductTypeId"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                //response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }
        public async Task<ProductBrandResponce> UpdateBrand(ProductBrand request)
        {
            var categoryId = request.Id;
            var ProductTypeId = request.ProductTypeId;
            string categoryName = request.Name;

            ProductBrandResponce response = new ProductBrandResponce();
            //response.Message = "ProductBrand Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (categoryId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE ProductBrands SET Name = @Name, ProductTypeId = @ProductTypeId WHERE Id = " + categoryId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Id", categoryId);
                    sqlCommand.Parameters.AddWithValue("@ProductTypeId", ProductTypeId);
                    sqlCommand.Parameters.AddWithValue("@Name", categoryName);
                    response.Id = categoryId;
                    response.Name = categoryName;
                    response.ProductTypeId = ProductTypeId;

                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.Message = "Brand Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                //response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<ProductBrandResponce> DeleteBrand(int brandId)
        {
            ProductBrandResponce response = new ProductBrandResponce();
           // response.Message = "Brand Deleted";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM ProductBrands WHERE Id = " + brandId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            //response.Message = "Category Delete Successful";
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.ProductTypeId = Convert.ToInt32(dataReader["ProductTypeId"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
               // response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }
        public async Task<ProductTypeResponce> AddType(ProductType request)
        {
            ProductTypeResponce responce = new ProductTypeResponce();
           // responce.Message = "ProductType Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO ProductTypes (Name) Values (@Name);";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Name", request.Name);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                       // responce.Message = "ProductType Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                //responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }
        public async Task<ProductTypeResponce> DeleteType(int brandId)
        {
            ProductTypeResponce response = new ProductTypeResponce();
            //response.Message = "Type Deleted";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM ProductTypes WHERE Id = " + brandId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            //response.Message = "Type Delete Successful";
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                //response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<ProductTypeResponce> GetType(int id)
        {
            ProductTypeResponce response = new ProductTypeResponce();
            //response.Message = "Get Type";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT Id, Name FROM ProductTypes WHERE Id = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            //response.Message = "Get Type Successful";
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                //response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<ProductTypeResponce> UpdateType(ProductType request)
        {
            var categoryId = Convert.ToInt32(request.Id);
            string categoryName = request.Name;

            ProductTypeResponce response = new ProductTypeResponce();
            //response.Message = "ProductType Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (categoryId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE ProductTypes SET Name = @Name WHERE Id = " + categoryId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Id", categoryId);
                    sqlCommand.Parameters.AddWithValue("@Name", categoryName);

                    response.Id = categoryId;
                    response.Name = categoryName;

                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                       // response.Message = "Type Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
               // response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<ProductResponce> AddProduct(Product request)
        {
            ProductResponce responce = new ProductResponce();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO Products (Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId) Values
                                    (@Name, @Description, @Price, @PictureUrl, @ProductTypeId, @ProductBrandId)";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Name", request.Name);
                    sqlCommand.Parameters.AddWithValue("@Description", request.Description);
                    sqlCommand.Parameters.AddWithValue("@Price ", request.Price);
                    sqlCommand.Parameters.AddWithValue("@PictureUrl ", request.PictureUrl);
                    sqlCommand.Parameters.AddWithValue("@ProductTypeId ", request.ProductTypeId);
                    sqlCommand.Parameters.AddWithValue("@ProductBrandId ", request.ProductBrandId);

                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }

        public async Task<ProductResponce> DeleteProduct(int productId)
        {
            ProductResponce response = new ProductResponce();
            //response.Message = " Product Deleted Successful";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM Products WHERE Id = " + productId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            //response.Message = " Product Deleted Successful";
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]);
                            response.ProductType =  Convert.ToInt32(dataReader["ProductTypeId"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            response.Price = Convert.ToInt32(dataReader["Price"]);
                            response.Description = dataReader["Description"] != DBNull.Value ? Convert.ToString(dataReader["Description"]) : string.Empty;
                            response.PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? Convert.ToString(dataReader["PictureUrl"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                //response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }
        public async Task<ProductResponce> UpdateProduct(Product request)
        {
            var productId = Convert.ToInt32(request.Id);

            ProductResponce response = new ProductResponce();
            //response.Message = "Product Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (productId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE Products SET Name = @Name, Price = @Price, Description = @Description, PictureUrl = @PictureUrl, ProductTypeId = @ProductTypeId, ProductBrandId = @ProductBrandId WHERE Id = " + productId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Id", productId);
                    sqlCommand.Parameters.AddWithValue("@Name", request.Name);
                    sqlCommand.Parameters.AddWithValue("@Price", request.Price);
                    sqlCommand.Parameters.AddWithValue("@Description", request.Description);
                    sqlCommand.Parameters.AddWithValue("@PictureUrl", request.PictureUrl);
                    sqlCommand.Parameters.AddWithValue("@ProductTypeId", request.ProductTypeId);
                    sqlCommand.Parameters.AddWithValue("@ProductBrandId", request.ProductBrandId);

                    response.Id = request.Id;
                    response.Name = request.Name;
                    response.Price =   Convert.ToInt32(request.Price);
                    response.Description = request.Description;
                    response.PictureUrl = request.PictureUrl;
                    response.ProductBrand = request.ProductBrandId;
                    response.ProductType = request.ProductTypeId;

                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.Message = "Product Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                //response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }
        public async Task<ProductResponce> GetProductByIdAsync(int id)
        {
            ProductResponce response = new ProductResponce();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT Id, Name, Price, Description, PictureUrl, ProductTypeId, ProductBrandId  FROM Products WHERE Id = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            response.Description = dataReader["Description"] != DBNull.Value ? Convert.ToString(dataReader["Description"]) : string.Empty;
                            response.PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? Convert.ToString(dataReader["PictureUrl"]) : string.Empty;
                            response.Price = Convert.ToInt32(dataReader["Price"]);
                            response.ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]);
                            response.ProductType =  Convert.ToInt32(dataReader["ProductTypeId"]);
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<List<Products>> GetProductsAsync()
        {
            var response = new List<Products>();
            //response.Message = "Get Products SuccessFul";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM Products";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                          //var product = new List<Products>();

                            while (await dataReader.ReadAsync())
                            {
                                Products data = new Products();

                                data.ProductId = Convert.ToInt32(dataReader["Id"]);
                                data.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                                data.Description = dataReader["Description"] != DBNull.Value ? Convert.ToString(dataReader["Description"]) : string.Empty;
                                data.PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? Convert.ToString(dataReader["PictureUrl"]) : string.Empty;
                                data.Price = Convert.ToInt32(dataReader["Price"]);
                                data.ProductBrandId = Convert.ToInt32(dataReader["ProductBrandId"]);
                                data.ProductTypeId = Convert.ToInt32(dataReader["ProductTypeId"]);
                                response.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<GetNoteResponse> GetProducts(GetProducts request)
        {
            GetNoteResponse response = new GetNoteResponse();
            response.IsSuccess = true;
            response.Message = "Fetch Data Successfully.";

            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                int Offset = (request.PageNumber - 1) * request.NumberOfRecordPerPage;
                int NumberOfRecordPerPage = request.NumberOfRecordPerPage;
                var searchName = request.SearchName+ '%';
                var brandId = request.BrandId;
                var typeId = request.TypeId;
                string SqlQuery = string.Empty;


                /*   SqlQuery = @" SELECT ProductId, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                     (SELECT COUNT(*) FROM Products) AS TotalRecord
                                     From Products 
                                     Order By ProductId " + request.SortBy.ToUpperInvariant()+@"
                                     LIMIT @Offset, @NumberOfRecordPerPage";*/

                if (request.SearchName.Length > 0) {
                    //SqlQuery = "SELECT * FROM Products WHERE Name LIKE @searchName";
                    SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE Name LIKE @searchName ) AS TotalRecord
                                  From Products WHERE Name LIKE @searchName
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";

                    /* SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                   (SELECT COUNT(*) FROM Products WHERE Name LIKE 'i%') AS TotalRecord
                                   From Products WHERE Name LIKE 'i%'*/
                }

                else if (request.BrandId > 0) {
                    SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductBrandId = @brandId) as TotalRecord from Products WHERE ProductBrandId = @brandId
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";

                    /* SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                   (SELECT COUNT(*) FROM Products WHERE ProductBrandId = 10) as TotalRecord from Products WHERE ProductBrandId = 10
                                   Order By Id asc
                                   OFFSET 0 ROWS
                                   FETCH NEXT 6 ROWS ONLY;*/
                }

                else if (request.TypeId > 0)
                {
                    SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductTypeId = @typeId) as TotalRecord from Products WHERE ProductTypeId = @typeId
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";

                    /* SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                   (SELECT COUNT(*) FROM Products WHERE ProductBrandId = 10) as TotalRecord from Products WHERE ProductBrandId = 10
                                   Order By Id asc
                                   OFFSET 0 ROWS
                                   FETCH NEXT 6 ROWS ONLY;*/
                }
                else
                {
                    SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products) AS TotalRecord
                                  From Products
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                }



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@brandId", request.BrandId);
                    sqlCommand.Parameters.AddWithValue("@typeId", request.TypeId);
                    sqlCommand.Parameters.AddWithValue("@searchName", searchName);
                    sqlCommand.Parameters.AddWithValue("@Offset", Offset);
                    sqlCommand.Parameters.AddWithValue("@NumberOfRecordPerPage", request.NumberOfRecordPerPage);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            int Count = 0;
                            response.data = new List<ProductResponce>();
                            while (await dataReader.ReadAsync())
                            {
                                response.data.Add(
                                    new ProductResponce()
                                    {
                                       /* NoteId = dataReader["Id"] != DBNull.Value ? (Int32)dataReader["Id"] : -1,
                                        Note = dataReader["Note"] != DBNull.Value ? (string)dataReader["Note"] : null,
                                        ScheduleDate = dataReader["ScheduleDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["ScheduleDate"]).ToString("dd/MM/yyyy") : null,
                                        ScheduleTime = dataReader["ScheduleTime"] != DBNull.Value ? Convert.ToDateTime(dataReader["ScheduleTime"]).ToString("hh:mm tt") : null,
                                        Monday= dataReader["Monday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Monday"]) : false,
                                        Tuesday= dataReader["Tuesday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Tuesday"]) : false,
                                        Wednesday= dataReader["Wednesday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Wednesday"]) : false,
                                        Thursday= dataReader["Thursday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Thursday"]) : false,
                                        Friday= dataReader["Friday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Friday"]) : false,
                                        Saturday= dataReader["Saturday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Saturday"]) : false,
                                        Sunday= dataReader["Sunday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Sunday"]) : false,*/

                                Id =dataReader["Id"] != DBNull.Value ? (Int32)dataReader["Id"] : -1,
                                Name = dataReader["Name"] != DBNull.Value ? (string)dataReader["Name"] : null,
                                        Description = dataReader["Description"] != DBNull.Value ? (string)dataReader["Description"] : null,
                                        PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? (string)dataReader["PictureUrl"] : null,
                                        Price = Convert.ToInt32(dataReader["Price"]),
                                ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]),
                                ProductType =  Convert.ToInt32(dataReader["ProductTypeId"])
                                    });

                                if (Count == 0)
                                {
                                    Count++;
                                    response.TotalRecords = dataReader["TotalRecord"] != DBNull.Value ? Convert.ToInt32(dataReader["TotalRecord"]) : -1;
                                    //response.TotalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(response.TotalRecords / request.NumberOfRecordPerPage)));
                                    response.CurrentPage = request.PageNumber;
                                    response.PageSize = request.NumberOfRecordPerPage;
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;
            }

            return response;
        }

        public async Task<GetNoteResponse> SearchProducts(GetSearchNoteRequest request)
        {
            GetNoteResponse response = new GetNoteResponse();
            response.IsSuccess = true;
            response.Message = "Fetch Data Successfully.";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                //int Offset = (request.PageNumber - 1) * request.NumberOfRecordPerPage;
                //int NumberOfRecordPerPage = request.NumberOfRecordPerPage;
                var searchName = request.SearchName+ '%';
                string SqlQuery = string.Empty;
                SqlQuery = "SELECT * FROM Products WHERE Name LIKE @searchName";
                //SqlQuery = "SELECT * FROM Products WHERE Name LIKE" + " " +  request.SearchName.ToUpperInvariant() + " " + request.LastName.ToUpperInvariant();

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    //sqlCommand.Parameters.AddWithValue("@Offset", Offset);
                    sqlCommand.Parameters.AddWithValue("@searchName", searchName);
                    //sqlCommand.Parameters.AddWithValue("@NumberOfRecordPerPage", request.NumberOfRecordPerPage);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            //int Count = 0;
                            response.data = new List<ProductResponce>();
                            while (await dataReader.ReadAsync())
                            {
                                response.data.Add(
                                    new ProductResponce()
                                    {
                                        Id =dataReader["Id"] != DBNull.Value ? (Int32)dataReader["Id"] : -1,
                                        Name = dataReader["Name"] != DBNull.Value ? (string)dataReader["Name"] : null,
                                        Description = dataReader["Description"] != DBNull.Value ? (string)dataReader["Description"] : null,
                                        PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? (string)dataReader["PictureUrl"] : null,
                                        Price = Convert.ToInt32(dataReader["Price"]),
                                        ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]),
                                        ProductType =  Convert.ToInt32(dataReader["ProductTypeId"])
                                    });

                               /* if (Count == 0)
                                {
                                    Count++;
                                    response.TotalRecords = dataReader["TotalRecord"] != DBNull.Value ? Convert.ToInt32(dataReader["TotalRecord"]) : -1;
                                    response.TotalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(response.TotalRecords / request.NumberOfRecordPerPage)));
                                    response.CurrentPage = request.PageNumber;
                                }*/
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;
            }

            return response;
        }

        public async Task<List<ProductBrandResponce>> GetBrands()
        {
            var response = new List<ProductBrandResponce>();
            //response.Message = "Get Products SuccessFul";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM ProductBrands";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            while (await dataReader.ReadAsync())
                            {
                                ProductBrandResponce data = new ProductBrandResponce();
                                data.Id = Convert.ToInt32(dataReader["Id"]);
                                data.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                                data.ProductTypeId = Convert.ToInt32(dataReader["ProductTypeId"]);
                                response.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }


        public async Task<List<ProductTypeResponce>> GetTypes()
        {
            var response = new List<ProductTypeResponce>();
            //response.Message = "Get Products SuccessFul";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM ProductTypes";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            while (await dataReader.ReadAsync())
                            {
                                ProductTypeResponce data = new ProductTypeResponce();
                                data.Id = Convert.ToInt32(dataReader["Id"]);
                                data.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                                response.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        /* public async Task<IReadOnlyList<ProductResponce>> GetProductTypesAsync()
         {

         }



         public Task<IReadOnlyList<ProductBrand>> GetProductBrandsAsync()
         {
             throw new NotImplementedException();
         }
 */

    }
}
