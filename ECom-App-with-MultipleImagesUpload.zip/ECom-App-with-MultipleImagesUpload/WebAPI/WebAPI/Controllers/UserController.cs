﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
    public class UserController : ControllerBase
    {

        public readonly IUser _user;

        public UserController(IUser user)
        {
            _user = user;
        }

        [Route("RegisterUser")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> RegisterUser(RegisterUserRequest request)
        {
            RegisterUserResponse response = new RegisterUserResponse();
            try
            {

                response = await _user.RegisterUser(request);

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

         [Route("LoginUser")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UserLogin(UserLoginRequest request)
        {
            UserLoginResponse response = new UserLoginResponse();
            try
            {
                response = await _user.UserLogin(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [Route("Address")]
        [HttpPost]
        [Authorize(Roles = "User, Admin")]
        public async Task<IActionResult> UpdateAddress(UserLoginResponse user) // Get All Users Information
        {
            UserAddressResponce response = new UserAddressResponce();
            try
            {
                response = await _user.UserDetails(user);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [Route("Admin/Add")]
        [HttpPost]
        [Authorize(Roles = "Admin")] // Admin Can Add Anything
        public async Task<IActionResult> AddInformation(AddInformationRequest request)
        {
            AddInformationResponse response = new AddInformationResponse();
            try
            {
                response = await _user.AddInformation(request);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [Route("Admin/Get")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<IActionResult> GetInformation() // Get All Users Information
        {
            GetInformationResponse response = new GetInformationResponse();
            try
            {
                response = await _user.GetInformation();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);

        }

        [Route("Admin/GetUserInfo")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<GetInformation> GetUserInformation(int Id) {
            var response = await _user.GetUserInfo(Id);
            if (response == null)
            {
                return null;
            }
            return response;
        }


        [Route("Admin/UpdateUserInfo")]
        [HttpPut]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation userInfo)
        {
            var user = await _user.UpdateUserInformation(userInfo);
            return user;
        }

        [Route("Admin/AddUser")]
        [HttpPost]
        [Authorize(Roles = "Admin")] // Admin Can Add Anything
        public async Task<IActionResult> AddUser(AddUser request)
        {
            AddUser response = new AddUser();
            if(request.Id == 0) { 
              response = await _user.AddUser(request);
            }
            else {
                response = await _user.UpdateUser(request);
            }
            return Ok(response);
        }

        [Route("Admin/GetUsers")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<GetUsers> GetUsers() // Get All Users Information
        {
            GetUsers response = new GetUsers();
            try
            {
                response = await _user.GetUsers();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;

        }


        [Route("Admin/GetUser")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<GetUser> GetUserById(int id) // Get All Users Information
        {
            GetUser response = new GetUser();
            try
            {
                response = await _user.GetUserById(id);
            }
            catch (Exception ex)
            {
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }

            return response;

        }

        [Route("Admin/DeleteUser")]
        [HttpDelete]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<UserAddressResponce> DeleteUser(int id)
        {
            var response = await _user.DeleteUserById(id);
            if (response == null)
            {
                return null;
            }
            return response;
        }

        [Route("Admin/DeleteImage")]
        [HttpDelete]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<bool> DeleteSpecificImage(int id) {
          var response = await _user.DeleteSpecificImage(id);
          if (response == false) {
                return false;
          }
          return true;
        }

    }
}
