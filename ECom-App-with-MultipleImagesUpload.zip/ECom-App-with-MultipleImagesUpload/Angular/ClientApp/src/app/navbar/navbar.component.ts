import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  public token:any;

  constructor(private userService : UserService) { }

  ngOnInit() {
      if(localStorage.getItem('token') === ""){
            location.reload();
      }
  }


  public isLoggedIn(){
    return this.userService.isLoggedIn();
  }

  public userInformation(){
    return this.userService.userInfomation();
  }

  public admin(){
    return this.userService.AdminUser();
  }

  public logout(){
    localStorage.removeItem('token');
    localStorage.removeItem('userDetails');
  }

}
