export interface ICategory {
    categoryId : number,
    categoryName : string
}

export interface ISubCategory {
    subcategoryId : number,
    categoryId : number,
    subcategoryName : string
}

export interface IProduct {
    productId : number,
    productName : string,
    productPrice : number,
    categoryId : number,
    subcategoryId : number
}