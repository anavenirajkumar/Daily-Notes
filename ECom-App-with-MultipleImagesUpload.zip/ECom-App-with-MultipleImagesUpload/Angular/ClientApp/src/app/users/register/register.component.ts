import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ILogin } from '../interfaces/ILogin';
import { IRegister } from '../interfaces/IRegister';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public user:IRegister = {
      username : '',
      email : '',
      password : '',
      confirmpassword : '',
      role : ''

  }

  public registerForm: FormGroup | any;

  constructor(private formBuilder : FormBuilder,
     private userService : UserService
    ) { }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      username : ['', [Validators.required, Validators.minLength(5)]],
      password : ['', [Validators.required, Validators.minLength(5),Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$')]],
      confirmpassword : ['', [Validators.required]],
      email : ['', Validators.required],
      role : ['User']
    })
  }

  registerUser(){
    this.registerForm.markAllAsTouched();
    if(this.registerForm.valid){
        //console.log(this.registerForm);

      this.user.username = this.registerForm.value.username;
      this.user.password = this.registerForm.value.password;
      this.user.confirmpassword = this.registerForm.value.confirmpassword;
      this.user.email = this.registerForm.value.email;
      this.user.role = this.registerForm.value.role;

      console.log(this.user);

      this.userService.register(this.user).subscribe((responce) => {
        console.log(responce);
      })
    }
  }

  public validatePassord(){
   // console.log(this.registerForm.value.password === this.registerForm.value.confirmpassword)
    return this.registerForm.value.password === this.registerForm.value.confirmpassword;
  }

}
