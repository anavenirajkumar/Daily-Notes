import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { AddBrandComponent } from './components/add-brand/add-brand.component';
import { UpdateBrandComponent } from './components/update-brand/update-brand.component';
import { AddTypeComponent } from './components/add-type/add-type.component';
import { UpdateTypeComponent } from './components/update-type/update-type.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { UpdateProductComponent } from './components/update-product/update-product.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UploadXmlFileComponent } from './components/upload-xml-file/upload-xml-file.component';
import { IdComponent } from './components/upload-xml-file/id/id.component';
import { AddUsersComponent } from './components/add-users/add-users.component';
import { AddCategoryComponent } from './components/category-controlller/add-category/add-category.component';
import { AddSubCategoryComponent } from './components/category-controlller/add-sub-category/add-sub-category.component';
import { AddProductCateComponent } from './components/category-controlller/add-product-cate/add-product-cate.component';
import { ProductCatIdComponent } from './components/category-controlller/add-product-cate/product-cat-id/product-cat-id.component';
import { MultipleImagesUploadComponent } from './components/multiple-images-upload/multiple-images-upload.component';
import { MultipleImagesEditComponent } from './components/multiple-images-edit/multiple-images-edit.component';

@NgModule({
  declarations: [
    AdminComponent,
    AddBrandComponent,
    UpdateBrandComponent,
    AddTypeComponent,
    UpdateTypeComponent,
    AddProductComponent,
    UpdateProductComponent,
    UploadXmlFileComponent,
    IdComponent,
    AddUsersComponent,
    AddCategoryComponent,
    AddSubCategoryComponent,
    AddProductCateComponent,
    ProductCatIdComponent,
    MultipleImagesUploadComponent,
    MultipleImagesEditComponent
    ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class AdminModule { }
