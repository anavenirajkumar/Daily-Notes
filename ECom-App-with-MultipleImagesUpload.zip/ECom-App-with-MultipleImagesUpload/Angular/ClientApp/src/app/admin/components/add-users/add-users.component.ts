import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { EmployeeService } from './services/employee.service';

@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.css']
})
export class AddUsersComponent implements OnInit {
  // {
  //   "userName": "string", //
  //   "emailID": "string",
  //   "mobileNumber": "string",
  //   "salary": 0,
  //   "gender": "string",
  //   "marrried": true,
  //   "designationId": 0,
  //   "uploadedDate": "2022-09-30T10:08:22.290Z",
  //   "updatedDate": "2022-09-30T10:08:22.290Z"
  // } 

  public employeesList:any;
  public employeeData:any = {
    UserId: 0,
    userName : '',
    emailID : '',
    mobileNumber : '',
    salary : 0,
    // doj : '',
    married : false,
    gender : '', 
    designationID : 0,
    uploadedDate : '',
    updatedDate : '',
   //  isMarried : false,
    // isActive : 0,
    selectedFroots : []
  }
  public genders = [{id : 1, name : "Male"}, {id :2 , name :"Female"}];
  public fruits:any = [
    { id: 1, name: 'Apple', checked: false },
    { id: 2, name: 'Banana', checked: false },
    { id: 3, name: 'Carrot', checked: false },
    { id: 4, name: 'Tomoto', checked: false },
    { id: 5, name: 'Orange', checked: false },
    { id: 6, name: 'Ice-Cream', checked: false },
    { id: 7, name: 'Mango', checked: false }
  ];
  public form: FormGroup | any;

  public activeStatus = [{id:1, name:'Yes',marriedStatus: true}, {id:2, name : 'No', marriedStatus: false}];
 // public employeeActiveStatus:any;
  constructor(public empService : EmployeeService, public datepipe: DatePipe) { }

  ngOnInit() {
      this.empService.getEmployees().subscribe((res) => {
        this.empService.listEmployee=res;
      })
      console.log(this.empService.listEmployee);
      this.empService.getDesignations().subscribe(data => {
        this.empService.listDesignation=data;
        console.log(data);
      });
    this.form = new FormGroup({
      fruits: new FormArray([]),
    });
  }

  submit(){
    console.log(this.employeeData); 
    if(this.employeeData.id == 0) {
      this.empService.employee = this.employeeData;
      this.empService.saveEmp().subscribe(data => {
      this.refreshData()       
      this.employeeData = {};
      this.activeStatus.forEach((ele) => {
        ele.marriedStatus = false;
       });
      })
    }else{
      let designationID:number = +this.employeeData.designationID;
      this.employeeData.designationID = designationID;
      this.empService.employee = this.employeeData;
      this.empService.updateEmp().subscribe(data => {
         this.refreshData();
         this.employeeData = {};
         this.activeStatus.forEach((ele) => {
          ele.marriedStatus = false;
         })
         console.log('Updated')
      })
    }
  }

  editEmployee(selectedEmployee:any){
    console.log(selectedEmployee);
    this.employeeData = selectedEmployee;
    console.log(selectedEmployee);
    let df=this.datepipe.transform(selectedEmployee.doj, 'yyyy-MM-dd');
    selectedEmployee.doj = df;
    console.log(selectedEmployee.doj);

    this.activeStatus.forEach((ele:any) => {
         if(ele.id === selectedEmployee.isActive){ 
             if(selectedEmployee.isActive == true){
                ele.isActive = true;
             } else {
                ele.isActive = true;
             }
         } 
         else {
            ele.isActive = false;
         }
    });
    console.log(this.activeStatus);

  }

  deleteEmployee(id:number){
           this.empService.deleteEmployee(id).subscribe(data=>{
             console.log('Record Deleted');
             this.refreshData()
           }, 
           err =>{
             console.log('Record not Deleted');
           });
  }

  refreshData(){
    this.empService.getEmployees().subscribe(data => {
      this.empService.listEmployee = data;  // listEmpoyee in services
    });
  }

  selectedMarriage(event:any) {
    console.log(event.target.value);
    // this.marriages.forEach((val:any) => {
    //   if(val.id == item.id && val.isSelected === false ){
    //     val.isSelected = true;
    //     this.checkedMarriage = val;
    //   }
    //   else if(val.id == item.id && item.isSelected == true){
    //     val.isSelected = false;
    //   }
    //   else {
    //     val.isSelected = false;
    //   }
    // });
    // console.log(item);
  }

  selectedActiveStatus(item:any) {
   // console.log(item);
    this.activeStatus.forEach((ele) => {
      if(ele.id === item.id && ele.marriedStatus == false){
         ele.marriedStatus = true;
         this.employeeData.married = true;

      } else{
        ele.marriedStatus = false;
        this.employeeData.married = false;
      }
      console.log(this.employeeData);
    })
    // this.activeStatus.forEach((val:any) => {
    //   if (val.id == item.id) {
    //       if(item.name === 'Active'){
    //         val.isActive = true;
    //         this.employeeActiveStatus = item;
    //       } else {
    //         val.isActive = true;
    //         this.employeeActiveStatus = item;
    //       }
    //   }
    //   else if(val.id == item.id && item.isActive == true ) {
    //     val.isActive = false;
    //     this.employeeActiveStatus = item;
    //   }
    //   else if(val.id == item.id && item.isActive == false) {
    //     val.isActive = false;
    //   }
    //   else {
    //     this.activeStatus.forEach((val:any) => {
    //      if(val.id == item.id && item.isActive == true){
    //         val.isActive = true
    //      } 
    //      else if(val.id == item.id && item.isActive == false){
    //        val.isActive = false
    //      } 
    //      else {
    //       val.isActive = false;
    //      }
    //     });
    //   }
    // });
    // console.log(this.activeStatus);
    // console.log(this.employeeActiveStatus);
  }

  selectFroots(obj:any){
    //  if(!obj.value.checked == true){
    //    if(this.selectedFroots.length > 0){
    //     this.employeeData.selectedFroots.forEach((ele:any) => {
    //       if(ele.id == obj.id){
    //           let index = this.employeeData.selectedFroots.findIndex(ele.id);
    //           this.employeeData.selectedFroots.split(index, 1)
    //       } 
    //    })
    //    }
       
    //  }
     obj.value.checked = true;
     this.employeeData.selectedFroots.push(obj.value);
     console.log(this.employeeData.selectedFroots);
     console.log(obj);
  }

  selectedFroot(obj:any){
     console.log(obj);
    let objIndex = this.employeeData.selectedFroots.findIndex((ele:any) => ele.id === obj.id);
     if(objIndex >= 0){
       this.employeeData.selectedFroots.splice(objIndex,1);
     } else{
      this.employeeData.selectedFroots.push(obj);
     }
     console.log(this.employeeData.selectedFroots);
  }

}
