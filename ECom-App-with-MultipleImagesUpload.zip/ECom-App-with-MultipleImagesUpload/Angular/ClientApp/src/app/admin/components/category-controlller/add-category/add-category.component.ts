import { Component, OnInit } from '@angular/core';
import { ICategory } from 'src/app/users/interfaces/ICategory';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {

  public category:ICategory = {
    categoryId : 0,
    categoryName : ''
  }

  public alert:boolean  = false;

  public categoryResponce:any = {
     message : ''
  }

  public categories:any = {
    categories : []
  };

  constructor(private adminService:UserService) { }

  ngOnInit(): void {
    this.getCategories();
  }

  public createCategory(){
    this.adminService.createCategory(this.category).subscribe((res)=>{
      console.log(res);
      this.getCategories();
      this.alert = true;
      this.categoryResponce = res;
      this.category.categoryName = ""
      setTimeout(() => {
          this.alert = false
      }, 2000);
    })
  }

 public getCategories(){
  this.adminService.getCategories().subscribe((data)=> {
    this.categories = data;
    console.log(this.categories);
  })
 }

 public deleteCategory(categoryId:any){
    this.adminService.deleteCategory(categoryId).subscribe((res)=>{
      console.log(res);
      this.getCategories();
    })
 }
}
