import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleImagesUploadComponent } from './multiple-images-upload.component';

describe('MultipleImagesUploadComponent', () => {
  let component: MultipleImagesUploadComponent;
  let fixture: ComponentFixture<MultipleImagesUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultipleImagesUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleImagesUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
