import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-multiple-images-edit',
  templateUrl: './multiple-images-edit.component.html',
  styleUrls: ['./multiple-images-edit.component.css']
})
export class MultipleImagesEditComponent implements OnInit {

  public userId:any;
  public user:any = {
     id : 0,
     name : '',
     age : 0,
     address : '',
     city : '',
     country : '',
     userImages : []
  }
  constructor(private snapShot:ActivatedRoute, private userService:UserService, private router : Router) { }

  ngOnInit(): void {
    this.snapShot.paramMap.subscribe((id)=> {
      this.userId = id.get('id');
      this.getUser(this.userId);
    })
  }

  public getUser(id:any){
     this.userService.getUserId(id).subscribe((res:any) =>{
       this.user = res;
       console.log(this.user);
     })
  }
  
   public removeSelectedImage(obj:any){
    let imageId = obj.imageId;
    let imageIndex = this.user.userImages.findIndex((ele:any) => ele.imageId === imageId);
    this.user.userImages.splice(imageIndex,1);
    this.userService.deleteSpecificImage(imageId).subscribe((res)=> {
      console.log(res);
    }, err => {
      console.log(err);
    })
   }

   public profilePhotos(event:any){
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              let imageName = event.target.files[i].name;
                reader.onload = (event:any) => {
                  console.log(event.target.result);
                   this.user.userImages.push({ name : imageName, image : event.target.result}); 
                }
              reader.readAsDataURL(event.target.files[i]);
              //console.log(event.target.files[i].name);
      }
  }
  console.log(this.user.userImages);
  
  }

  public UpdateUser(){
    let age:number = +this.user.age;
    this.user.age = age;
    //console.log(this.user); return;
     this.userService.uploadUser(this.user).subscribe((res) => {
      console.log(res);
     }, err => {
      console.log(err);
     });
     this.router.navigateByUrl('/admin/multiple-images-upload');
  }
}
