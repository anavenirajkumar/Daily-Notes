import { Component, OnInit } from '@angular/core';
import { ShopService } from 'src/app/shop/services/shop.service';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-multiple-images-upload',
  templateUrl: './multiple-images-upload.component.html',
  styleUrls: ['./multiple-images-upload.component.css']
})
export class MultipleImagesUploadComponent implements OnInit {

  public user:any = {
    id : 0,
    name : '',
    city : '',
    country : '',
    age : null,
    address : '',
    userImages:[]
  }
  public data:any = {
    userData : [],
    userImages : []
  }
  constructor(private userService:UserService) { }

  ngOnInit(): void {
    this.getUser();
  }

  public profilePhotos(event:any){
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              let imageName = event.target.files[i].name;
                reader.onload = (event:any) => {
                  console.log(event.target.result);
                   this.user.userImages.push({id: i, name : imageName, image : event.target.result}); 
                }
              reader.readAsDataURL(event.target.files[i]);
              //console.log(event.target.files[i].name);
      }
  }
  console.log(this.user.userImages);
  
  }



public removeProfilePhotos(){
  this.user.userImages = [];
  console.log(this.user.userImages);
}

public SelectedProfileImage(imageId:any){
let imageIndex = this.user.userImages.findIndex((e:any) => e.id === imageId);
this.user.userImages.splice(imageIndex,1);
console.log(this.user.userImages);

}

public submitUserDetails(){
  let age:number = +this.user.age;
  this.user.age = age;
  console.log(this.user); 
  this.userService.uploadUser(this.user).subscribe((res) => {
   console.log(res);
   this.user = {};
   this.user.userImages = [];
  }, err => {
    console.log(err);
  });
  this.getUser();
}
public getUser(){
  this.userService.getUsers().subscribe((res:any) => {
   this.data.userData = res.users;
   this.data.userImages = res.userImages;
   console.log(res);
   console.log(res.users);
  });
}

public deleteUser(id:any){
  console.log(id); 
  this.userService.deleteUser(id).subscribe((res:any) => {
    console.log(res);
    this.getUser();
  }, err => {
    console.log(err);
  })
  }
}
