import { Component, OnInit } from '@angular/core';
import { ShopService } from 'src/app/shop/services/shop.service';

@Component({
  selector: 'app-add-type',
  templateUrl: './add-type.component.html',
  styleUrls: ['./add-type.component.css']
})
export class AddTypeComponent implements OnInit {

  public types:any = [];
  public type = {
   id : 0,
   name : ''
  }
  constructor(private shopService: ShopService) { }

  ngOnInit(): void {
     this.getTypes();
  }

  public addType(){
    if(this.type.name.length > 2){
      this.shopService.addType(this.type).subscribe((res) => {
        console.log(res);
        this.getTypes();
      });
     
    } else{
      alert("Please Enter Minimum Characters");
    }
  }

  public getTypes(){
    this.shopService.getTypes().subscribe((res) => {
      this.types = res;
    })
  }
  public deleteType(id:any){
    this.shopService.deleteType(id).subscribe((res) => {
      console.log(res);
      this.getTypes();
    })
  }
}
