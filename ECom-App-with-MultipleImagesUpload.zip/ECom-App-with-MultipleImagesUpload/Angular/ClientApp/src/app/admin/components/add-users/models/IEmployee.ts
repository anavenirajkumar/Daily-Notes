export class IEmployee{
    id: number=0;
    name : string | any;
    lastName : string='';
    email : string='';
    age : number | any;
    doj : any;
    gender : string=''; // male
    isMarried : number | any;
    isActive : number | any;
    designationID : any;
    designation : string='';
}

export class IDesignation{
    id: number | any;
    designation : string='';
}

