import { Component, OnInit } from '@angular/core';
import { ISubCategory } from 'src/app/users/interfaces/ICategory';
import { UserService } from 'src/app/users/services/user.service';


@Component({
  selector: 'app-add-sub-category',
  templateUrl: './add-sub-category.component.html',
  styleUrls: ['./add-sub-category.component.css']
})
export class AddSubCategoryComponent implements OnInit {

  public subcategory:ISubCategory = {
    subcategoryId : 0,
    categoryId : 0,
    subcategoryName : ''
  }

  public categories:any = {
     message : '',
    categories : []
  }
  public alert:boolean  = false;

  public subcategoryResponce:any = {
     message : ''
  }

  public subCategories:any = {
    subCategories : []
  }
  constructor(private adminService :UserService) { }

  ngOnInit(): void {
   this.getCategories();
   this.getSubCategories();
  }

  createSubCategory(){
    let subCategoryId :number = +this.subcategory.subcategoryId;
    console.log(subCategoryId);
     this.adminService.createSubCategory(this.subcategory).subscribe((res)=> {
       console.log(res);
       this.getSubCategories();
       this.subcategoryResponce = res;
       this.alert = true;
       this.subcategory.subcategoryId = 0;
       this.subcategory.subcategoryName = '';
  
       setTimeout(() => {
          this.alert = false;
       }, 2000);
     })
  }

 public getCategories(){
     this.adminService.getCategories().subscribe((res)=> {
       console.log(res);
       this.subcategory.subcategoryId = 0;
       this.subcategory.subcategoryName = "";
       this.categories = res;
       console.log(this.categories);
     })
  }

  public getSubCategories(){
    this.adminService.getSubCategories().subscribe((res)=> {
      console.log(res);
      this.subCategories = res;
    })
 }

 public deleteSubCategory(subCategoryId:any){
     this.adminService.deleteSubCategory(subCategoryId).subscribe((res)=> {
       console.log(res);
       this.getSubCategories();
     })
 }
}
