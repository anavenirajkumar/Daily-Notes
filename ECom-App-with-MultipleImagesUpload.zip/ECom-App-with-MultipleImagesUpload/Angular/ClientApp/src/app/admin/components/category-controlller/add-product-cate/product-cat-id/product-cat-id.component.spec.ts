import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductCatIdComponent } from './product-cat-id.component';

describe('ProductCatIdComponent', () => {
  let component: ProductCatIdComponent;
  let fixture: ComponentFixture<ProductCatIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductCatIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductCatIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
