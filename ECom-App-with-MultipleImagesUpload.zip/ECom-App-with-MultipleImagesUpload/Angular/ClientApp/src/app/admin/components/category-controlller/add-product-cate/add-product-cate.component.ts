import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/users/interfaces/ICategory';
import { UserService } from 'src/app/users/services/user.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-add-product-cate',
  templateUrl: './add-product-cate.component.html',
  styleUrls: ['./add-product-cate.component.css']
})
export class AddProductCateComponent implements OnInit {

  public product:IProduct = {
    productId : 0,
    productName : '',
    productPrice : 0,
    categoryId : 0,
    subcategoryId : 0,
  }
  public categories:any = {
    message : '',
    categories : []
  }
 public subcategories:any = {
  message : '',
  subCategories : []
 }
 public products:any = {
  message : '',
  products : []
 }
 public filterSubcategories:any;
 public alert:boolean  = false;
 public productResponce:any = {
     message : ''
  }
  constructor(private adminService :UserService) { }

  ngOnInit(): void {
   this.getCategories();
   this.getProducts();
   this.adminService.getSubCategories().subscribe((res)=> {
     this.subcategories.subCategories = res;
     console.log(this.subcategories);
   })
  }

  createProduct(){
    let productId :number = +this.product.productId;
    console.log(productId);

     if(this.product.categoryId != 0 && this.product.subcategoryId != 0 && this.product.productName != '' && this.product.productPrice != 0){
      this.adminService.createProduct(this.product).subscribe((res)=> {
        console.log(res);

        this.product.productId = 0;
        this.product.productName = '';
        this.product.productPrice = 0;
        this.product.categoryId = 0;
        this.product.subcategoryId = 0;

        this.productResponce = res;
        this.alert = true;
        this.getProducts();
        setTimeout(() => {
           this.alert = false;
        }, 2000);
      })
     }
  }

 public getCategories(){
     this.adminService.getCategories().subscribe((res)=> {
       console.log(res);
       this.product.productId = 0;
       this.product.productName = "";
       this.categories = res;
       console.log(this.categories);
     })
  }



  public getProducts(){
     this.adminService.getProducts().subscribe((res)=> {
       console.log(res);
       this.products = res;
     })
  }

  public deleteProduct(productId:any){
    this.adminService.deleteProduct(productId).subscribe((res)=> {
      console.log(res);
      this.getProducts();
    })
  }


public selectState(ID:any){
  console.log(ID)
  let CategoryId:number= +ID;
  console.log(this.subcategories.subCategories);
  // this.filterSubcategories = this.sub.subcategories.subCategories.filter((e:any) => e.categoryId == state.target.value); 
  this.filterSubcategories = _.filter(this.subcategories.subCategories.subCategories , ele => ele.subCategoryId === CategoryId) // with using lodash
  console.log(this.filterSubcategories);
  //console.log(this.city)
}
}
