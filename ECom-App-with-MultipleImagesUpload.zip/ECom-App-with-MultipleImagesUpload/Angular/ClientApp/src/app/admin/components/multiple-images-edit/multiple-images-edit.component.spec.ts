import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MultipleImagesEditComponent } from './multiple-images-edit.component';

describe('MultipleImagesEditComponent', () => {
  let component: MultipleImagesEditComponent;
  let fixture: ComponentFixture<MultipleImagesEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MultipleImagesEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MultipleImagesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
