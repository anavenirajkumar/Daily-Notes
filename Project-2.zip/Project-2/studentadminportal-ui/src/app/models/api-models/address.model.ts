export interface Address {
  id: string,
  physicalAddress: string,
  postalAddress: string
}
