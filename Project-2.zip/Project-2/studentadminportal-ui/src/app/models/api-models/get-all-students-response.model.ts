import { Student } from "./student.model";

export interface GetAllStudentsResponse {
  students: Student[]
}
