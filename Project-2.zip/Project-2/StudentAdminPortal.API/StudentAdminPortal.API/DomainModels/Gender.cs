﻿using System;

namespace StudentAdminPortal.API.DomainModels
{
    public class Gender
    {
        public Guid Id { get; set; }
        public string Description { get; set; }
    }
}
