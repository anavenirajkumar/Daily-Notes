﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class CountryResponce
    {
        public string Message { get; set; }
        public List<GetCountries> Countries { get; set; }
    }
    public class GetCountries
    {
        public int CountryId { get; set; }
        public string CountryName { get; set; }
    }
    public class StateResponce
    {
        public string Message { get; set; }
        public List<GetStates> States { get; set; }
    }

    public class GetStates
    {

        public int StateId { get; set; }
        public string StateName { get; set; }
        public int CountryId { get; set; }

        public Country Country { get; set; }
    }
    public class CityResponce
    {
        public string Message { get; set; }
        public List<Cities> Cities { get; set; }
    }

    public class Cities
    {
        public int CityId { get; set; }
        public string CityName { get; set; }
        public int StateId { get; set; }

    }
    public class MandalResponce
    {
        public string Message { get; set; }
        public List<Mandals> Mandals { get; set; }
    }

    public class Mandals
    {
        public int MandalId { get; set; }
        public string MandalName { get; set; }
        public int CityId { get; set; }

    }

    public class VillageResponce
    {
        public string Message { get; set; }
        public List<Villages> Villages { get; set; }
    }

    public class Villages
    {
        public int VillageId { get; set; }
        public string VillageName { get; set; }
        public int MandalId { get; set; }

    }
}
