﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadFileController : ControllerBase
    {

        public readonly IUploadFile _uploadFileDL;
        private readonly string AppDirectory = Path.Combine(Directory.GetCurrentDirectory(), "Resources");
        public UploadFileController(IUploadFile uploadFile)
        {
            _uploadFileDL = uploadFile;
        }

        [HttpPost("UploadExcelFile")]
        [AllowAnonymous]

        public async Task<IActionResult> UploadExcelFile([FromForm] UploadXMLFile request)
        {

            UploadXMLFileResponse response = new UploadXMLFileResponse();
            string path = "UploadFileFolder/"+request.File.FileName;
            try
            {

                using (FileStream stream = new FileStream(path, FileMode.CreateNew))
                {
                    await request.File.CopyToAsync(stream);
                }

                response = await _uploadFileDL.UploadXMLFile(request, path);

                string[] files = Directory.GetFiles("UploadFileFolder/"); // Get Files and Deleting Existing Files
                foreach (string file in files)
                {
                    System.IO.File.Delete(file);
                    Console.WriteLine($"{file} is deleted.");
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;

            }

            return Ok(response);
        }

        [HttpPost("UploadCSVFile")]
        [AllowAnonymous]

        public async Task<IActionResult> UploadCSVFile([FromForm] UploadCSVFileRequest request)
        {
            UploadCSVFileResponse response = new UploadCSVFileResponse();
            string path = "UploadFileFolder/" + request.File.FileName;
            try
            {

                using (FileStream stream = new FileStream(path, FileMode.CreateNew))
                {
                    await request.File.CopyToAsync(stream);
                }

                response = await _uploadFileDL.UploadCSVFile(request, path);

                string[] files = Directory.GetFiles("UploadFileFolder/");
                foreach (string file in files)
                {
                    System.IO.File.Delete(file);
                    Console.WriteLine($"{file} is deleted.");
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;

            }

            return Ok(response);
        }

        [HttpPost("ReadRecord")]
        [AllowAnonymous]

        public async Task<IActionResult> ReadRecord(ReadRecordRequest request)
        {
            ReadRecordResponse response = new ReadRecordResponse();

            try
            {
                response = await _uploadFileDL.ReadRecord(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpGet("ReadRecords")]
        [AllowAnonymous]
        public async Task<IActionResult> ReadRecords()
        {
            ReadRecordResponse response = new ReadRecordResponse();

            try
            {
                response = await _uploadFileDL.ReadRecords();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }
        /*  [HttpDelete]
          [AllowAnonymous]
          public async Task<IActionResult> DeleteRecord(DeleteRecordRequest request)
          {
              DeleteRecordResponse response = new DeleteRecordResponse();

              try
              {
                  response = await _uploadFileDL.DeleteRecord(request);
              }
              catch (Exception ex)
              {
                  response.IsSuccess = false;
                  response.Message = ex.Message;
              }

              return Ok(response);
          }*/


        [HttpGet("GetByIdRecord/{id}")]
        [AllowAnonymous]
        public async Task<ReadRecord> GetByIdRecord(int id) // Get Id by Category;
        {
            ReadRecord response = new ReadRecord();
            try
            {
                response = await _uploadFileDL.GetIdByRecord(id);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                throw;
            }

            return response;
        }


        [HttpDelete("DeleteRecord")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteRecord(int recordId) // Delete Record by ID
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            try
            {
                response = await _uploadFileDL.DeletebyId(recordId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPut("UpdateRecord")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateRecord(ReadRecord record) // Update Category;
        {
            ReadRecord response = new ReadRecord();
            try
            {
                response = await _uploadFileDL.UpdateRecord(record);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                throw;
            }

            return Ok(response);
        }


        [HttpPost("UploadTestFile")]
        [AllowAnonymous]
        public async Task<IActionResult> UploadTestFile(IFormFile file) // learn byte[]
        {

            byte[] fileBytes;
            // Convert File to Byte[]
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                 fileBytes = ms.ToArray();
            }



            //  How to Converting a File into Byte[] when the user is uploading a File
            List<string> bytestoFile = new List<string>();
            foreach (var b in fileBytes)
            {
                var item = System.Text.Encoding.ASCII.GetString(new[] { b }); // How To Convert a Single Byte to a String
                bytestoFile.Add(item);
            }


            // Download Byte[] Image File
            var imageFile = await GetFile(fileBytes);


            // text to byte[]
            using (var ms = new MemoryStream())
            {
                string test = "Rajkumar";
                byte[] testBytes = Encoding.ASCII.GetBytes(test);

                // byte[] to text
                string result = System.Text.Encoding.UTF8.GetString(testBytes);
            }

            

            // Object to byte[] and Serialize the Object
            Category obj = new Category();
            obj.CategoryId = 1;
            obj.CategoryName = "Test";

            // Serialize the Object
            var objString = JsonSerializer.Serialize(obj); // Object to byte[] 

            // Serializing Object to Deserialize
            Category objtoDeserialize = JsonSerializer.Deserialize<Category>(objString);

            // Convert Object to byte[]
            byte[] jsonUtf8Bytes = JsonSerializer.SerializeToUtf8Bytes(obj); // Serialized the Object


            // Convert a Single Byte to a String
            List<string> bytestoString = new List<string>();
            foreach (var b in jsonUtf8Bytes) {
                var item = System.Text.Encoding.ASCII.GetString(new[] { b }); // How To Convert a Single Byte to a String
                bytestoString.Add(item);
            }


            return imageFile;
        }


        private async Task<IActionResult> GetFile(byte[] fileBytes)
        {
            //return File(fileBytes, "image/png"); // for showing the image
            return File(fileBytes, "image/png", "Download"); // for downloading the image
        }



        // download Image based on Id
        [HttpGet("downloadImage/{id}")]
        public async Task<IActionResult> DownloadFile(int id)
        {
            // https://github.com/Nehanthworld/AngularFileUploadWithWebAPI/blob/master/WebAPI/fileManager/Controllers/FileManagerController.cs
          
            if (!Directory.Exists(AppDirectory))
                Directory.CreateDirectory(AppDirectory);
            string file = "pieCharts3D.jpg";
            var path = Path.Combine(AppDirectory, file);

            var memory = new MemoryStream();
            using (var stream = new FileStream(path, FileMode.Open))
            {
                await stream.CopyToAsync(memory);
            }
            memory.Position = 0;
            var contentType = "APPLICATION/octet-stream";
            var fileName = Path.GetFileName(path);

            return File(memory, contentType, fileName);
        }


        [HttpPost("Base64toImage")]
        public async Task<IActionResult> Base64ToImage(string base64, string imageName)
        {
            return null;
        }

       

    }
}
