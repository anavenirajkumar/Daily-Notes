﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.DTOS;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        public readonly ICategory _category;
        public CategoryController(ICategory category)
        {
            _category = category;
        }

        [HttpPost("AddCategory")]
        [AllowAnonymous]

        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddCategory(Category category) // Create Category
        {
            CategoryResponce response = new CategoryResponce();
            try
            {
                response = await _category.Category(category);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpPost("AddSubCategory")]
        [AllowAnonymous]
        public async Task<IActionResult> AddSubCategory(SubCategory subcategory) // Create SubCategory
        {
            SubCategoryResponce response = new SubCategoryResponce();
            try
            {
                response = await _category.SubCategory(subcategory);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("GetCategories")]
        [AllowAnonymous]
        public async Task<IActionResult> GetCategories() // Get Categories
        {
            CategoryResponce response = new CategoryResponce();
            try
            {
                response = await _category.GetCategories();
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("GetSubCategories")]
        [AllowAnonymous]
        public async Task<IActionResult> GetSubCategories() // Get All GetSubCategories
        {
            SubCategoryResponce response = new SubCategoryResponce();
            try
            {
                response = await _category.GetSubCategories();
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpGet("GetCategory/{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetCategory(int categoryId) // Get Id by Category;
        {
            CategoryResponce response = new CategoryResponce();
            try
            {
                response = await _category.GetCategory(categoryId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("GetSubCategory/{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetSubCategory(int subcategoryId) // Get Id by SubCategory;
        {
            SubCategoryResponce response = new SubCategoryResponce();
            try
            {
                response = await _category.GetSubCategory(subcategoryId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPut("UpdateCategory")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateCategory(Category category) // Update Category;
        {
            CategoryResponce response = new CategoryResponce();
            try
            {
                response = await _category.UpdateCategory(category);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPut("UpdateSubCategory")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateSubCategory(SubCategory subcategory) // Update SubCategory;
        {
            SubCategoryResponce response = new SubCategoryResponce();
            try
            {
                response = await _category.UpdateSubCategory(subcategory);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpDelete("DeleteCategory/{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteCategory(int categoryId) // Delete Id by Category;
        {
            CategoryResponce response = new CategoryResponce();
            try
            {
                response = await _category.DeleteCategory(categoryId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpDelete("DeleteSubCategory/{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteSubCategory(int subcategoryId) // Delete Id by SubCategory;
        {
            SubCategoryResponce response = new SubCategoryResponce();
            try
            {
                response = await _category.DeleteSubCategory(subcategoryId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("GetProducts")]
        [AllowAnonymous]
        public async Task<IActionResult> GetProducts() // Get All Users Information
        {
            DTOS.CategoryProductResponce response = new DTOS.CategoryProductResponce();
            try
            {
                response = await _category.GetProducts();
            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("GetProduct/{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetProduct(int productId) // Get Id by Product;
        {
            DTOS.CategoryProductResponce response = new DTOS.CategoryProductResponce();
            try
            {
                response = await _category.GetProduct(productId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPut("UpdateProduct")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateProduct(CategoryProduct product) // Update Product;
        {
            DTOS.CategoryProductResponce response = new DTOS.CategoryProductResponce();
            try
            {
                response = await _category.UpdateProduct(product);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPost("AddProduct")]
        [AllowAnonymous]
        public async Task<IActionResult> AddProduct(CategoryProduct product) // Create Product
        {
            DTOS.CategoryProductResponce response = new DTOS.CategoryProductResponce();
            try
            {
                response = await _category.Product(product);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpDelete("DeleteProduct/{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteProduct(int productId) // Delete Id by Product;
        {
            DTOS.CategoryProductResponce response = new DTOS.CategoryProductResponce();
            try
            {
                response = await _category.DeleteProduct(productId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }
    }
}
