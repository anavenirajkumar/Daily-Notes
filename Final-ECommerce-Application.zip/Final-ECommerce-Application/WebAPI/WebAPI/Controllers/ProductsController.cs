﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using WebAPI.Core.Entities;
using WebAPI.Core.Specifications;
using WebAPI.Interfaces;
using System.Drawing;
using System.IO;
using System.Net;
using Microsoft.AspNetCore.Authorization;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        public IProductRepository _repo { get; set; } // must public

        public ProductsController(
            IProductRepository repo
            )
        {
            _repo = repo;
        }

        // Brands
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpPost("AddBrand")]
        public async Task<bool> AddBrand(ProductBrand modal)
        {
            var result = await _repo.AddBrand(modal);
            return result;
        }
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpGet("brand/{id}")]

        public async Task<ProductBrandResponce> GetBrand(int id)
        {
            var item = await _repo.GetBrand(id);
            if (item == null)
            {
                return null;
            }
            return item;
        }

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpPut("UpdateBrand")]

        public async Task<bool> PutBrand(ProductBrand modal)
        {
            var brand = await _repo.UpdateBrand(modal);
            return brand;
        }

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpDelete("DeleteBrand/{id}")]

        public async Task<bool> DeleteBrand(int id)
        {
            var brand = await _repo.DeleteBrand(id);
            return brand;

        }

        [HttpGet("GetBrands")]
        public async Task<List<ProductBrandResponce>> GetBrands()
        {
            var products = await _repo.GetBrands();
            return products;
        }

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpPost("AddCategory")]
        public async Task<bool> AddType(ProductType modal)
        {
            var result  =  await _repo.AddType(modal);
            return result;
        }

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpGet("Category/{id}")]
        public async Task<ProductTypeResponce> GetType(int id)
        {
            var item = await _repo.GetType(id);
            if (item == null)
            {
                return null;
            }
            return item;
        }


        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpPut("UpdateCategory")]
        public async Task<bool> PutType(ProductType modal)
        {
            var brand = await _repo.UpdateType(modal);
            return brand;
        }

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpDelete("DeleteCategory/{id}")]
        public async Task<bool> DeleteType(int id)
        {
            var brand = await _repo.DeleteType(id);
            return brand;
        }

        [HttpGet("GetCategories")]
        public async Task<List<ProductTypeResponce>> GetTypes()
        {
            var products = await _repo.GetTypes();
            return products;
        }



        [HttpGet("GetProduct/{id}")]
        public async Task<GetProductResponce> GetProductById(int id)
        {
            var products = await _repo.GetProductByIdAsync(id);
            return products;
        }


        [HttpGet("DownloadImage/{id}")]
        public async Task<ActionResult> GetDownloadProductById(int id)
        {
            var products = await _repo.DownloadProductImage(id);
            byte[] imageBytes = Encoding.ASCII.GetBytes(products.PictureUrl);
            return File(imageBytes, "image/jpeg", "download"); // for downloading the image
        }



        [HttpGet]

        //  public async Task<ActionResult<IReadOnlyList<ProductToReturnDto>>> GetProducts(string sort, int? brandId, int ? typeId)
        // sort for 'Products' Assending and Dessending -> https://localhost:44358/api/products?sort=priceAsc or priceDsc
        // Filter for 'Brands' -> https://localhost:44358/api/products?brandId=2
        // Filter for 'TypeId' -> https://localhost:44358/api/products?typeId=2&brandId=2
        // Filter using 'Brands' and 'TypeId' -> https://localhost:44358/api/products?typeId=2
        // Pagination -> https://localhost:44358/api/products?pageSize=3&pageIndex=1 or pageSize=6&pageIndex=2
        // Pagination -> https://localhost:44358/api/products?typeId=2&brandId=2&sort=priceDsc&pageIndex=1&pageSize=2
        // Search Functionality ->  https://localhost:44358/api/products?search=iphone&sort=priceDsc

        // public async Task<ActionResult<Pagination<ProductResponce>>> GetProducts([FromQuery] ProductSpecParams productParams)
        public async Task<List<Products>> GetProducts()
        {
            /*            var spec = new ProductsWithTypesAndBrandsSpecification(productParams); // example 3 using AutoMapper
                        var countSpec = new ProductsWithFiltersForCountSpecification(productParams); // for Pagination
                        var products = await _repo.GetProductsAsync();
                        var totalItems = products.Count;
                        var data = _mapper.Map<IReadOnlyList<ProductResponce>>(products);

                        return Ok(new Pagination<ProductResponce>(productParams.PageIndex,
                            productParams.PageSize, totalItems, data));*/
            var products = await _repo.GetProductsAsync();
            return products;
        }

        /* [HttpGet("{id}")]

         public async Task<ActionResult<ProductResponce>> GetProduct(int id) //<Product> example 1
         {
             var spec = new ProductsWithTypesAndBrandsSpecification(id); // example 1
             return await _productRepo.GetEntityWithSpec(spec);

             var spec = new ProductsWithTypesAndBrandsSpecification(id); // example 2 with DTOS
             var product = await _productRepo.GetEntityWithSpec(spec);
             return new ProductToReturnDto // using DTO Return Product Responce Format
             {
                 Id = product.Id,
                 Name = product.Name,
                 Description = product.Description,
                 PictureUrl = product.PictureUrl,
                 Price = product.Price,
                 ProductBrand = product.ProductBrand.Name,
                 ProductType = product.ProductType.Name
             };

             var spec = new ProductsWithTypesAndBrandsSpecification(id); // example 3 AutoMapper
             var product = await _productRepo.GetEntityWithSpec(spec);
             if (product == null) return NotFound(new ApiResponse(404)); // for Error Handling
             return _mapper.Map<Product, ProductToReturnDto>(product);

         }*/

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpPost("AddProduct")]

        public async Task<bool> AddProduct(Product modal)
        {
            var result =  await _repo.AddProduct(modal);
            return result;
        }

        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpPut("UpdateProduct")]

        public async Task<bool> UpdateProduct(Product modal)
        {
            var brand = await _repo.UpdateProduct(modal);
            return brand;
        }
        [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin")]
        [HttpDelete("DeleteProduct/{id}")]

        public async Task<bool> DeleteProduct(int id)
        {
            var product = await _repo.DeleteProduct(id);
            return product;

        }

        // Using with Query Params
        //[Route("GetProductsWithPage/{PageNumber?}/{NumberOfRecordPerPage?}/{SortBy?}/{SearchName?}/{BrandId?}/{TypeId?}")]
        [Route("GetProductsWithPage")]
        [HttpGet]
        public async Task<GetNoteResponse> GetProductsWithQueryParams([FromQuery] int pageNumber, [FromQuery] int numberOfRecordPerPage, [FromQuery] string sortBy, [FromQuery] string searchName, [FromQuery] int brandId, [FromQuery] int TypeId)
        {
            GetNoteResponse response = new GetNoteResponse();
            try
            {
                response = await _repo.GetProductsWithQueryParams(pageNumber,numberOfRecordPerPage,sortBy,searchName,brandId, TypeId);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;
            }

            return response;
        }


        [HttpPost("GetProductsWithPage")]
        public async Task<GetNoteResponse> GetProductsWithPage(GetProducts request)
        {
            GetNoteResponse response = new GetNoteResponse();
            try
            {
                response = await _repo.GetProducts(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;
            }

            return response;
        }

        /* [HttpPost("SearchProducts")]
        public async Task<GetNoteResponse> SearchProducts(GetSearchNoteRequest request) {
            GetNoteResponse response = new GetNoteResponse();
            try
            {
                response = await _repo.SearchProducts(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;
            }

            return response;
        }*/
    }
}
