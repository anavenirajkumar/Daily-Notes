﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;

namespace WebAPI.Interfaces
{
    public interface IProductRepository
    {
        // brands
        Task<bool> AddBrand(ProductBrand request);
        Task<ProductBrandResponce> GetBrand(int id);
        Task<bool> UpdateBrand(ProductBrand request);
        Task<bool> DeleteBrand(int brandId);
        Task<List<ProductBrandResponce>> GetBrands();

        // types
        Task<bool> AddType(ProductType request);
        Task<ProductTypeResponce> GetType(int id);
        Task<bool> UpdateType(ProductType request);
        Task<bool> DeleteType(int brandId);
        Task<List<ProductTypeResponce>> GetTypes();

        // Products
        Task<bool> AddProduct(Product request);
        Task<bool> UpdateProduct(Product request);
        Task<bool> DeleteProduct(int productId);


        Task<GetProductResponce> GetProductByIdAsync(int id);

        Task<DownloadImage> DownloadProductImage(int id); // download image


        Task<List<Products>> GetProductsAsync();
        //Task<IReadOnlyList<ProductResponce>> GetProductBrandsAsync();
        //Task<IReadOnlyList<ProductType>> GetProductTypesAsync();

        public Task<GetNoteResponse> GetProducts(GetProducts request);

        public Task<GetNoteResponse> SearchProducts(GetSearchNoteRequest request);

        public Task<GetNoteResponse> GetProductsWithQueryParams(int pageNumber, int numberOfRecordPerPage, string sortBy, string searchName, int brandId, int TypeId);
        

    }
}
