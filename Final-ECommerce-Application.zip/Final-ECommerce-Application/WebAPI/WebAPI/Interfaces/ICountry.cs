﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface ICountry
    {
         Task<CountryResponce> Country(Country country);
         Task<StateResponce> State(State state);
         Task<CityResponce> City(City city);
         Task<MandalResponce> Mandal(Mandal mandal);
         Task<VillageResponce> Village(Village village);

        // Get Data
         Task<CountryResponce> GetCountries();
         Task<StateResponce> CountryId(int CountryID);
         Task<CityResponce> StateId(int StateId);
         Task<MandalResponce> CityId(int CityId);
         Task<VillageResponce> MandalId(int MandalId);
    }
}
