﻿using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using OfficeOpenXml.Core.ExcelPackage;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;
using OfficeOpenXml;
using System.Drawing;
using OfficeOpenXml.Style;
using WebAPI.Core.Entities;

namespace WebAPI.Services
{
    public class UserService : IUser
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        public UserService(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);
        }

        // Register User
        public async Task<RegisterUserResponse> RegisterUser(RegisterUser request)
        {


            RegisterUserResponse response = new RegisterUserResponse();
            response.IsSuccess = true;
            response.Message = "SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (request.Password != request.ConfirmPassword)
                {
                    response.IsSuccess = false;
                    response.Message = "Password Not Match";
                    return response;
                }

                // Check Register Email is Already Exist Query
                string Sql = @"SELECT Email  
                                    FROM registerUser
                                    WHERE Email=@Email";

                string alreadyEmail; //

                UserLoginResponse responseUser = new UserLoginResponse();

                using (SqlCommand sqlCommand = new SqlCommand(Sql, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            responseUser.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                            alreadyEmail = responseUser.Email; //
                            response.IsSuccess = false;
                            response.Message = "User Is Already Registered";

                        }
                        else
                        {
                            alreadyEmail = null;
                        }
                    }

                }


                if (alreadyEmail == null) // if null Create New Register User
                {
                    request.Password = BCrypt.Net.BCrypt.HashPassword(request.Password);

                    string SqlQuery = @"INSERT INTO  registerUser 
                                    (UserName, PassWord, Role, Email) Values 
                                    (@UserName, @PassWord, @Role, @Email);";

                    using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                    {
                        sqlCommand.CommandType = System.Data.CommandType.Text;
                        sqlCommand.CommandTimeout = 180;
                        sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                        sqlCommand.Parameters.AddWithValue("@PassWord", request.Password);
                        sqlCommand.Parameters.AddWithValue("@Role", request.Role);
                        sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                        int Status = await sqlCommand.ExecuteNonQueryAsync();
                        if (Status <= 0)
                        {
                            response.IsSuccess = false;
                            response.Message = "Register Query Not Executed";
                            return response;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Login User
        public async Task<UserLoginResponse> UserLogin(UserLoginRequest request)
        {
            /* UserLoginResponse response = new UserLoginResponse();
             response.IsSuccess = true;
             response.Message = "Login SuccessFul";
             DateTime lastLoginTime = DateTime.Now;  // lastLogin Time
             try
             {
                 if (_SqlConnection.State != System.Data.ConnectionState.Open)
                 {
                     await _SqlConnection.OpenAsync();
                     var user = await _SqlConnection.QuerySingleAsync<GetInfoByEmail>(@"SELECT * FROM registerUser WHERE Email= @Email", request);
                     lastLoginTime = user.LastLogin == null ? DateTime.Now : (DateTime)user.LastLogin;
                     request.LastLogin = DateTime.Now; // PresentLogin Time
                     var count = await _SqlConnection.ExecuteAsync(@"UPDATE [dbo].[registerUser] SET [LastLogin] = @LastLogin WHERE [Email] = @Email", request);
                     if(count > 0) {
                         Console.WriteLine("User Login Time Updated");
                     }
                 }

                 string SqlQuery = @"SELECT UserId, UserName, Role, Village, Mandal, District, Email, Password
                                     FROM registerUser
                                     WHERE Email=@Email";

                 using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                 {
                     sqlCommand.CommandType = System.Data.CommandType.Text;
                     sqlCommand.CommandTimeout = 180;
                     sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                     sqlCommand.Parameters.AddWithValue("@PassWord", request.Password);
                     using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                     {
                         if (dataReader.HasRows)
                         {
                             await dataReader.ReadAsync();
                             response.Message = "Login Successful";
                             *//*                            response.data = new UserLoginInformation();
                             *//*
                             response.UserID = dataReader["UserId"] != DBNull.Value ? Convert.ToString(dataReader["UserId"]) : string.Empty;
                             response.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                             response.Role = dataReader["Role"] != DBNull.Value ? Convert.ToString(dataReader["Role"]) : string.Empty;
                             response.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                             response.Password = dataReader["Password"] != DBNull.Value ? Convert.ToString(dataReader["Password"]) : string.Empty;
                             response.Village = dataReader["Village"] != DBNull.Value ? Convert.ToString(dataReader["Village"]) : string.Empty;
                             response.Mandal = dataReader["Mandal"] != DBNull.Value ? Convert.ToString(dataReader["Mandal"]) : string.Empty;
                             response.District = dataReader["District"] != DBNull.Value ? Convert.ToString(dataReader["District"]) : string.Empty;
                             // response.LastLogin = request.LastLogin;
                             response.LastLogin = lastLoginTime;
                             response.Cart = new List<ProductOrder>();
                             bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, response.Password);
                             if (isValidPassword)
                             {
                                 response.Token = GenerateJwt(response.UserID, response.UserName, response.Role);
                                 return response;
                             }
                             else
                             {
                                 response = null;
                             }
                         }
                         else
                         {
                             response.IsSuccess = false;
                             response.Message = "Login Unsuccessful";
                             return response;
                         }
                     }

                 }
             }
             catch (Exception ex)
             {
                 response.IsSuccess = false;
                 response.Message = ex.Message;
             }
             finally
             {
                 await _SqlConnection.CloseAsync();
                 await _SqlConnection.DisposeAsync();
             }

             return response;*/
            UserLoginResponse response = new UserLoginResponse();
            DateTime lastLoginTime = DateTime.Now;  // lastLogin Time
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var user = await _SqlConnection.QuerySingleAsync<GetInfoByEmail>(@"SELECT * FROM registerUser WHERE Email= @Email", request);
                    bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, user.Password);
                    if (isValidPassword)
                    {
                        lastLoginTime = user.LastLogin == null ? DateTime.Now : (DateTime)user.LastLogin;
                        request.LastLogin = DateTime.Now; // PresentLogin Time
                        var count = await _SqlConnection.ExecuteAsync(@"UPDATE [dbo].[registerUser] SET [LastLogin] = @LastLogin WHERE [Email] = @Email", request);
                        if (count > 0)
                        {
                            Console.WriteLine("User Login Time Updated");
                        }
                        response = await _SqlConnection.QuerySingleAsync<UserLoginResponse>(@"SELECT UserId, UserName, Role, Village, 
                            Mandal, District, Email, Password, MobileNumber, ProfileName FROM registerUser WHERE Email=@Email", new { Email = request.Email });
                        string profilePath = "https://localhost:44393/Resources/User/Images/";
                        response.ProfileName = profilePath + response.ProfileName;
                        response.LastLogin = lastLoginTime;
                        response.Cart = new List<ProductOrder>();
                        response.IsSuccess = true;
                        response.Message = "Login Successfully";
                        response.Token = GenerateJwt(response.UserID, response.Email, response.Role);
                        if (response.Role.Equals("Admin"))
                        {
                            response.Roles = new List<string> { "Admin", "Owner", "SuperAdmin", "User" };
                        }
                        else
                        {
                            response.Roles = new List<string> { "User" };
                        }
                        // Get Roles from Database Logic
                        /* string Roles = "A, B, C, D";
                         string[] userRoles = Roles.Split(new Char[] { ',' });
                         foreach (string role in userRoles)
                         {
                             Console.WriteLine(role);
                         }*/
                        //return response;
                    }
                    else
                    {
                        return null;
                    }
                    /* var user = await _SqlConnection.QuerySingleAsync<GetInfoByEmail>(@"SELECT * FROM registerUser WHERE Email= @Email", request);
                     if (user.Email.Equals(request.Email)) {
                          response.Message = "Email is Already Exist";
                          //return response;
                     }
                     else {
                         var user = await _SqlConnection.QuerySingleAsync<GetInfoByEmail>(@"SELECT * FROM registerUser WHERE Email= @Email", request);
                         bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, response.Password);
                         if (isValidPassword)
                         {
                             lastLoginTime = user.LastLogin == null ? DateTime.Now : (DateTime)user.LastLogin;
                             request.LastLogin = DateTime.Now; // PresentLogin Time
                             var count = await _SqlConnection.ExecuteAsync(@"UPDATE [dbo].[registerUser] SET [LastLogin] = @LastLogin WHERE [Email] = @Email", request);
                             if (count > 0){
                                 Console.WriteLine("User Login Time Updated");
                             }
                             response = await _SqlConnection.QuerySingleAsync<UserLoginResponse>(@"SELECT UserId, UserName, Role, Village, 
                             Mandal, District, Email, Password, MobileNumber FROM registerUser WHERE Email=@Email", new { Email = request.Email });
                             response.LastLogin = lastLoginTime;
                             response.Cart = new List<ProductOrder>();
                             response.IsSuccess = true;
                             response.Message = "Login Successfully";
                             response.Token = GenerateJwt(response.UserID, response.Email, response.Role);
                             if (response.Role.Equals("Admin"))
                             {
                                 response.Roles = new List<string> { "Admin", "Owner", "SuperAdmin", "User" };
                             }
                             else
                             {
                                 response.Roles = new List<string> { "User" };
                             }
                             // Get Roles from Database Logic
                             *//* string Roles = "A, B, C, D";
                              string[] userRoles = Roles.Split(new Char[] { ',' });
                              foreach (string role in userRoles)
                              {
                                  Console.WriteLine(role);
                              }*//*
                             //return response;
                         }
                     }*/

                    return response;
                }
            }
            catch (Exception ex)
            {
      /*        response.IsSuccess = false;
                response.Message = "Login Unsuccessful";*/
            }
            return null;
        }


        public async Task<UserLoginResponse> GetRefreshUser(string email, string userId)
        {
            /* UserLoginResponse response = new UserLoginResponse();
             response.IsSuccess = true;
             response.Message = "Login SuccessFul";
             DateTime lastLoginTime = DateTime.Now;  // lastLogin Time
             try
             {
                 if (_SqlConnection.State != System.Data.ConnectionState.Open)
                 {
                     await _SqlConnection.OpenAsync();

                 }

                 string SqlQuery = @"SELECT UserId, UserName, Role, Village, Mandal, District, Email, Password
                                     FROM registerUser
                                     WHERE Email=@email AND UserId = @userId";

                 using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                 {
                     sqlCommand.CommandType = System.Data.CommandType.Text;
                     sqlCommand.CommandTimeout = 180;
                     sqlCommand.Parameters.AddWithValue("@Email", email);
                     sqlCommand.Parameters.AddWithValue("@UserId", userId);
                     using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                     {
                         if (dataReader.HasRows)
                         {
                             await dataReader.ReadAsync();
                             response.Message = "Get User Successful";
                             response.UserID = dataReader["UserId"] != DBNull.Value ? Convert.ToString(dataReader["UserId"]) : string.Empty;
                             response.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                             response.Role = dataReader["Role"] != DBNull.Value ? Convert.ToString(dataReader["Role"]) : string.Empty;
                             response.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                             response.Password = dataReader["Password"] != DBNull.Value ? Convert.ToString(dataReader["Password"]) : string.Empty;
                             response.Village = dataReader["Village"] != DBNull.Value ? Convert.ToString(dataReader["Village"]) : string.Empty;
                             response.Mandal = dataReader["Mandal"] != DBNull.Value ? Convert.ToString(dataReader["Mandal"]) : string.Empty;
                             response.District = dataReader["District"] != DBNull.Value ? Convert.ToString(dataReader["District"]) : string.Empty;
                             response.LastLogin = lastLoginTime;
                             response.Cart = new List<ProductOrder>();
                         }
                         else
                         {
                             response.IsSuccess = false;
                             response.Message = "Get User Unsuccessful";
                             return null;
                         }
                     }

                 }
             }
             catch (Exception ex)
             {
                 response.IsSuccess = false;
                 response.Message = ex.Message;
             }
             finally
             {
                 await _SqlConnection.CloseAsync();
                 await _SqlConnection.DisposeAsync();
             }

             return response;*/


            UserLoginResponse response = new UserLoginResponse();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    response = await _SqlConnection.QuerySingleAsync<UserLoginResponse>(@"SELECT UserId, UserName, Role, Village, Mandal, District, Email, Password, MobileNumber, ProfileName, LastLogin
                    FROM registerUser WHERE Email=@Email AND UserId = @UserId", new { Email = email, UserId = userId });
                    string profilePath = "https://localhost:44393/Resources/User/Images/";
                    response.ProfileName = profilePath + response.ProfileName;
                    response.IsSuccess = true;
                    response.Message = "Get User Successfully";
                    response.Cart = new List<ProductOrder>();
                    if (response.Role.Equals("Admin"))
                    {
                        response.Roles = new List<string> { "Admin", "Owner", "SuperAdmin", "User" };
                    }
                    else
                    {
                        response.Roles = new List<string> { "User" };
                    }
                }
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
        // Update User Address
        public async Task<bool> UserDetails(UserLoginResponse user)
        {
            /*var UserID = Int16.Parse(user.UserID);
            string UserName = user.UserName;

            UserAddressResponce response = new UserAddressResponce();
            //response.IsSuccess = true;
            response.Message = "Address Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (UserID == null)
                {
                    return null;
                }

                *//* string SqlQuery = @" SELECT UserId from registerUser WHERE UserId=UserId AND INSERT INTO registerUser
                                     (Village, Mandal, District) Values 
                                     (@Village, @Mandal, @District)";*//*

                string SqlQuery = @"UPDATE registerUser SET Village = @Village, Mandal = @Mandal, District = @District, MobileNumber = @MobileNumber WHERE UserId = @UserID";



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserId", UserID);
                    sqlCommand.Parameters.AddWithValue("@Village", user.Village);
                    sqlCommand.Parameters.AddWithValue("@Mandal", user.Mandal);
                    sqlCommand.Parameters.AddWithValue("@District", user.District);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", user.MobileNumber);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.IsSuccess = false;
                        response.Message = "Address Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                //response. = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;*/

            UserAddressResponce response = new UserAddressResponce();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var count = await _SqlConnection.ExecuteAsync(@"UPDATE registerUser SET Village = @Village, Mandal = @Mandal, District = @District, MobileNumber = @MobileNumber WHERE UserId = @UserID", user);
                    if(count > 0) {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;

        }

        // Upload Users
        public async Task<AddInformationResponse> AddInformation(AddInformationRequest request)
        {
            AddInformationResponse response = new AddInformationResponse();
            ///response.IsSuccess = true;
            response.Message = "User Created SuccessFul";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                // Married, DesignationId, uploadedDate, updatedDate
                string SqlQuery = @"INSERT INTO userInformation 
                                    (UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate) Values
                                    (@UserName, @EmailID, @MobileNumber, @Salary, @Gender, @Married, @DesignationId, @uploadedDate, @updatedDate)";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    //UserName, EmailID, MobileNumber, Salary, Gender
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                    sqlCommand.Parameters.AddWithValue("@EmailID", request.EmailID);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", request.MobileNumber);
                    sqlCommand.Parameters.AddWithValue("@Salary", request.Salary);
                    sqlCommand.Parameters.AddWithValue("@Gender", request.Gender);
                    sqlCommand.Parameters.AddWithValue("@Married", request.Marrried);
                    sqlCommand.Parameters.AddWithValue("@DesignationId", request.DesignationId);
                    sqlCommand.Parameters.AddWithValue("@uploadedDate", request.uploadedDate);
                    sqlCommand.Parameters.AddWithValue("@updatedDate", request.updatedDate);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.IsSuccess = false;
                        response.Message = "AddInformation Query Not Executed";
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Get All Users
        public async Task<GetInformationResponse> GetInformation()
        {
            GetInformationResponse response = new GetInformationResponse();
            response.IsSuccess = true;
            response.Message = "SuccessFul";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM userInformation";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.getInformation = new List<GetInformation>();

                            while (await dataReader.ReadAsync())
                            {
                                GetInformation data = new GetInformation();
                                //Married, DesignationId, uploadedDate, updatedDate
                                data.UserId =  Convert.ToInt32(dataReader["UserId"]);
                                data.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                                data.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                                data.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                data.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                                data.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                data.Marrried = dataReader["Married"] != DBNull.Value ? Convert.ToBoolean(dataReader["Married"]) : false;
                                data.DesignationId =  Convert.ToInt32(dataReader["DesignationId"]);
                                data.uploadedDate = dataReader["uploadedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["uploadedDate"]).ToString("dd/MM/yyyy") : null;
                                data.updatedDate = dataReader["updatedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["updatedDate"]).ToString("hh:mm tt") : null;
                                //data.IsActive = dataReader["IsActive"] != DBNull.Value ? Convert.ToBoolean(dataReader["IsActive"]) : false;

                                response.getInformation.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // GET By User ID
        public async Task<GetInformation> GetUserInfo(int id)
        {
            GetInformation response = new GetInformation();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT UserId, UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate FROM userInformation WHERE UserId = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            //response.Message = "Get Brand Successful";
                            response.UserId = Convert.ToInt32(dataReader["UserId"]);
                            response.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                            response.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                            response.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                            response.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                            response.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                            response.Marrried = dataReader["Married"] != DBNull.Value ? Convert.ToBoolean(dataReader["Married"]) : false;
                            response.DesignationId =  Convert.ToInt32(dataReader["DesignationId"]);
                            response.uploadedDate = dataReader["uploadedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["uploadedDate"]).ToString("dd/MM/yyyy") : null;
                            response.updatedDate = dataReader["updatedDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["updatedDate"]).ToString("hh:mm tt") : null;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        // Update User Infomation
        public async Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation request)
        {
            var userId = request.UserId;

            UpdateUserInformation response = new UpdateUserInformation();
            //response.Message = "ProductBrand Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (userId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE userInformation SET UserName = @UserName, EmailID = @EmailID, MobileNumber = @MobileNumber, Salary = @Salary, Gender = @Gender, Married= @Married, DesignationId = @DesignationId, uploadedDate = @uploadedDate, updatedDate = @updatedDate WHERE UserId = " + userId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserId", userId);
                    sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                    sqlCommand.Parameters.AddWithValue("@EmailID", request.EmailID);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", request.MobileNumber);
                    sqlCommand.Parameters.AddWithValue("@Salary", request.Salary);
                    sqlCommand.Parameters.AddWithValue("@Gender", request.Gender);
                    sqlCommand.Parameters.AddWithValue("@Married", request.Married);
                    sqlCommand.Parameters.AddWithValue("@DesignationId", request.DesignationId);
                    sqlCommand.Parameters.AddWithValue("@uploadedDate", request.uploadedDate); // DateTime.Now.ToString("MMMM, dd-MM-yyyy"));
                    sqlCommand.Parameters.AddWithValue("@updatedDate", request.updatedDate); //DateTime.Now.ToString("MMMM, dd-MM-yyyy HH:mm tt"));


                    response.UserId = userId;
                    response.UserName = request.UserName;
                    response.EmailID = request.EmailID;
                    response.MobileNumber = request.MobileNumber;
                    response.Salary = request.Salary;
                    response.Gender = request.Gender;
                    response.Married = request.Married;
                    response.DesignationId = response.DesignationId;
                    response.uploadedDate = request.uploadedDate;
                    response.updatedDate = request.updatedDate;


                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.Message = "Brand Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }


        public async Task<AddUser> AddUser(AddUser request)
        {
            int insertedId = 0;
            //response.IsSuccess = true;
            //response.Message = "User Created SuccessFul";

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {

                    await con.OpenAsync();
                    insertedId = await con.QuerySingleAsync<int>(@"INSERT INTO UserData ( Name, Age, Address, City, Country) VALUES ( @Name, @Age, @Address, @City, @Country)
                    SELECT CAST(SCOPE_IDENTITY() AS INT)", request);
                    request.Id = insertedId;
                    // example 1
                    /*  foreach(var image in request.userImages) {
                         string uploadImageQuery = "";
                         image.Id = insertedId;
                         uploadImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                         await con.ExecuteAsync(uploadImageQuery, image);
                     }*/

                    // example 2
                    request.userImages.ToList().ForEach(e =>
                    {
                        e.Id = insertedId;
                    });
                    await con.ExecuteAsync(@"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)", request.userImages);

                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return request;
        }


        // Get All Users


        // JWT Token Generation
        public string GenerateJwt(string UserID, string Email, string Role)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            //claim is used to add identity to JWT token
            var claims = new[] {
         new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
         new Claim(JwtRegisteredClaimNames.Sid, UserID),
         new Claim(JwtRegisteredClaimNames.Email, Email),
         new Claim(ClaimTypes.Role,Role),
         new Claim("Date", DateTime.Now.ToString()),
         };

            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
              _configuration["Jwt:Audiance"],
              claims,    //null original value
              expires: DateTime.Now.AddMinutes(10), // 1 or 120

              //notBefore:
              signingCredentials: credentials);

            string Data = new JwtSecurityTokenHandler().WriteToken(token); //return access token 
            return Data;
        }

        public async Task<GetUsers> GetUsers()
        {
            GetUsers responce = new GetUsers();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    responce.users = (List<Users>)await con.QueryAsync<Users>(@" SELECT * FROM UserData");
                    responce.userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages");
                    responce.IsSuccess = true;
                    responce.Message = "Get Users Successfully";
                    return responce;
                }
            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
                return null;
            }
        }

        public async Task<GetUser> GetUserById(int id)
        {
            GetUser responce = new GetUser();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    var user = await con.QuerySingleAsync<Users>(@" SELECT * FROM UserData WHERE Id = " + id);
                    responce.Id = user.Id;
                    responce.Name = user.Name;
                    responce.Age = user.Age;
                    responce.Address = user.Address;
                    responce.City = user.City;
                    responce.Country = user.Country;
                    responce.userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages WHERE UserId = " + id);
                    //responce.Message = "Get User Successfully";
                    //responce.Id = user.id;
                    return responce;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<AddUser> UpdateUser(AddUser request)
        {
            //AddUser response = new AddUser();
            //response.IsSuccess = true;
            //response.Message = "User Created SuccessFul";

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    await con.ExecuteAsync(@"UPDATE  [dbo].[UserData] SET [Name] = @Name, [Age] = @Age, [Address] = @Address, [City] = @City, [Country] = @Country WHERE [Id] = @Id", request);
                    var userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages WHERE UserId = @Id", request);
                    foreach (var image in request.userImages) // 2
                    {
                        /* string newImageQuery = "";
                         image.Id = request.Id;
                         newImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                         await con.ExecuteAsync(newImageQuery, image);*/

                        if (userImages.Count > 0)
                        {
                            foreach (var existimage in userImages)
                            {
                                if (existimage.ImageId != image.ImageId && existimage.Name != image.Name)
                                {
                                    string newImageQuery = "";
                                    image.Id = request.Id;
                                    newImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                                    await con.ExecuteAsync(newImageQuery, image);
                                }
                            }
                        }
                        else
                        {
                            string newImageQuery = "";
                            image.Id = request.Id;
                            newImageQuery = @"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)";
                            await con.ExecuteAsync(newImageQuery, image);
                        }

                    }
                    // await con.ExecuteAsync(@"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)", request.Images);

                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return request;
        }

        public async Task<UserAddressResponce> DeleteUserById(int id)
        {
            UserAddressResponce responce = new UserAddressResponce();
            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                await con.OpenAsync();
                try
                {
                    if (id != 0)
                    {
                        await con.ExecuteAsync(@"DELETE FROM UserData WHERE Id = @Id", new { @Id = id });
                    }
                    var userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM UserImages WHERE UserId = " + id);
                    foreach (var del in userImages)
                    {
                        if (del.ImageId != 0)
                        {
                            await con.ExecuteAsync(@"DELETE FROM UserImages WHERE UserId = " + id);
                        }
                    }
                    responce.Message = "Record Successfully Deleted";
                    return responce;
                }
                catch (Exception ex)
                {
                    responce.Message = ex.Message;
                    Console.WriteLine(ex);
                    return responce;
                }
            }
        }

        public async Task<bool> DeleteSpecificImage(int id)
        {
            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                await con.OpenAsync();
                try
                {
                    await con.ExecuteAsync(@"DELETE FROM UserImages WHERE ImageId = " + id);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    return false;
                }
            }
        }

        public async Task<ImageUser> UploadImages(ImageUser request)
        {
            return null;
        }

        public async Task<AddNewUserRequest> AddNewUserRequest(AddNewUserRequest request)
        {
            AddNewUserRequest responce = new AddNewUserRequest();
            {
                int insertedId = 0;
                try
                {
                    using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                    {
                        request.CreatedDate = DateTime.UtcNow;
                        await con.OpenAsync();
                        insertedId = await con.QuerySingleAsync<int>(@"INSERT INTO AddNewUserRequest (Name, Email, MobileNumber, Gender, Married, DateOfJoining, City, Country,CreatedDate, UpdatedDate) 
VALUES (@Name, @Email, @MobileNumber, @Gender, @Married, @DateOfJoining, @City, @Country, @CreatedDate, @UpdatedDate)
                    SELECT CAST(SCOPE_IDENTITY() AS INT)", request);
                        request.UserId = insertedId;

                        request.SelectedFroots.ToList().ForEach(e => {
                            e.UserId = insertedId;
                        });
                        await con.ExecuteAsync(@"INSERT INTO SelectedFroots(Name, Checked, UserId) VALUES ( @Name, @Checked, @UserId)", request.SelectedFroots);

                        await UploadImage(request);
                        request.userImages.ToList().ForEach(e => {
                            e.UserId = insertedId;
                        });
                        await con.ExecuteAsync(@"INSERT INTO Images(ImageName, ImageType, UserId,CreatedDate, LastUpdatedDate) 
                                                 VALUES ( @ImageName, @ImageType, @UserId, @CreatedDate, @LastUpdatedDate)", request.userImages);
                        responce.UserId = insertedId;
                        return responce;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
                finally
                {
                    await _SqlConnection.CloseAsync();
                    await _SqlConnection.DisposeAsync();
                }
            }
        }


        private async Task UploadImage(AddNewUserRequest request)
        {
            var validExtensions = new List<string>
            {
               ".jpeg",
               ".png",
               ".gif",
               ".jpg"
            };

            if (request != null && request.Images.Count() > 0)
            {
                /*   foreach (var userImage in request.userImages)  {
                       foreach (var image in request.Images)
                       {
                           var extension = Path.GetExtension(image.FileName);
                           if (validExtensions.Contains(extension))
                           {
                               // var fileName = Guid.NewGuid() + Path.GetExtension(profileImage.FileName); -> images/5w6ww7w8w6189w7e8w96753426.jpg
                               var fileName = image.FileName; // -> saving with name -> images/developer.jpg
                               var fileImagePath = await Upload(image, fileName);
                               userImage.ImageName = fileImagePath;
                               userImage.ImageType = extension;
                           }
                       }
                   }*/


                foreach (var image in request.Images)
                {
                    var extension = Path.GetExtension(image.FileName);
                    if (validExtensions.Contains(extension))
                    {
                        var fileName = image.FileName;
                        await Upload(image, fileName);
                    }
                }
            }
        }


        private async Task<string> Upload(IFormFile file, string fileName)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), @"Resources\Images", fileName);
            using Stream fileStream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(fileStream);
            return Path.Combine(@"Resources\Images", fileName);
            // return GetServerRelativePath(fileName);
        }


        /* private string GetServerRelativePath(string fileName) {
             return Path.Combine(@"Resources\Images", fileName);
         }*/


        public async Task<AddNewUserRequest> UpdateNewUserRequest(AddNewUserRequest request)
        {

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    request.UpdatedDate = DateTime.UtcNow;
                    await con.OpenAsync();
                    await con.ExecuteAsync(@"UPDATE  [dbo].[AddNewUserRequest] SET [Name] = @Name, [Email] = @Email, [MobileNumber] = @MobileNumber, [Gender] = @Gender, [Married] = @Married, [DateOfJoining] = @DateOfJoining, [City]= @City, [Country]= @Country, [UpdatedDate]= @UpdatedDate WHERE [UserId] = @UserId", request);
                    // var userImages = (List<UserImages>)await con.QueryAsync<UserImages>(@"SELECT * FROM Images WHERE UserId = @UserId", request);
                    var selectedFroots = (List<Froots>)await con.QueryAsync<Froots>(@"SELECT * FROM SelectedFroots WHERE UserId = @UserId", request);

                    /* foreach (var image in request.userImages) // 2
                     {
                         if (userImages.Count > 0)
                         {
                             foreach (var existimage in userImages)
                             {
                                 if (existimage.Name != image.ImageName)
                                 {
                                     await UploadImage(request);
                                     string newImageQuery = "";
                                     image.UserId = request.UserId;
                                     newImageQuery = @"INSERT INTO Images(ImageName, ImageType,LastUpdatedDate, UserId) VALUES ( @ImageName, @ImageType, @LastUpdatedDate,@UserId)";
                                     await con.ExecuteAsync(newImageQuery, image);
                                 }
                             }
                         }
                         else
                         {
                             string newImageQuery = "";
                             image.UserId = request.UserId;
                             newImageQuery = @"INSERT INTO Images(ImageName, ImageType,LastUpdatedDate, UserId) VALUES ( @ImageName, @ImageType, @LastUpdatedDate,@UserId)";
                             await con.ExecuteAsync(newImageQuery, image);
                         }

                     }*/

                    foreach (var froot in request.SelectedFroots) // 7
                    {
                        if (selectedFroots.Count > 0)
                        {
                            /*  if (froot.UserId == 0){
                                  string newImageQuery = "";
                                  froot.UserId = request.UserId;
                                  newImageQuery = @"INSERT INTO SelectedFroots(Name,Checked, UserId) VALUES ( @Name, @Checked, @UserId)";
                                  await con.ExecuteAsync(newImageQuery, froot);
                              }
                              else {
                              string newImageQuery = "";
                              froot.UserId = request.UserId;
                              // newImageQuery = @"UPDATE INTO SelectedFroots(Name,Checked, UserId) VALUES ( @Name, @Checked, @UserId)";
                              newImageQuery = @"UPDATE  [dbo].[SelectedFroots] SET [Name] = @Name, [Checked] = @Checked, [UserId] = @UserId  WHERE [UserId] = " + froot.UserId;
                              await con.ExecuteAsync(newImageQuery, froot);
                          }*/
                            string newImageQuery = "";
                            //froot.UserId = request.UserId;
                            newImageQuery = @"UPDATE  [dbo].[SelectedFroots] SET [Name] = @Name, [Checked] = @Checked, [UserId] = @UserId  WHERE [Id] = " + froot.Id;
                            await con.ExecuteAsync(newImageQuery, froot);
                        }
                        else
                        {
                            string newImageQuery = "";
                            froot.UserId = request.UserId;
                            newImageQuery = @"INSERT INTO SelectedFroots(Name,Checked, UserId) VALUES ( @Name, @Checked, @UserId)";
                            await con.ExecuteAsync(newImageQuery, froot);
                        }

                    }

                    /*  if(selectedFroots.Count > 0) { 
                          foreach(var existFroot in selectedFroots) { 
                              //var check = await removeExistFroot(existFroot);
                              *//* foreach(var froot in request.SelectedFroots) { 
                                    if(existFroot.Name != froot.Name) {
                                      string newImageQuery = "";
                                      froot.UserId = request.UserId;
                                      newImageQuery = @"INSERT INTO SelectedFroots(Name,Checked, UserId) VALUES ( @Name, @Checked, @UserId)";
                                      await con.ExecuteAsync(newImageQuery, froot);
                                  }
                              }*//*
                          }
                      }*/
                    // await con.ExecuteAsync(@"INSERT INTO UserImages(Name, Image, UserId) VALUES ( @Name, @Image, @Id)", request.Images);

                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return request;
        }
        public async Task<IEnumerable<GetNewUsers>> GetNewUsers()
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    var users = await con.QueryAsync<GetNewUsers>(@"SELECT * FROM AddNewUserRequest");
                    return users;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<GetNewUsers> GetNewUserById(int UserId)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                    var user = await con.QuerySingleAsync<GetNewUsers>(@"SELECT * FROM AddNewUserRequest WHERE UserId = @UserId", new { UserId = UserId });
                    if (user != null)
                    {
                        user.SelectedFroots = (List<Froots>)await con.QueryAsync<Froots>(@"SELECT * FROM SelectedFroots WHERE UserId = " + UserId);
                        user.userImages = (List<UserImage>)await con.QueryAsync<UserImage>(@"SELECT * FROM Images WHERE UserId = " + UserId);
                    }
                    return user;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<bool> DeleteNewUserById(int id)
        {
            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                await con.OpenAsync();
                try
                {
                    if (id != 0)
                    {
                        var images = (List<UserImage>)await con.QueryAsync<UserImage>(@"SELECT * FROM Images WHERE UserId = " + id);
                        string[] files = Directory.GetFiles("Resources/Images/"); // Get Files and Deleting Existing Files
                        if (files.Length > 0)
                        {
                            foreach (string file in files)
                            {
                                foreach (var removeExistImage in images)
                                {
                                    if (file.Contains(removeExistImage.ImageName))
                                    {
                                        System.IO.File.Delete(file);
                                        Console.WriteLine($"{file} is deleted.");
                                    }
                                }
                            }
                        }
                        await con.ExecuteAsync(@"DELETE FROM AddNewUserRequest WHERE UserId = @Id", new { @Id = id });
                        await con.ExecuteAsync(@"DELETE FROM SelectedFroots WHERE UserId = " + id);
                        await con.ExecuteAsync(@"DELETE FROM Images WHERE UserId = " + id);
                        //await con.ExecuteAsync(@"DELETE A FROM AddNewUserRequest A JOIN SelectedFroots S ON A.UserId = S.ProductId JOIN Images I ON A.UserId = I.UserId", new { UserId = id});

                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public async Task<bool> DeleteUserImage(int id)
        {
            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                await con.OpenAsync();
                try
                {
                    var images = (List<UserImage>)await con.QueryAsync<UserImage>(@"SELECT * FROM Images WHERE ImageId = " + id);
                    string[] files = Directory.GetFiles("Resources/Images/"); // Get Files and Deleting Existing Files
                    if (files.Length > 0)
                    {
                        foreach (string file in files)
                        {
                            foreach (var removeExistImage in images)
                            {
                                if (file.Contains(removeExistImage.ImageName))
                                {
                                    System.IO.File.Delete(file);
                                    Console.WriteLine($"{file} is deleted.");
                                }
                            }
                        }
                    }
                    await con.ExecuteAsync(@"DELETE FROM Images WHERE ImageId = " + id);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                    return false;
                }
            }
        }

        public async Task<UpdateUserImages> UpdateImages(UpdateUserImages request)
        {
            UpdateUserImages responce = new UpdateUserImages();
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    request.UpdatedDate = DateTime.UtcNow;
                    await con.OpenAsync();
                    await UpdateUserImage(request);

                    request.userImages.ToList().ForEach(e => {
                        e.UserId = request.UserId;
                    });
                    await con.ExecuteAsync(@"INSERT INTO Images(ImageName, ImageType, UserId,CreatedDate, LastUpdatedDate) 
                                                 VALUES ( @ImageName, @ImageType, @UserId, @CreatedDate, @LastUpdatedDate)", request.userImages);
                    responce.userImages = (List<UserImage>)await con.QueryAsync<UserImage>(@"SELECT * FROM Images WHERE UserId = " + request.UserId);
                    responce.UserId = request.UserId;
                    foreach (var image in request.userImages)
                    {
                        image.LastUpdatedDate = DateTime.UtcNow;
                        image.CreatedDate = DateTime.UtcNow;
                    }
                    return responce;
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
                return null;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
        }

        private async Task UpdateUserImage(UpdateUserImages request)
        {
            var validExtensions = new List<string>
            {
               ".jpeg",
               ".png",
               ".gif",
               ".jpg"
            };

            if (request != null && request.Images.Count() > 0)
            {

                foreach (var image in request.Images)
                {
                    var extension = Path.GetExtension(image.FileName);
                    if (validExtensions.Contains(extension))
                    {
                        var fileName = image.FileName;
                        await UploadUserImages(image, fileName);
                    }
                }
            }
        }


        private async Task<string> UploadUserImages(IFormFile file, string fileName)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), @"Resources\Images", fileName);
            using Stream fileStream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(fileStream);
            return Path.Combine(@"Resources\Images", fileName);
            // return GetServerRelativePath(fileName);
        }

        public async Task<string> LogoutUser(UserLoginResponse user, string Token)
        {
            try
            {
                var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
                var claims = new[] {
                   new Claim(Token, Token),
                };

                var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
                  _configuration["Jwt:Audiance"],
                  claims,
                  expires: DateTime.Now,
                  signingCredentials: credentials);

                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await con.OpenAsync();
                }
                return "Token Expired";
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return "Token Not Expired";
            }
        }

        public async Task<GetInfoByEmail> GetLoggedUser(int userId)
        {
            GetInfoByEmail response = new GetInfoByEmail();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                    response = await _SqlConnection.QuerySingleAsync<GetInfoByEmail>(@"SELECT * FROM registerUser WHERE UserId = " + userId);
                }
                return response;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<OfficeOpenXml.ExcelPackage> GetUsersXMLFile()
        {
            IEnumerable<GetNewUsers> data = await GetNewUsers();
            OfficeOpenXml.ExcelPackage excelFile = new OfficeOpenXml.ExcelPackage();
            OfficeOpenXml.ExcelWorksheet ws = excelFile.Workbook.Worksheets.Add("Users");
            int row = 1;
            int columnCount = 5;

            var columnChar = (char)65;

            ws.Cells[row, 1, row, columnCount].Merge = true;
            ws.Cells[row, 1, row, columnCount].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

            ws.Cells[$"{columnChar}{row++}"].Value = "All Users";

            ws.Cells[$"{columnChar++}{row}"].Value = "User Id";
            ws.Cells[$"{columnChar++}{row}"].Value = "User Name";
            ws.Cells[$"{columnChar++}{row}"].Value = "MobileNumber";
            ws.Cells[$"{columnChar++}{row}"].Value = "DateOfJoining";
            ws.Cells[$"{columnChar++}{row}"].Value = "Country";

            ws.Cells[1, 1, row, columnCount].Style.Font.Bold = true;
            ws.Cells[1, 1, row, columnCount].Style.Fill.PatternType = ExcelFillStyle.Solid;
            Color headingColor = ColorTranslator.FromHtml("#33579C");
            ws.Cells[1, 1, row, columnCount].Style.Fill.BackgroundColor.SetColor(headingColor);
            ws.Cells[1, 1, row, columnCount].Style.Font.Bold = true;
            ws.Cells[1, 1, row, columnCount].Style.Font.Color.SetColor(Color.White);

            Color itemColor = ColorTranslator.FromHtml("#EEEEEE");
            row++;
            foreach (GetNewUsers a in data)
            {
                ws.Cells["A" + row].Value = a.UserId;
                ws.Cells["B" + row].Value = a.Name;
                ws.Cells["C" + row].Value = a.MobileNumber;
                ws.Cells["D" + row].Value = a.DateOfJoining.ToString();
                ws.Cells["E" + row].Value = a.Country;
                ws.Cells[row, 1, row, columnCount].Style.Fill.PatternType = ExcelFillStyle.Solid;
                if (row % 2 == 0)
                {
                    ws.Cells[row, 1, row, columnCount].Style.Fill.BackgroundColor.SetColor(itemColor);
                }
                else
                {
                    ws.Cells[row, 1, row, columnCount].Style.Fill.BackgroundColor.SetColor(Color.Gainsboro);
                }

                ws.Cells["E" + row].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                row++;
            }

            ws.Cells[row, 1, row, 4].Merge = true;
            ws.Cells[row, 1, row, 4].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Cells["A" + row].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
            ws.Cells["A" + row].Value = "Grand Total";
            ws.Cells["E" + row].Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
            ws.Cells["E" + row].Value = "";

            ws.Cells[1, 1, row, columnCount].Style.Border.Top.Style = ExcelBorderStyle.Thin;
            ws.Cells[1, 1, row, columnCount].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            ws.Cells[1, 1, row, columnCount].Style.Border.Left.Style = ExcelBorderStyle.Thin;
            ws.Cells[1, 1, row, columnCount].Style.Border.Right.Style = ExcelBorderStyle.Thin;
            ws.Cells[1, 1, row, columnCount].AutoFitColumns();
            ws.Cells[1, 1, row, columnCount].Style.Numberformat.Format = "@";

            return excelFile;
        }

        public async Task<int> PlaceUserOrder(UserLoginResponse user)
        {
            try
            {
                using (var con = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]))
                {
                    await _SqlConnection.OpenAsync();
                    var success = await _SqlConnection.ExecuteAsync(@"INSERT INTO UserOrders(ProductName, ProductPrice, MobileNumber, DeliveryAddress, UserId) VALUES
                                                     (@ProductName, @ProductPrice, @MobileNumber, @DeliveryAddress, @UserId)", user, (System.Data.IDbTransaction)user.Cart);
                    return success;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return 0;
            }
        }

        public async Task<List<Order>> GetUserOrders(UserLoginResponse user)
        {
            try
            {
                using (var con = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]))
                {
                    return (List<Order>)await con.QueryAsync(@"select * from UserOrders where UserId = @UserID", new { UserID = user.UserID });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<List<Order>> GetAllOrders(UserLoginResponse user)
        {
            try
            {
                using (var con = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]))
                {
                    return (List<Order>)await con.QueryAsync(@"select * from UserOrders");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<string> UploadUserProfile(int userId, string existProfile, IFormFile profileImage)
        {
            try {
              var validExtensions = new List<string>
              {
               ".jpeg",
               ".png",
               ".gif",
               ".jpg"
              };

                string profilePath = "https://localhost:44393/Resources/User/Images/";
                if (existProfile == null)
                {
                    if (profileImage != null && profileImage.Length > 0)
                    {
                        var extension = Path.GetExtension(profileImage.FileName);
                        if (validExtensions.Contains(extension))
                        {
                            string[] images = profileImage.FileName.Split('.');
                            //var fileName = userId + "." + images[1];
                            var fileName = Guid.NewGuid() + Path.GetExtension(profileImage.FileName);
                            await UploadUserImage(profileImage, fileName);
                            await _SqlConnection.OpenAsync();
                            await _SqlConnection.ExecuteAsync(@"UPDATE registerUser SET ProfileName = @ProfileName WHERE UserId = @UserId", new { ProfileName = fileName, UserId = userId });
                            fileName = profilePath + fileName;
                            return fileName;
                            /*string[] images = userImage.Split(',');
                            return userImage + "." + images[1];*/
                        }
                    }
                }
                else {
                   await DeleteProfile(existProfile);
                   var fileName = Guid.NewGuid() + Path.GetExtension(profileImage.FileName);
                   await UploadUserImage(profileImage, fileName);
                   await _SqlConnection.OpenAsync();
                   await _SqlConnection.ExecuteAsync(@"UPDATE registerUser SET ProfileName = @ProfileName WHERE UserId = @UserId", new { ProfileName = fileName, UserId = userId });
                   fileName = profilePath + fileName;
                   return fileName;
                }
            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
        private async Task<string> UploadUserImage(IFormFile file, string fileName)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), @"Resources\User\Images", fileName);
            using Stream fileStream = new FileStream(filePath, FileMode.Create);
            await file.CopyToAsync(fileStream);
            return Path.Combine(@"Resources\User\Images", fileName);
        }


        private async Task<bool> DeleteProfile(string existProfile)
        {
            try
            {
                string profilePath = "https://localhost:44393/";
                string[] files = Directory.GetFiles("Resources/User/Images/"); // Get Files and Deleting Existing Files
                if (files.Length > 0)
                {
                    foreach (string file in files)
                    {
                        string check = profilePath + file;
                        if (check.Equals(existProfile))
                        {
                            System.IO.File.Delete(file);
                            Console.WriteLine($"{file} is deleted.");
                            return true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        public async Task<string> UpdateUserProfile(string userId, IFormFile userProfile)
        {
            try {
                string[] files = Directory.GetFiles("Resources/User/Images/"); // Get Files and Deleting Existing Files
                if (files.Length > 0)
                {
                    foreach (string file in files)
                    {
                        if (file.Contains(userId))
                        {
                            System.IO.File.Delete(file);
                            Console.WriteLine($"{file} is deleted.");
                            string[] images = userProfile.FileName.Split('.');
                            var fileName = userId + "." + images[1];
                            var userImage = await UploadUserImage(userProfile, fileName);
                            return userImage;
                        }
                    }
                }
            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
            }
            return null;
        }




        /*  private async Task<bool> removeExistFroot(Froots froot)
          {
                  using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                  {
                  try {
                      await con.OpenAsync();
                      var selectedFroots = (List<Froots>)await con.QueryAsync<Froots>(@"SELECT * FROM SelectedFroots WHERE UserId = " + froot.UserId);
                      if (selectedFroots.Contains(froot))
                      {
                          Console.WriteLine("aaaa");
                      }
                      foreach (var existImage in selectedFroots)
                      {
                          if (existImage.Name != froot.Name)
                          {
                              string newImageQuery = "";
                              newImageQuery = @"INSERT INTO SelectedFroots(Name,Checked, UserId) VALUES ( @Name, @Checked, @UserId)";
                              await con.ExecuteAsync(newImageQuery, existImage);
                          }
                      }
                      return true;
                  }
                  catch(Exception ex) {
                      Console.WriteLine(ex.Message);
                       return false;
                    }
                 }
          }*/
    }
}
