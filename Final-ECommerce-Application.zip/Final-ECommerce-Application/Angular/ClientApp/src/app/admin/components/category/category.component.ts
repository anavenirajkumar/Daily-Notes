import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { DialogPopupComponent } from '../dialog-popup/dialog-popup.component';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  public category = {id:0, name:''};
  public categories:any = [];
  constructor(private adminService:AdminService,private dialogModel: MatDialog) { }

  ngOnInit(): void {
    this.getCategories();
  }

  public createCategory(){
     if(this.category.name){
        this.adminService.addCategory(this.category).subscribe((res) => {
           this.getCategories();
        })
     }
  }

  public getCategories(){
    this.adminService.getCategories().subscribe((res) => {
       this.categories = res;
    });
  }

 public deleteCategory(id:number): void {
     const dialogRef = this.dialogModel.open(DialogPopupComponent,{ data: { messageHead: "Delete Category", messageBody: "Are you want sure Delete ?" }
     });
     dialogRef.afterClosed().subscribe(result => {
      if (!!result) {
            this.adminService.deleteCategory(id).subscribe((res) => {
             this.getCategories();
        })}
    });

  }
}
