import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/user/services/user.service';

@Component({
  selector: 'app-edit-multiple-images',
  templateUrl: './edit-multiple-images.component.html',
  styleUrls: ['./edit-multiple-images.component.css']
})
export class EditMultipleImagesComponent implements OnInit {
 
  public userId:any;
  public user:any;
  public checkMarried:any;
  public marriedStatus = [{id:1, name:'Married',checked: false}, {id:2, name : 'UnMarried', checked: false}];
  selectedIndex: number | any;
  public selectedImages:any = [];
  public imagePath = 'https://localhost:44393/Resources/Images/';
  public fruits:any = [
    { id: 1, name: 'Apple', checked: false },
    { id: 2, name: 'Banana', checked: false },
    { id: 3, name: 'Carrot', checked: false },
    { id: 4, name: 'Tomoto', checked: false },
    { id: 5, name: 'Orange', checked: false },
    { id: 6, name: 'Ice-Cream', checked: false },
    { id: 7, name: 'Mango', checked: false }
  ];
  public errorMessages:string[] = [];
  constructor(private snapShot:ActivatedRoute, private userService:UserService, private router:Router) { }

  ngOnInit(): void {
    this.snapShot.paramMap.subscribe((id)=> {
      this.userId = id.get('id');
      this.getUser(this.userId);
    })  
  }
 
  public getUser(UserId:any){
    this.userService.GetNewUserById(UserId).subscribe((res:any) => {
       this.user = res;
       console.log(this.user);
       this.user.userImages.forEach((ele:any) => {
           ele.imageName = this.imagePath + ele.imageName;
       });
       if(this.user.married === true){
         this.marriedStatus.filter((ele) => {
          if(ele.name === 'Married'){
            ele.checked = true;
            let index = this.marriedStatus.findIndex((ele) => ele.name == 'Married');
            this.selectedIndex = index;
          }
         })
       }
       else{
          this.marriedStatus.filter((ele) => {
           if(ele.name === 'UnMarried'){
             ele.checked = true;
             let index = this.marriedStatus.findIndex((ele) => ele.name == 'UnMarried');
             this.selectedIndex = index;
           } 

          })
     } 


      //  if(this.user.selectedFroots != null){
      //     this.user.selectedFroots.filter((obj1:any) => {
      //          this.fruits.filter((obj2:any) => {
      //               if(obj1.name === obj2.name){
      //                 obj2.checked = obj1.checked;
      //               }
      //          })
      //     })
      //  }   

    }, err => {
      localStorage.removeItem('token');
      localStorage.removeItem('userDetails');
      this.router.navigateByUrl('/')
    });
  }

  selectedMarried(index:any, event:any) {
    this.selectedIndex = event.target.checked ? index : null;
    console.log(this.selectedIndex);
    if(this.selectedIndex === 0){
       this.user.married = true;
    } else if(this.selectedIndex === 1){
      this.user.married = false;
    } else{
      this.user.married = null;
    }
  }

  public updateUser(){
    console.log(this.user); 
    this.errorMessages = [];
    const valid = this.verifyForm();
    if(valid){
      const formData = this.createForm();
      this.userService.updateNewUser(formData).subscribe((res) => {
        console.log(res);
        this.router.navigateByUrl('/admin/upload-multiple-images');
      }, err => {
        console.log(err);
      });
    }
  }
  

  selectedFroot(obj:any,event:any){
    console.log(obj);
     if(event.target.checked === true && obj.checked === true){
      this.user.selectedFroots.forEach((ele:any) => {
           if(ele.name === obj.name){
              ele.checked = true;
           }
      })
     } else{
      this.user.selectedFroots.forEach((ele:any) => {
        if(ele.name === obj.name){
           ele.checked = false;
        }
   })
     }
    console.log(this.user);
 }

 public profilePhotos(event:any){
  if(event.target.files.length > 0){
      for(let i = 0; i < event.target.files.length; i++){
          //this.user.userImages.push( {id : i, File : event.target.files[i]})
          const imageName = event.target.files[i].name;
          const updatedFile = new File([event.target.files[i]], imageName, { type: event.target.files[i].type });
          var reader = new FileReader();
              reader.onload = (event:any) => {
              console.log(event.target.result);
              this.selectedImages.push({ id : i, image : event.target.result }); 
              this.user.userImages.push({ imageId : i, imageFile: updatedFile, imageName : imageName, type : updatedFile.type}); 
         }
             reader.readAsDataURL(event.target.files[i]);
      }
  }
  console.log(this.user.userImages);

}

public deleteImage(image:any){
  this.userService.deleteUserImage(image.imageId).subscribe((res)=> {
     console.log(res);
     this.getUser(this.userId);
  });
}
public SelectedProfileImage(image:any){
  let imageId = image.id;
  let imageIndex = this.selectedImages.findIndex((ele:any) => ele.id === imageId);
  let userimageIndex = this.user.userImages.findIndex((ele:any) => ele.id === imageId);
  this.selectedImages.splice(imageIndex,1);
  this.user.userImages.splice(userimageIndex,1);
  console.log(this.selectedImages);
}

public createForm() :FormData{
  const formData = new FormData();
  formData.append('userId', this.user.userId);
  formData.append('name', this.user.name);
  formData.append('email',this.user.email);
  formData.append('mobileNumber', this.user.mobileNumber);
  formData.append('gender',this.user.gender);
  formData.append('married',this.user.married);
  formData.append('dateOfJoining',this.user.dateOfJoining);
  formData.append('city',this.user.city);
  formData.append('country',this.user.country);
//   if (this.user.userImages != null) {
//     this.user.userImages.forEach((x:any, i:any) => {
//         formData.append(`userImages[${i}][imageId]`, i);
//         formData.append(`userImages[${i}][imageName]`, x.imageName);
//         formData.append(`images`, x.imageFile);
//         formData.append(`userImages[${i}][imageType]`, x.type);
//     });
// }
if (this.selectedImages != null) {
  this.selectedImages.forEach((x:any, i:any) => {
    formData.append(`userImages[${i}][imageId]`, i);
    formData.append(`userImages[${i}][imageName]`, x.imageName);
    formData.append(`images`, x.imageFile);
    formData.append(`userImages[${i}][imageType]`, x.type);
  });
}

if (this.user.selectedFroots != null) {
  this.user.selectedFroots.forEach((x:any, i:any) => {
      formData.append(`selectedFroots[${i}][id]`, x.id);
      formData.append(`selectedFroots[${i}][name]`, x.name);
      formData.append(`selectedFroots[${i}][checked]`, x.checked);
      formData.append(`selectedFroots[${i}][userId]`, x.userId ? x.userId : 0);
  });
}
return formData;
}

 public updatePictures(event:any){

  if(event.target.files.length > 0){
    for(let i = 0; i < event.target.files.length; i++){
        const imageName = event.target.files[i].name;
        const updatedFile = new File([event.target.files[i]], imageName, { type: event.target.files[i].type });
        this.selectedImages.push({ imageId : i, imageFile: updatedFile, imageName : imageName, type : updatedFile.type}); 
      //   var reader = new FileReader();
      //       reader.onload = (event:any) => {
      //       console.log(event.target.result);
      //       this.selectedImages.push({ imageId : i, imageFile: updatedFile, imageName : imageName, type : updatedFile.type}); 
      //       }
      //      reader.readAsDataURL(event.target.files[i]);
    }
}
  const userImages = this.updateImages();
  this.userService.UpdateUserImages(userImages).subscribe((res:any)=> {
    console.log(res);
    this.user.userImages = res.userImages;
    this.user.userImages.forEach((ele:any) => {
      ele.imageName = this.imagePath + ele.imageName;
   });
  });
 }

 public updateImages():FormData{
  const upadteImages = new FormData();
  if (this.selectedImages != null) {
    upadteImages.append('userId', this.user.userId);
    this.selectedImages.forEach((x:any, i:any) => {
      upadteImages.append(`userImages[${i}][imageId]`, i);
      upadteImages.append(`userImages[${i}][imageName]`, x.imageName);
      upadteImages.append(`images`, x.imageFile);
      upadteImages.append(`userImages[${i}][imageType]`, x.type);
    });
  }
  return upadteImages;
 }

 public verifyForm(): boolean {
  let formsValid = true;
  if (this.user.name == "" && this.user.name < 3) {
      formsValid = false;
      this.errorMessages.push("Please Enter Name");
  }
  if(this.user.email == "" && this.user.email.length < 9){
    formsValid = false;
    this.errorMessages.push("Email");
  }
  if(this.user.mobileNumber === null && this.user.mobileNumber == "" || this.user.mobileNumber.length < 10){
    formsValid = false;
    this.errorMessages.push("Please Enter Mobile Number");
  }
   if (this.user.gender == "") {
      formsValid = false;
      this.errorMessages.push("Please Select Gender");
  }
  if(this.user.married == null){
    formsValid = false;
    this.errorMessages.push("Please Select Married");
  }
  if(this.user.dateOfJoining == ""){
    formsValid = false;
    this.errorMessages.push("Please Select DOJ");
  }
  if(this.user.city == ""){
    formsValid = false;
    this.errorMessages.push("Please Enter City");
  }
  if(this.user.country == ""){
    formsValid = false;
    this.errorMessages.push("Please Enter Country");
  }
  if(this.user.userImages.length === 0){
    formsValid = false;
    this.errorMessages.push("Please Upload Images");
  }
  if(this.user.selectedFroots.length === 0){
    formsValid = false;
    this.errorMessages.push("Please Select Froots");
  }
 return formsValid;
}
}
