import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { CategoryComponent } from './components/category/category.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { EditCategoryComponent } from './components/edit-category/edit-category.component';
import { DialogPopupComponent } from './components/dialog-popup/dialog-popup.component';
import { MatDialogModule } from '@angular/material/dialog';
import { AddBrandComponent } from './components/add-brand/add-brand.component';
import { UpdateBrandComponent } from './components/update-brand/update-brand.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { UploadXmlFileComponent } from './components/upload-xml-file/upload-xml-file.component';
import { UpdateProductComponent } from './components/update-product/update-product.component';
import { IdComponent } from './components/upload-xml-file/id/id.component';
import { UploadMultipleImagesComponent } from './components/upload-multiple-images/upload-multiple-images.component';
import { EditMultipleImagesComponent } from './components/edit-multiple-images/edit-multiple-images.component';
import {MatSelectModule} from '@angular/material/select';

@NgModule({
  declarations: [
    AdminComponent,
    CategoryComponent,
    EditCategoryComponent,
    DialogPopupComponent,
    AddBrandComponent,
    UpdateBrandComponent,
    AddProductComponent,
    UpdateProductComponent,
    UploadXmlFileComponent,
    IdComponent,
    UploadMultipleImagesComponent,
    EditMultipleImagesComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule, 
    FormsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule, // Dialogue
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule
  ]
})
export class AdminModule { }
