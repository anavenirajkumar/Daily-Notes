import { Component, OnInit } from '@angular/core';
import { IUser } from '../../models/IUser';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public hide:boolean = true;
  public user:IUser = {email : 'anaveni.rajkumar1@gmail.com', password:'Rajkumar1@'};
  public errorMessage:string[] = [];
  public loginMessage:any = {error:[], success:[]};
  constructor(private userService:UserService,private router : Router) { }

  ngOnInit(): void {
  }

  public login(){
    this.errorMessage.length = 0;
    this.loginMessage.error.length = 0;
    this.loginMessage.success.length = 0;
      if(this.validate()){
         this.userService.login(this.user).subscribe((res:any) => {
         this.loginMessage.success.push(res.message);
        setTimeout(() => {
          if(res.role === 'Admin'){
            this.router.navigate(['/admin']);
          } else if(res.userID !== null ){
            this.router.navigate(['/user/user-profile']);
          } else{
            this.router.navigate(['/user/login']);
          }
        }, 2000); 
        }, () => {this.loginMessage.error.push("Invalid Credentials")});
      }
  }

  private validate():boolean{
    let validEmail = this.user.email.endsWith("@gmail.com");
     if(this.user.email == ''){
        this.errorMessage.push('Please Enter Email Address');
     }
    else if(!validEmail){
        this.errorMessage.push('Please Enter Proper Email Address');
     }
     if(this.user.password == ''){
        this.errorMessage.push('Please Enter Password');
     } 
    else if(this.user.password.length < 4){
        this.errorMessage.push('Please Enter Password Minimum 4 Characters');
     }
    return this.errorMessage.length === 0;
  }

}
