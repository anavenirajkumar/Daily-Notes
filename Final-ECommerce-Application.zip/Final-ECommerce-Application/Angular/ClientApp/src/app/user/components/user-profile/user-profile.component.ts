import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  public userInfo  = this.userService.currentUser;
  public enableAddress : boolean = false;
  public existImage:string = "";
  public displayProfileImageUrl = 'https://localhost:44393/Resources/User/Images/';
  constructor(private router : Router, private userService : UserService) { }

  ngOnInit() {
 
  }


  submitUpdateAddress(){
       this.userService.updateUserAddress(this.userInfo).subscribe((response: any) => {
         this.enableAddress = false;
      })
    }

    public logout(){
      localStorage.removeItem('token');
      localStorage.removeItem('userDetails');
    }
    
    public uploadProfile(event:any){
        //let userId:string = this.userInfo.userID;
        const file: File = event.target.files[0];
        // var reader = new FileReader();
        // reader.onload = (event:any) => {
        // this.userImage =  event.target.result; 
        // }
        // reader.readAsDataURL(event.target.files[0]);
        let userId:number = +this.userService.currentUser.userID;
        this.userService.uploadImage(userId, this.userInfo.profileName, file).subscribe(
            (successResponse) => {
              this.existImage = successResponse;
              this.userInfo.profileName = successResponse;
            },(err) => {});
      }
  }


  

  
