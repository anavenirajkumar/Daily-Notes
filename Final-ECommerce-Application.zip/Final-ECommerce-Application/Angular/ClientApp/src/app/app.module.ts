import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CoreModule } from './coremodule/core.module';
import { FormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { UserService } from './user/services/user.service';
import { JwtInterceptor } from './user/interceptors/jwt.interceptor';
import { AdminService } from './admin/services/admin.service';
import { DatePipe } from '@angular/common';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
@NgModule({
  declarations: [
    AppComponent,
    PagenotfoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CoreModule, 
    FormsModule,
    HttpClientModule
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA // import for All Modules
  ],
  providers: [UserService,AdminService,DatePipe,
    {
      provide : HTTP_INTERCEPTORS, // Inject InterCeptors for pass token in Headers
      useClass : JwtInterceptor,
      multi : true
    }],
  bootstrap: [AppComponent]
})
export class AppModule { }
