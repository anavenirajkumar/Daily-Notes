import { createAction, props } from '@ngrx/store';
import { IUser } from '../interface/IUser';

export const registerUser = createAction('[Register] Register User',
 props<{user : IUser}>() // this action method receiving total form data, Props is Passing data with Function
);