import { Component, OnInit } from '@angular/core';

import { Store } from '@ngrx/store';
import { State } from './reducers/register.reducer';
import * as registerActions from '../register/actions/register.actions';
import { IUser } from './interface/IUser';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public user:IUser = { // FormsModule
     name : '',
     email : '',
     mobile : null,
     location : ''
  }
  constructor(private store: Store<State>) { }

  ngOnInit(): void {

  }

  public submitUser(){
      if(this.vaildUser() == true){
        this.store.dispatch(registerActions.registerUser({user : this.user}));
        console.log(this.user);
        this.user = {
          name : '',
          email : '',
          mobile : null,
          location : ''
        }
      }
  }
  public vaildUser():boolean | any{
    if(this.user.name !=='' && this.user.email !=='' && this.user.mobile !=='' && this.user.location !==''){
      return true;
    } else {
      return false;
    }
  }
}
