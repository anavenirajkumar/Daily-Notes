import { Action, createReducer, on } from '@ngrx/store';
import { IUser } from '../interface/IUser';
import * as userActions from '../actions/register.actions'

export const registerFeatureKey = 'register';

export interface State {
   user : IUser
}

export const initialState: State = {
    user : {
      name : '',
      email : '',
      mobile : 0,
      location : ''
    }
};

export const reducer = createReducer(
  initialState,
  on(userActions.registerUser, (state, {user}) => {
    return {
      user : {
        name : user.name,
        email : user.email,
        mobile : user.mobile,
        location : user.location
      }
    }
  })
);
