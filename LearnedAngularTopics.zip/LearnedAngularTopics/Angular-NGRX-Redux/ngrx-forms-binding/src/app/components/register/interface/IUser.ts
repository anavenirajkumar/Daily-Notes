export interface IUser{
    name : string,
    email : string,
    mobile : number | any,
    location : string
}