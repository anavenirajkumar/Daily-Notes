import * as fromRegister from './register.actions';

describe('yRegisters', () => {
  it('should return an action', () => {
    expect(fromRegister.yRegisters().type).toBe('[Register] Y Registers');
  });
});
