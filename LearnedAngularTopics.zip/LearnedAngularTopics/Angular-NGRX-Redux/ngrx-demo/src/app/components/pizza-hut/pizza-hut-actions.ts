import { createAction } from "@ngrx/store";

export const buyPizza = createAction('[PIZZA HUT] Buy Pizza'); //[PIZZA HUT] -> Component Referable Name
