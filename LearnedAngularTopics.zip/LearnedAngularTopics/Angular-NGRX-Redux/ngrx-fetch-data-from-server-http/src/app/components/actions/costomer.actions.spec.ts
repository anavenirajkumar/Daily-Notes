import * as fromCostomer from './costomer.actions';

describe('yCostomers', () => {
  it('should return an action', () => {
    expect(fromCostomer.yCostomers().type).toBe('[Costomer] Y Costomers');
  });
});
