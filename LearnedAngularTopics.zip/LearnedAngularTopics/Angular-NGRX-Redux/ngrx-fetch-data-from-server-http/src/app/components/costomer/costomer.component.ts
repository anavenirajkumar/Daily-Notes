import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { State } from '../../reducers/index';
import { ICustomer } from 'src/app/interface/ICostomer';
import * as customerReducer from '../reducers/costomer.reducer';
import * as customerActions from '../actions/costomer.actions';
@Component({
  selector: 'app-costomer',
  templateUrl: './costomer.component.html',
  styleUrls: ['./costomer.component.css']
})
export class CostomerComponent implements OnInit {

  public customers:ICustomer[] | any;
  public errorMessage:string | any;
  public loading:boolean = false;

  constructor(private store:Store<State>) { }

  ngOnInit(): void { // pipe -> A pipe takes in data as input and transforms it into an output
    this.store.pipe(select(customerReducer.costomerFeatureKey)).subscribe((state) => {
      this.customers = state.customers;
      this.errorMessage = state.errorMessage;
      this.loading = state.loading
    });
  }

  public getCustomers(){
    this.loading = true;
     setTimeout(() => {
      this.store.dispatch(customerActions.loadCustomers());
     }, 2000);
  }

}
