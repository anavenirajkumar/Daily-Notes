import { Action, createReducer, on } from '@ngrx/store';
import { ICustomer } from 'src/app/interface/ICostomer';
import * as customerActions from '../actions/costomer.actions';

export const costomerFeatureKey = 'costomer';

export interface State {
   loading: boolean,
   customers: ICustomer[],
   errorMessage : string
}

export const initialState: State = {
    loading : false,
    customers : [],
    errorMessage : ''
};

export const reducer = createReducer(
  initialState,
  on(customerActions.loadCustomers, (state)=>{
    return {
      ...state,
      loading : true
    }
  }),
  on(customerActions.loadCustomersSuccess, (state, {customers})=> {
    return {
      ...state,
      customers : customers,
      loading : false
      
    }
  }),
  on(customerActions.loadCustomersFailure, (state, {error}) => {
    return {
      ...state,
      loading : false,
      errorMessage : error
    }
  })

);
