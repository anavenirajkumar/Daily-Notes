import * as fromProductItem from './product-item.actions';

describe('yProductItems', () => {
  it('should return an action', () => {
    expect(fromProductItem.yProductItems().type).toBe('[ProductItem] Y ProductItems');
  });
});
