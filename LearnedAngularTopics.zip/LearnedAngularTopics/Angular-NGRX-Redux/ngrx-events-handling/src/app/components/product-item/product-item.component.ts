// Step 3 is "index.ts" file import  reducer in State
// Step 4  
import { Component, OnInit } from '@angular/core';
import { Store, select } from '@ngrx/store';  // import
import { State } from '../../reducers'; // import State "index.ts"
import * as productActions from '../product-item/actions/product-item.actions'; // import
import * as productReducer from '../product-item/reducers/product-item.reducer'; // import


@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.css']
})
export class ProductItemComponent implements OnInit {

  public product:any;

  constructor(private store:Store<State>) { }

  ngOnInit(): void {
    this.store.pipe(select(productReducer.productItemFeatureKey)).subscribe((state)=>{
      this.product = state;
    })
  }

 public clickDecrQty(){
   this.store.dispatch(productActions.decrQty());
 }

 public clickIncrQty(){
   this.store.dispatch(productActions.incrQty());
 }

}
