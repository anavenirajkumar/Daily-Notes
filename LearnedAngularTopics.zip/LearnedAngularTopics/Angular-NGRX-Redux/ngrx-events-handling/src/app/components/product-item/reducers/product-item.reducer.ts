
 // Step 2
import { Action, createReducer, on } from '@ngrx/store';
import { decrQty, incrQty } from '../actions/product-item.actions';


export const productItemFeatureKey = 'productItem'; 

export interface State {
  sno : string,
  image : string,
  name : string,
  price : number,
  qty : number
}

export const initialState: State = {
   sno : 'AA12345',
   image : 'https://images-na.ssl-images-amazon.com/images/I/61OUIIXnPqL._AC_SL1001_.jpg',
   name : 'Smart Watch',
   price : 500,
   qty : 1

};

export const reducer = createReducer(
  initialState,
  on(incrQty, (state) => {
     return {
       ...state, // Spread Operator and I'm Changing Only Qty logic
       // qty : state.qty + 1,
       qty : ( state.qty + 1 <= 10) ? state.qty + 1 : 10
     }
  }),
  on(decrQty,(state)=> {
    return {
      ...state,
      qty : (state.qty - 1 > 1) ? state.qty - 1 : 1 // Ternary Operator
    }
  })

);
