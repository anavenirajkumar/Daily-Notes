import {
  ActionReducer,
  ActionReducerMap,
  createFeatureSelector,
  createSelector,
  MetaReducer
} from '@ngrx/store';
import { environment } from '../../environments/environment';
import * as productReducer from '../components/product-item/reducers/product-item.reducer'; // Step 3 import

export interface State {
  [productReducer.productItemFeatureKey] : productReducer.State //  import
}

export const reducers: ActionReducerMap<State> = {
  [productReducer.productItemFeatureKey] : productReducer.reducer //  import
};


export const metaReducers: MetaReducer<State>[] = !environment.production ? [] : [];
