export interface IEmployee {
    EmployeeId : number,
    EmployeeName : string,
    Department : string,
    DateOfJoining : string,
    PhotoFileName : string
}