import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IDepartment } from '../models/IDepartment';
import { IEmployee } from '../models/IEmployee';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  readonly APIUrl="http://localhost:44464/api"; // http://localhost:44464/ or 58830
  readonly PhotoUrl = "http://localhost:44464/Photos/"; // http://localhost:44464/ 58830
  
  constructor( private httpClient : HttpClient) { }

  getDepartmentList():Observable<IDepartment[]>{
    return this.httpClient.get<IDepartment[]>(this.APIUrl+'/Department');
  }

  addDepartment(data:any){
    return this.httpClient.post(this.APIUrl+'/Department', data);
  }
  editDepartment(data:any){
    return this.httpClient.put(this.APIUrl+'/Department',data);
  }

  deleteDepartment(id:any){
    return this.httpClient.delete(this.APIUrl+'/Department'+id);
  }

  getEmployees():Observable<IEmployee[]>{
    return this.httpClient.get<IEmployee[]>(this.APIUrl+'/Employee');
  }
  
  addEmployee(data:any){
    return this.httpClient.post(this.APIUrl+'/Employee',data);
  }

  editEmployee(data:any){
    return this.httpClient.put(this.APIUrl+'/Employee',data);
  }
  deleteEmployee(id:any){
    return this.httpClient.delete(this.APIUrl+'/Employee'+id);
  }

}
