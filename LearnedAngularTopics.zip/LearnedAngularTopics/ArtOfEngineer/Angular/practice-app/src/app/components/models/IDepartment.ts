export interface IDepartment {
    DepartmentId: number,
    DepartmentName: string
}