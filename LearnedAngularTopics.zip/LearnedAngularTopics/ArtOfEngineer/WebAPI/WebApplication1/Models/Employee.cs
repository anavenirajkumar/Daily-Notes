﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Employee
    {
       
        public int EmployeeId { get; set; }
       /* [DisplayName("Employee Name")]
        [Required(ErrorMessage = "Employee Name is required")]
        [StringLength(100, MinimumLength = 3)]*/
        public string EmployeeName { get; set; }

       /* [DisplayName("Department Name")]
        [Required(ErrorMessage = "Department Name is required")]
        [StringLength(100, MinimumLength = 3)]*/

        public string Department { get; set; }

       /* [DisplayName("DateOfJoining")]
        [Required(ErrorMessage = "DateOfJoining is required")]*/
        public string DateOfJoining { get; set; }

       /* [DisplayName("PhotoFileName")]
        [Required(ErrorMessage = "PhotoFileName is required")]*/
        public string PhotoFileName { get; set; }

    }
}