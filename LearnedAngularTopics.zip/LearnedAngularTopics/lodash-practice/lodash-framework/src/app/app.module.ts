import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LodashComponent } from './lodash/lodash.component';
import { PracticeArraysComponent } from './practice-arrays/practice-arrays.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConverttomonthPipe } from './pipes/converttomonth.pipe';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { DisableSelectedOptionsComponent } from './disable-selected-options/disable-selected-options.component';
import { CurrentYearMonthComponent } from './current-year-month/current-year-month.component';

@NgModule({
  declarations: [
    AppComponent,
    LodashComponent,
    PracticeArraysComponent,
    ConverttomonthPipe,
    FileUploadComponent,
    DisableSelectedOptionsComponent,
    CurrentYearMonthComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
