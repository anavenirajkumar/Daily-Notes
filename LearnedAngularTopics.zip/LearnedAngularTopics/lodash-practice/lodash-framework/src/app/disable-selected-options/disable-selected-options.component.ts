import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-disable-selected-options',
  templateUrl: './disable-selected-options.component.html',
  styleUrls: ['./disable-selected-options.component.css']
})
export class DisableSelectedOptionsComponent implements OnInit {

  public selectedItem:any;
  public productName:any;
  public selectedItemsOne:any = [];
  public selectedItemsTwo:any = [];
  public mobiles:any = [
    {id: 1, name: 'Iphone 13 Pro', categoryName : "Apple" },
    {id: 2, name: 'OnePlus 10 Pro',categoryName : "OnePlus"},
    {id: 3, name: 'Samsung Galaxy S21', categoryName : "Samsung"},
    {id: 4, name: 'Redmi Note 4',categoryName : "Redmi"},
    {id: 5, name: 'Realme 9 Pro', categoryName : "Realme"}
  ];

  public item:any;

  ////////// Multiple Variable ///////////
  public v1 :any;
  public v2 :any;
  public v3 :any;
  public v4 :any;
  public v5 :any;

  constructor() { }

  ngOnInit(): void {
 
  }

  public addMobile(){
    //console.log(this.productName);
    this.selectedItem = this.productName;
    let f = this.selectedItemsOne.find((e:any) => e === this.productName);
     if(f == undefined){
      this.selectedItemsOne.push(this.productName);
      this.productName = "";
     }
     this.productName = "";
  }

  public addMobileTwo(){
    this.selectedItemsTwo.push(this.productName);
    if(this.productName === "Apple"){
      this.v1 = this.productName;
      this.productName = "";
    }else if(this.productName === "OnePlus"){
      this.v2 = this.productName;
      this.productName = "";
    }else if(this.productName === "Samsung"){
      this.v3 = this.productName;
      this.productName = "";
    }else if(this.productName === "Redmi"){
      this.v4 = this.productName;
      this.productName = "";
    }else if(this.productName === "Realme"){
      this.v5 = this.productName;
      this.productName = "";
    }
  }

  public onSelect(val:any){
     console.log(val);
     this.productName = val;
     this.addMobile();
  }

  public onSelectTwo(val:any){
    console.log(val);
    this.productName = val;
    this.addMobileTwo()
 }
}
