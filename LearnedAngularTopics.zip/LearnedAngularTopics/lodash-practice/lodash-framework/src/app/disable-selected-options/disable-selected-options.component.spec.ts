import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisableSelectedOptionsComponent } from './disable-selected-options.component';

describe('DisableSelectedOptionsComponent', () => {
  let component: DisableSelectedOptionsComponent;
  let fixture: ComponentFixture<DisableSelectedOptionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisableSelectedOptionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisableSelectedOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
