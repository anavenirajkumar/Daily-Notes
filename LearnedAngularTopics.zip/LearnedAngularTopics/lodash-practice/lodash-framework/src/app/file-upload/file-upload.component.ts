import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  public file:File | any = null;
  public fileSize:any;
  
  // only jpg and jpeg images allowed
  public selectImageText:string = "Please Select JPG,JPEG Images Only";
  public onlyJPGText:string = '';
  //public otherImagesNotAllowed:string = '';

  // multiple images upload and display
  public product:any = {
    name : '',
    image : '',
  }
    // Client Images Upload 
    public clientImages:any = {
      profileImages : [],
      adharCardImages : [],
      passportImages : []
   }
 
  public images:any[] = [];
  constructor() { }

  ngOnInit(): void {
  }

  public onChange(event:any){
   this.file = event.target.files[0];
   console.log(this.file);
     let sizeInBytes: number =  this.file.size;
     console.log(sizeInBytes);
     this.fileSize = this.formatBytes(sizeInBytes);
     console.log(this.fileSize);
  }

  public formatBytes(bytes:any,decimals = 2){
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];

  }

  // only JPG Files Allowed
  public onlyJPGImagesUploadOnly(event:any){
  const files = event.target.files; // Single image Code => event.target.files[0]
  console.log(files);

  const allowedFileTypes = ["image/jpg", "image/jpeg"];
  if (files.length > 0) {
    this.selectImageText = '';
  }

  ////////////////// Single Image Object Code /////////////////////
  //  if(allowedFileTypes.includes(files.type)){
  //   this.onlyJPGText = '';
  // } else {
  //   this.onlyJPGText = 'Only JPG, JPEG Images Allowed Only';
  // }

  ////////////////// Multiple Images Code /////////////////////////
  if (Array.from(files).every((file:any) => allowedFileTypes.includes(file.type))) {
    this.onlyJPGText = '';
  } else {
    this.onlyJPGText = 'Only JPG, JPEG Images Allowed Only';
  }
   console.log(this.onlyJPGText);
  }


  public uploadImage(event:any){
    if (event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              reader.onload = (event:any) => {
                console.log(event.target.result);
                this.product.image = event.target.result;
              }
              reader.readAsDataURL(event.target.files[i]);
      }
    }
  }

  public removeImage(){
    this.product.image = "";
  }




///////////////////// Multiple Images upload by Client Category ////////////////////
public profilePhotos(event:any){
  if (event.target.files && event.target.files[0]) {
    var filesAmount = event.target.files.length;
    for (let i = 0; i < filesAmount; i++) {
            var reader = new FileReader();
            let imageName = event.target.files[i].name;
              reader.onload = (event:any) => {
                console.log(event.target.result);
                 this.clientImages.profileImages.push({id: i, name : imageName, image : event.target.result}); 
              }
            reader.readAsDataURL(event.target.files[i]);
            //console.log(event.target.files[i].name);
    }
}
console.log(this.clientImages.profileImages);

}

public removeProfilePhotos(){
    this.clientImages.profileImages = [];
    console.log(this.clientImages.profileImages);
}

public SelectedProfileImage(imageId:any){
  let imageIndex = this.clientImages.profileImages.findIndex((e:any) => e.id === imageId);
  this.clientImages.profileImages.splice(imageIndex,1);
  console.log(this.clientImages.profileImages);

}

// Adhar Card Images
public adharCardPhotos(event:any){
  if (event.target.files && event.target.files[0]) {
    var filesAmount = event.target.files.length;
    for (let i = 0; i < filesAmount; i++) {
            var reader = new FileReader();
            let imageName = event.target.files[i].name;
              reader.onload = (event:any) => {
                console.log(event.target.result);
                 this.clientImages.adharCardImages.push({id: i, name : imageName, image : event.target.result}); 
              }
            reader.readAsDataURL(event.target.files[i]);
            //console.log(event.target.files[i].name);
    }
}
console.log(this.clientImages.adharCardImages);

}

public removeAdharCardPhotos(){
    this.clientImages.adharCardImages = [];
    console.log(this.clientImages.adharCardImages);
}

public SelectedAdharCardImage(imageId:any){
  let imageIndex = this.clientImages.adharCardImages.findIndex((e:any) => e.id === imageId);
  this.clientImages.adharCardImages.splice(imageIndex,1);
  console.log(this.clientImages.adharCardImages);

}

// Adhar Card Images
public passportPhotos(event:any){
  if (event.target.files && event.target.files[0]) {
    var filesAmount = event.target.files.length;
    for (let i = 0; i < filesAmount; i++) {
            var reader = new FileReader();
            let imageName = event.target.files[i].name;
              reader.onload = (event:any) => {
                console.log(event.target.result);
                 this.clientImages.passportImages.push({id: i, name : imageName, image : event.target.result}); 
              }
            reader.readAsDataURL(event.target.files[i]);
            //console.log(event.target.files[i].name);
    }
}
console.log(this.clientImages.passportImages);

}

public removePassportPhotos(){
    this.clientImages.passportImages = [];
    console.log(this.clientImages.passportImages);
}

public SelectedPassportImage(imageId:any){
  let imageIndex = this.clientImages.passportImages.findIndex((e:any) => e.id === imageId);
  this.clientImages.passportImages.splice(imageIndex,1);
  console.log(this.clientImages.passportImages);

}

public clientDetails(){
  console.log(this.clientImages);
}

///////////////////// Multiple Images Upload and Duplicate Images Not Allowed //////////////////////
 public onFileChange(event:any) {
    if (event.target.files && event.target.files[0]) {
        var filesAmount = event.target.files.length;
        for (let i = 0; i < filesAmount; i++) {
                var reader = new FileReader();
                let imageName = event.target.files[i].name;
                let imageSize = event.target.files[i].size;
                let nameFinder = this.images.some((e) => e.name === imageName || e.size === imageSize);
                 if(nameFinder){
                      console.log(this.images);
                   return;
                 }
                else {
                  reader.onload = (event:any) => {
                    console.log(event.target.result);
                     this.images.push({id: i, name : imageName, image : event.target.result, size : imageSize}); 
                    //  this.myForm.patchValue({
                    //     fileSource: this.images
                    //  });
                    console.log(this.images);
                  }
                 }
                reader.readAsDataURL(event.target.files[i]);
                //console.log(event.target.files[i].name);
        }
    }
    
    // Post Images Array to Backend
    const frmData = new FormData(); 
    for (var i = 0; i < this.images.length; i++) { 
      console.log(this.images[i], "EACH Image Upload");
      // frmData.append("fileUpload", this.images[i]);
      //this.service.upload(this.images[i]);
    }
    console.log(frmData);
    // call Api using Service
  }

  public removeAllImages(){
    this.images = [];
  }

  public removeSelectedImage(imageId:any){
     console.log(imageId);
     let index = this.images.findIndex((e) => e.id === imageId);
     this.images.splice(index,1);
     console.log(this.images);
  }
  
}
