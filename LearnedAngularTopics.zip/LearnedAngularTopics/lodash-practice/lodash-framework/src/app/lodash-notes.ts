
// merge
let object = [{ 'b': 2 }, { 'd': 4 }];
let other = [{ 'c': 3 }, { 'e': 5 }];
   
let merged =  _.merge(object, other);
console.log(merged);

//sortBy

// reject

//forEach

// map

// replace

// find

// findKey

// keys

// omit

// pick

// without

// groupBy

// findIndex

// isMatch

// RXJS :  forkJoin, Subject, ReplaySubject, BehaviorSubject, ISubscription, retry, catch, Observable, 



