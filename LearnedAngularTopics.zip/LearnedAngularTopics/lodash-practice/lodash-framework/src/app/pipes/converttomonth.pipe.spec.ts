import { ConverttomonthPipe } from './converttomonth.pipe';

describe('ConverttomonthPipe', () => {
  it('create an instance', () => {
    const pipe = new ConverttomonthPipe();
    expect(pipe).toBeTruthy();
  });
});
