import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';


@Component({
  selector: 'app-lodash',
  templateUrl: './lodash.component.html',
  styleUrls: ['./lodash.component.css']
})
export class LodashComponent implements OnInit {

  
  constructor() { 
    const employees = [
      {
          "code": "CT7207",
          "salary": 40000,
          "id": 1007,
          "job": "Manager",
          "department": "Operations",
          "name": "Bently Smith",
          "hobbies": ["Sports", "Reading", "Painting"]
      },
      {
          "code": "CT7210",
          "salary": 80000,
          "id": 1010,
          "job": "Director",
          "department": "Operations",
          "name": "Isla Morris",
          "hobbies": ["Sports", "Reading"]
      },
      {
          "code": "CT7202",
          "salary": 15000,
          "id": 1002,
          "job": "Salesman",
          "department": "Sales",
          "name": "Allen Green",
          "hobbies": ["Sports", "Painting"]
      },
      {
          "code": "CT7208",
          "salary": 60000,
          "id": 1008,
          "job": "Analyst",
          "department": "Research",
          "name": "Xavier Campbell",
          "hobbies": ["Reading", "Painting"]
      },
      {
          "code": "CT7209",
          "salary": 50000,
          "id": 1009,
          "job": "Analyst",
          "department": "Research",
          "name": "Ethan Kumar",
          "hobbies": ["Crafting", "Painting"]
      },
      {
          "code": "CT7201",
          "salary": 20000,
          "id": 1001,
          "job": "Clerk",
          "department": "Accounting",
          "name": "John Marshal",
          "hobbies": ["Singing", "Painting"]
      },
      {
          "code": "CT7205",
          "salary": 15000,
          "id": 1005,
          "job": "Salesman",
          "department": "Sales",
          "name": "Ethan Almaas",
          "hobbies": ["Singing", "Dancing"]
      },
      {
          "code": "CT7211",
          "salary": 15000,
          "id": 1011,
          "job": "Salesman",
          "department": "Sales",
          "name": "Natalie Robinson",
          "hobbies": ["Writing"]
      },
      {
          "code": "CT7212",
          "salary": 15000,
          "id": 1012,
          "job": "Salesman",
          "department": "Sales",
          "name": "Earl Rose",
          "hobbies": ["Singing", "Sports"]
      },
      {
          "code": "CT7206",
          "salary": 20000,
          "id": 1006,
          "job": "Clerk",
          "department": "Accounting",
          "name": "Ilija Seifert",
          "hobbies": ["Singing", "Cooking"]
      },
      {
          "code": "CT7204",
          "salary": 20000,
          "id": 1004,
          "job": "Clerk",
          "department": "Accounting",
          "name": "Annette Burke",
          "hobbies": ["Reading", "Teaching"]
      },
      {
          "code": "CT7203",
          "salary": 15000,
          "id": 1003,
          "job": "Salesman",
          "department": "Sales",
          "name": "Fernando Gordon",
          "hobbies": []
      },
      {
          "code": "CT7213",
          "salary": 15000,
          "id": 1013,
          "job": "Salesman",
          "department": "Sales",
          "name": "Catherine Foster",
          "hobbies": []
      }
  ];
  
  // get employee with id 1003
  
  let employee = _.find(employees, e => e.id === 1003);
  console.log(employee);
  
  // get index of an employee having id 1008
  let findIndex = _.findIndex(employees, e => e.id === 1003);
  console.log(findIndex);

  
  // get salesman employees in job dept
  let onlySalesman = _.filter(employees, e => e.job === 'Salesman');
  console.log(onlySalesman);

  // get employees having salary greater than 40K
  let above40kSal = _.filter(employees, e => e.salary > 40000);
  console.log(above40kSal);
  
  // get number of employees having salary greater than 50K and from research department
   let above50kSalwithResearchDep = _.filter(employees, e => e.salary > 50000 && e.department ==='Research');
   console.log(above50kSalwithResearchDep);
  
  // get only name and salary of all employees
  let nameandSal = _.map(employees, e => ({
    name : e.name, salary : e.salary
  }));
  console.log(nameandSal);
  // get only name, job and annual salary of all employees
   let nameJobAnualSal = _.map(employees, e => ({
     name : e.name, job : e.job, annualSalary : e.salary * 12 
   }));
   console.log(nameJobAnualSal);
  
  // get only first name and last name of all employees
    let flname = _.map(employees, e => {
      let name = e.name.split(' ');
      //console.log(name);
      return { firstName : name[0], lastName : name[1] }
    });
    console.log(flname);
  
  // get name and salary of employees having salary greater than 10K but less than 20K ordered by name
   let nameSalEmp = _.filter(employees, e => e.salary > 10000 && e.salary <= 20000).map(e => ({name : e.name, salary : e.salary})).sort((emp1, emp2) => {
    const n1 = emp1.name.toLowerCase();
    const n2 = emp2.name.toLowerCase();
    if(n1 < n2){
      return -1;
    } else if(n1 > n2){
      return 1;
    } else {
      return 0;
    }
   });
   console.log(nameSalEmp);
  
  // get salary wise Accending
   let salWiseAssending = _.map(employees, e => ({ salary : e.salary})).sort((emp1, emp2) => {
    let s1 = emp1.salary;
    let s2 = emp2.salary;
    if(s1 < s2){
      return -1;
    } else if(s1 > s2) {
      return 1;
    } else {
      return 0;
    }
   });
   console.log("Salary Wise Assending Order", salWiseAssending);
  
  // get salary wise Dessending
  let salWiseDssending = _.map(employees, e => ({ salary : e.salary})).sort((emp1, emp2) => {
    let s1 = emp1.salary;
    let s2 = emp2.salary;
    if(s1 < s2){
      return -1;
    } else if(s1 > s2) {
      return 1;
    } else {
      return 0;
    }
   });
   console.log("Salary Wise Dssending Order", salWiseDssending);

  // return true if all employees having salary greater than 10K
   let eachEmpSal = _.every(employees, e => e.salary > 10000);
   console.log("All Employees Salaries > 10k", eachEmpSal);

  
  // return true if any employee is having salary greater than 60K
    let anyEmpSal60k = _.some(employees, e => e.salary > 60000);
    console.log("Any Employee Salaty > 60k", anyEmpSal60k);
  
  // get employees whose hobby is Reading
   let hobbyfilter = _.filter(employees, e => e.hobbies.some(e => e === 'Reading'))
   console.log("Hobby Filter", hobbyfilter);
     
  // get sum of all salaries
   let allEmpSal = _.map(employees, e => e.salary).reduce((acc, cur) => acc + cur , 0);
   console.log("All Employee Salaries", allEmpSal);
  
  // get average of salary of employees
   let avgSalEmp = _.map(employees, e => e.salary).reduce((acc, cur) => acc + cur, 0) / employees.length
   console.log("Average Employee Salary", avgSalEmp);
  
  // get max salary
   let maxSal = Math.max(...employees.map(e => e.salary));
   console.log(maxSal);
  // get min salary
  let minSal = Math.min(...employees.map(e => e.salary));
  console.log(minSal);
    
  // get all distinct job names
   let arrOfJobs = Array.from(new Set(employees.map(e => e.job)));
   console.log(arrOfJobs);
  
  // get distinct hobbies
   let arrOfHobbies = Array.from(new Set(employees.map(e => e.hobbies).flat())) // flat() method sub arrays merge into single array
   console.log(arrOfHobbies);
  
  // get employee name and likes (hobbies). 
  // The likes is a string as "Like hobby1/hobby2/hobby3". The likes will be created from hobbies array
  let nameLikes = _.map(employees, e => ({ name : e.name, Likes : e.hobbies.join("/")}));
  console.log(nameLikes);
  
  // remove employee having id 1010
  let removeIndex = _.findIndex(employees, e => e.id === 1010); // index is 1
  console.log(removeIndex);
  
  employees.splice(1, 1); // removeIndex or 1
  console.log(employees);

  
  // get sum of salary department wise
  let depwiseSal = Array.from(new Set(employees.map(e => e.department))).map(dep => ({
    dep,
    salary : employees.filter(e => e.department === dep).map(e => e.salary).reduce((acc, cur) => acc + cur, 0)
  }));
  console.log(depwiseSal);
  
  // get employees name and code whose name starts with alphabet "e" (case insensitive)
   let nameSearch = _.filter(employees, e => e.name.toLocaleLowerCase().startsWith('a'));
   console.log(nameSearch);
  
  // get employees name and code whose name ends with alphabet "n" (case insensitive)
   let nameSearchEnding = _.filter(employees, e => e.name.toLowerCase().endsWith('n'));
   console.log(nameSearchEnding);
  
  // get employees name and code whose name have "tly"
  let specifyName = employees.filter(i => i.name.toLowerCase().search('tly') !== -1);
  console.log('get employees name and code whose name have "tly":', specifyName);

}  

ngOnInit(): void {

}

}

