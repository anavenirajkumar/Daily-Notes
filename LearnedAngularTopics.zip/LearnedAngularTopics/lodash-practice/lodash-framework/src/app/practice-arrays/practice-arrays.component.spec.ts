import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticeArraysComponent } from './practice-arrays.component';

describe('PracticeArraysComponent', () => {
  let component: PracticeArraysComponent;
  let fixture: ComponentFixture<PracticeArraysComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PracticeArraysComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PracticeArraysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
