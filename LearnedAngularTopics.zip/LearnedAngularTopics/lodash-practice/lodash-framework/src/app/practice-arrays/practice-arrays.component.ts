import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';

@Component({
  selector: 'app-practice-arrays',
  templateUrl: './practice-arrays.component.html',
  styleUrls: ['./practice-arrays.component.css']
})
export class PracticeArraysComponent implements OnInit {
  
  public employees:any;

  public searchName:any; 

  public options = [ { id : 0, name: "Accending"}, { id : 1, name: "Dessending"}, {id : 2, name : 'Default'}];

  public Orderby:any;

  constructor() { 
    const employees = [
      {
          "code": "CT7207",
          "salary": 40000,
          "id": 1007,
          "job": "Manager",
          "department": "Operations",
          "name": "Bently Smith",
          "hobbies": ["Sports", "Reading", "Painting"]
      },
      {
          "code": "CT7210",
          "salary": 80000,
          "id": 1010,
          "job": "Director",
          "department": "Operations",
          "name": "Isla Morris",
          "hobbies": ["Sports", "Reading"]
      },
      {
          "code": "CT7202",
          "salary": 15000,
          "id": 1002,
          "job": "Salesman",
          "department": "Sales",
          "name": "Allen Green",
          "hobbies": ["Sports", "Painting"]
      },
      {
          "code": "CT7208",
          "salary": 60000,
          "id": 1008,
          "job": "Analyst",
          "department": "Research",
          "name": "Xavier Campbell",
          "hobbies": ["Reading", "Painting"]
      },
      {
          "code": "CT7209",
          "salary": 50000,
          "id": 1009,
          "job": "Analyst",
          "department": "Research",
          "name": "Ethan Kumar",
          "hobbies": ["Crafting", "Painting"]
      },
      {
          "code": "CT7201",
          "salary": 20000,
          "id": 1001,
          "job": "Clerk",
          "department": "Accounting",
          "name": "John Marshal",
          "hobbies": ["Singing", "Painting"]
      },
      {
          "code": "CT7205",
          "salary": 15000,
          "id": 1005,
          "job": "Salesman",
          "department": "Sales",
          "name": "Ethan Almaas",
          "hobbies": ["Singing", "Dancing"]
      },
      {
          "code": "CT7211",
          "salary": 15000,
          "id": 1011,
          "job": "Salesman",
          "department": "Sales",
          "name": "Natalie Robinson",
          "hobbies": ["Writing"]
      },
      {
          "code": "CT7212",
          "salary": 15000,
          "id": 1012,
          "job": "Salesman",
          "department": "Sales",
          "name": "Earl Rose",
          "hobbies": ["Singing", "Sports"]
      },
      {
          "code": "CT7206",
          "salary": 20000,
          "id": 1006,
          "job": "Clerk",
          "department": "Accounting",
          "name": "Ilija Seifert",
          "hobbies": ["Singing", "Cooking"]
      },
      {
          "code": "CT7204",
          "salary": 20000,
          "id": 1004,
          "job": "Clerk",
          "department": "Accounting",
          "name": "Annette Burke",
          "hobbies": ["Reading", "Teaching"]
      },
      {
          "code": "CT7203",
          "salary": 15000,
          "id": 1003,
          "job": "Salesman",
          "department": "Sales",
          "name": "Fernando Gordon",
          "hobbies": []
      },
      {
          "code": "CT7213",
          "salary": 15000,
          "id": 1013,
          "job": "Salesman",
          "department": "Sales",
          "name": "Catherine Foster",
          "hobbies": []
      }
  ];

  this.employees = employees;
 
// get 'employee' data with this id '1003'

let employee = _.find(employees, e => e.id === 1003);
console.log(employee);

// 'findindex; of an employee having id 1008

let empIndex = _.findIndex(employees, e => e.id === 1008);
console.log(empIndex);

// get department of 'Operations' employees only
let depOperations = _.filter(employees, e => e.department === 'Operations');
console.log(depOperations);

// get employees having salary greater than 40K
let above40k = _.filter(employees, e => e.salary > 40000);
console.log(above40k);

// get number of employees having salary greater than 50K and from Research department
let depResearch = _.filter(employees, e => e.salary > 50000 && e.department === 'Research');
console.log(depResearch);

// get only 'name' and 'salary' of all employees
let nameSal = _.map(employees, e => ({ name : e.name, salary : e.salary}));
console.log(nameSal);

// get only 'name' 'job' and 'annualsalary' of all employees
let nameJobAnualSal = _.map(employees, e => ({name : e.name, job : e.department, anualSal : e.salary * 12}));
console.log(nameJobAnualSal);

// get only 'firstname' and 'lastname' of all employees
let flname = _.map(employees, e => {
  let fn = e.name.split(" ");
  //console.log(fn);
  return { firtName : fn[0], lastName : fn[1]}
});
console.log(flname);

// Add firstName and LastName Space between FirstName and LastName
let fullName = _.map(flname, e => {
  let fn = e.firtName + " " + e.lastName;
  //console.log(fn);
  return { Name : fn}
});
console.log(fullName);

// get 'name' and 'salary' of employees having salary greater than 10K but less than 20K ordered by name
let nameSorting = _.filter(employees, e => e.salary >= 10000 && e.salary <= 50000).map(e => ({name : e.name, salary : e.salary})).sort((a,b) => {
  let n1 = a.name.toLowerCase(); // a
  let n2 = b.name.toLowerCase(); // b
  if(n1 < n2){
    return -1;
  } else if(n1 > n2){
    return 1;
  } else {
    return 0;
  }
});
console.log(nameSorting);

// return true if all employees having salary greater than 10K
let all10k = _.every(employees, e => e.salary > 10000);
console.log(all10k);

// return true if any employee is having salary greater than 60K
let any50k = _.some(employees, e => e.salary > 50000);
console.log(any50k);

// get employees whose hobbies is 'Reading'
let arrayofArray = _.filter(employees, e => e.hobbies.some(e => e === 'Reading'));
console.log(arrayofArray);

// get sum of all salaries
let allSal = _.map(employees, e => e.salary).reduce((acc, cur) => acc + cur, 0);
console.log(allSal);

// get 'average' of salary of employees
let avgSal = _.map(employees, e => e.salary).reduce((acc, cur) => acc + cur, 0) / employees.length;
console.log(avgSal);

// get max salary
let maxSal = Math.max(...employees.map(e => e.salary));
console.log(maxSal);

// get min salary
let minSal = Math.min(...employees.map(e => e.salary));
console.log(minSal);

// get all 'job' names
let jobNames = Array.from(new Set(employees.map(e => e.department)));
console.log(jobNames);

// get all 'hobbies' names
let hobbiesNames = Array.from(new Set(employees.map(e => e.hobbies).flat()));
console.log(hobbiesNames);

// get employee 'name' and likes:'a/b/c/d'. 
let nameLikes = _.map(employees, e => ({ name : e.name, Likes : e.hobbies.join("/")}));
console.log(nameLikes);

// remove employee having id 1010
let getIndex = _.findIndex(employees, e => e.id === 1010);
console.log(getIndex);

employees.splice(getIndex, 1);
console.log(employees);

// get sum of salary department wise
let depWiseSal = Array.from(new Set(employees.map(e => e.department))).map((dep) => ({
  dep,
  salary : employees.filter(e => e.department === dep).map(e => e.salary).reduce((acc, cur) => acc + cur)
}));
console.log(depWiseSal);

// get employees name and code whose name starts with alphabet "e" (case insensitive)
let nameSearch = _.filter(employees, e => e.name.toLowerCase().startsWith("e"));
console.log(nameSearch);

// get employees name and code whose name ends with alphabet "n" (case insensitive)
let endwithN = _.filter(employees, e => e.name.toLowerCase().endsWith("n"));
console.log(endwithN);

// get employees name and code whose name have "tly" using search()
let searchtly = _.filter(employees, e => e.name.toLowerCase().match('tly'));
console.log(searchtly);

}

ngOnInit(): void {
  this.searchName = this.employees;
}

public search(e:any){
  console.log(e.target.value);
  let searchedName = e.target.value;
  if(searchedName.length > 0){
    this.searchName = _.filter(this.employees, e => e.name.toLowerCase().match(searchedName));
  } else if(searchedName == "") {
    this.searchName = this.employees;
  }
}

public OrderbySalary(){
  console.log(this.Orderby);
  if(this.Orderby == 0){
    this.employees.sort((a:any,b:any) => {
      let n1 = a.name.toLowerCase();
      let n2 = b.name.toLowerCase();
      if(n1 < n2){
        return -1;
      } else if(n1 > n2){
        return 1;
      } else {
        return 0;
      }
    })
  } else if(this.Orderby == 1){
      this.employees.sort((a:any,b:any) => {
      let n1 = a.name.toLowerCase();
      let n2 = b.name.toLowerCase();
      if(n1 > n2){
        return -1;
      } else if(n1 < n2){
        return 1;
      } else {
        return 0;
      }
    })
  }
}

}
