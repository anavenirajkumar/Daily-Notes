import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CurrentYearMonthComponent } from './current-year-month/current-year-month.component';
import { DisableSelectedOptionsComponent } from './disable-selected-options/disable-selected-options.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { LodashComponent } from './lodash/lodash.component';
import { PracticeArraysComponent } from './practice-arrays/practice-arrays.component';

const routes: Routes = [
  {path : 'current-month-year', component : CurrentYearMonthComponent},
  {path : 'lodash', component : LodashComponent},
  {path : 'practice', component : PracticeArraysComponent},
  {path : 'file-upload', component : FileUploadComponent},
  {path : 'disable-selected-dropdowns', component : DisableSelectedOptionsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
