import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-current-year-month',
  templateUrl: './current-year-month.component.html',
  styleUrls: ['./current-year-month.component.css']
})
export class CurrentYearMonthComponent implements OnInit {

  public years:string[] = [];
  public selectedMonthOrYear: string | any;
  public curr_year:any;

  ///
  public months: any[] = moment.months();  
  public currentMonthsInCurrentYear:any;

  // 
  public yearsTwo: number[] = [];
  public currentDate = new Date() // or "07/27/2022";
  public selectedYear:any;

   ngOnInit() {
    this.curr_year = moment(moment().toDate(), 'DD/MM/YYYY').year();
    console.log("Current Year", this.curr_year);

    let curr_month = moment(moment().toDate(), 'DD/MM/YYYY').month();
    console.log("Current Month", curr_month);

    this.selectedMonthOrYear = this.curr_year.toString() + ',' + (curr_month + 1).toString(); // 2022,7 -> 7 is Current Month

    this.years.push(this.selectedMonthOrYear);
    do{
       this.years.push(this.curr_year.toString());
       this.curr_year--
    } while(2018 <= this.curr_year)

    console.log("Total Years", this.years);
   
    console.log("Total Year Months", this.months);

    this.currentMonthsInCurrentYear = this.months.filter((m) => +moment(this.currentDate).month("July").format('M') >= +moment(this.currentDate).
    month(m).format('M'));
    //console.log(this.currentMonthsInCurrentYear);
    console.log("CurrentYearMonths", this.currentMonthsInCurrentYear);
    this.months = this.currentMonthsInCurrentYear;
    
     this.yearsTwo = [new Date(this.currentDate).getFullYear(), new Date(this.currentDate).getFullYear() - 1, new Date(this.currentDate).getFullYear() - 2];
     console.log("YearsTwo", this.yearsTwo);

     this.months.unshift('Select a Month'); // when page loads adding this string
  
    } 


  public onYearSelect(event: any) {
    this.selectedYear = event.target.value;
    if (this.selectedYear === moment(this.currentDate).subtract(1, 'years').format('YYYY')) {
        this.months = moment.months();
        this.months.unshift('Select a Month');
    } else if (this.selectedYear === moment(this.currentDate).subtract(2, 'years').format('YYYY')) {
      this.months = moment.months();
      this.months.unshift('Select a Month');
    } else if (this.selectedYear === moment(this.currentDate).subtract(3, 'years').format('YYYY')) {
      this.months = moment.months();
      this.months.unshift('Select a Month');
    } else if (this.selectedYear === moment(this.currentDate).subtract(4, 'years').format('YYYY')) {
      this.months = moment.months();
      this.months.unshift('Select a Month');
    }
    else { this.months = this.currentMonthsInCurrentYear; }
    console.log(this.months);
  }
}
