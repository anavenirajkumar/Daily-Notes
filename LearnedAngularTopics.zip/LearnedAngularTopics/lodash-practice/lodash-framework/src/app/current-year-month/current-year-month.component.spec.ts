import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentYearMonthComponent } from './current-year-month.component';

describe('CurrentYearMonthComponent', () => {
  let component: CurrentYearMonthComponent;
  let fixture: ComponentFixture<CurrentYearMonthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CurrentYearMonthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentYearMonthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
