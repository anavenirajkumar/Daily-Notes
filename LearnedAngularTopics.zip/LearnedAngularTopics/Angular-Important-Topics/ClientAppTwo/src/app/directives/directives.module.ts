import { NgModule } from "@angular/core";
import { DirectiveComponent } from "./directive.component";
import { DirectivesRoutingModule } from "./directive.routing.module";
import { AdvanceDirective } from "./directive/advance-directive";
import { NormalDirective } from "./directive/normal-directive";

@NgModule({
    declarations : [DirectiveComponent,NormalDirective,AdvanceDirective],
    imports : [DirectivesRoutingModule]
})
export class DirectivesModule {}