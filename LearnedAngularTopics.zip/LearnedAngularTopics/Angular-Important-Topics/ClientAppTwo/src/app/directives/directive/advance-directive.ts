import { Directive, ElementRef, HostBinding, HostListener, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[appAdvance]',
})
export class AdvanceDirective {
    @Input() fromParent :any;
    @HostBinding('style.backgroundColor') backgroundColor: any; // defining the directive for where this is using for apply all -> appAdvance

  constructor(private element:ElementRef) {}

  ngOnInit() {
    this.element.nativeElement.style.color = this.fromParent;
  }

  @HostListener('mouseenter') mouseover(eventData: Event) { // mouse hover chesinappudu
    this.backgroundColor = 'purple';
  }

  @HostListener('mouseleave') mouseleave(eventData: Event) { // mouse leave chesinappudu
    this.backgroundColor = 'green';
  }
  
}
