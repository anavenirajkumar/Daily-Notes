import { Directive, ElementRef, OnInit } from '@angular/core';

@Directive({
  selector: '[appNormal]',
})
export class NormalDirective {
  constructor(private elementRef: ElementRef) {}

  ngOnInit() {
    this.elementRef.nativeElement.style.color = 'red';
  }
}
