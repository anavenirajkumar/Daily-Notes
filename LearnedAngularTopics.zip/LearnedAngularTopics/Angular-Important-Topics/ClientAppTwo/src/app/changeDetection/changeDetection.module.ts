import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ChangeDetectionStrategyComponent } from "./changeDetection.component";
import { ChangeDetectionStrategyRoutingModule } from "./changeDetection.routing.module";
import { ChangeDetectionStrategyComponentOne } from "./components/changeDetection.component-one";
import { ChangeDetectionStrategyComponentTwo } from "./components/changeDetection.component-two";

@NgModule({
    declarations : [ChangeDetectionStrategyComponent,ChangeDetectionStrategyComponentOne,ChangeDetectionStrategyComponentTwo],
    imports : [CommonModule,ChangeDetectionStrategyRoutingModule,FormsModule]
})
export class ChangeDetectionStrategyModule{}