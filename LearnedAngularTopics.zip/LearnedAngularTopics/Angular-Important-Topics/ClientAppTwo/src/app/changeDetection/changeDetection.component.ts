import { ChangeDetectionStrategy, Component, OnInit } from "@angular/core";

@Component({
    selector : 'app-detechChanges',
    templateUrl : './changeDetection.component.html',
    styles : [''],
    changeDetection : ChangeDetectionStrategy.OnPush // OnPush Pedithe "Root" component nundi changes check cheyadu, only e component varake changes check chestundi.
})
export class ChangeDetectionStrategyComponent implements OnInit{
    public name:string = '';
    constructor(){}
    ngOnInit() {
        
    }

    public test(){
     console.log("Parent Component test Method Called")
    }
}