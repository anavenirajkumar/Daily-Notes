import { ChangeDetectionStrategy, Component, OnInit } from "@angular/core";

@Component({
    selector : 'app-detechChanges-two',
    templateUrl : './changeDetection.component-two.html',
    styles : [''],
    changeDetection : ChangeDetectionStrategy.OnPush
})
export class ChangeDetectionStrategyComponentTwo implements OnInit{
    constructor(){}
    ngOnInit() {
        
    }
    public test(){
        console.log("Nested Child Component test Method Called"); // changeDetection vadakapothe -> "Parent" component lo amyna changes ithe prathisari call avuthundi. 
    }

    public test2(){
        console.log("Nested Child Component test2 Method Called"); //  changeDetection vadithe (ChangeDetectionStrategy.OnPush) pedithe -> "Parent" component lo changes ina kuda Call avvadu
    }
}