import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnInit, SimpleChanges } from "@angular/core";

@Component({
    selector : 'app-detechChanges-one',
    templateUrl : './changeDetection.component-one.html',
    styles : [''],
   // changeDetection : ChangeDetectionStrategy.OnPush  
})
export class ChangeDetectionStrategyComponentOne implements OnInit,OnChanges{
    @Input() name :any;
    constructor(private cdr: ChangeDetectorRef){}
    ngOnInit() {
      
    }

    ngOnChanges(changes: SimpleChanges) {
        
    }
    
    public test(){
        console.log("Child Component test Method Called"); // changeDetection vadakapothe -> "Parent" component lo amyna changes ithe prathisari call avuthundi. 
    }

    public test2(){
        console.log("Child Component test2 Method Called"); //  changeDetection vadithe (ChangeDetectionStrategy.OnPush) pedithe -> "Parent" component lo changes ina kuda Call avvadu
    }
}