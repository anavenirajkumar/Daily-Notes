import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ViewEncapsulationComponent } from "./view-encapsulation";

const routes:Routes = [
  {path : '', component : ViewEncapsulationComponent}
];

@NgModule({
    imports : [RouterModule.forChild(routes)],
    exports : [RouterModule]
})
export class ViewEncapsulationRoutingModule {}