import { Component, OnInit, ViewEncapsulation } from "@angular/core";

@Component({
    selector : 'app-view-encapsulation',
    templateUrl : './view-encapsulation.html',
    styles : [''],
    encapsulation : ViewEncapsulation.Emulated // default component
})
export class ViewEncapsulationComponent implements OnInit{
    constructor(){}
    ngOnInit() {
        
    }
}