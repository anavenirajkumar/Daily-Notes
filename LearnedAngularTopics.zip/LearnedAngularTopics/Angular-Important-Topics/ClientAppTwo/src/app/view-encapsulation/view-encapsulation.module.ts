import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ViewEncapsulationComponentOne } from "./components/view-encapsulation-one";
import { ViewEncapsulationComponentTwo } from "./components/view-encapsulation-two";
import { ViewEncapsulationComponent } from "./view-encapsulation";
import { ViewEncapsulationRoutingModule } from "./view-encapsulation.routing.module";

@NgModule({
    declarations : [ViewEncapsulationComponent,ViewEncapsulationComponentOne,ViewEncapsulationComponentTwo],
    imports : [CommonModule, ViewEncapsulationRoutingModule]
})
export class ViewEncapsulationModule {}