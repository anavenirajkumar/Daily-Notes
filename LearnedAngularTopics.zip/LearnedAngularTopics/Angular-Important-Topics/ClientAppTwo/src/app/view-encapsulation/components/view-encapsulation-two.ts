import { Component, OnInit, ViewEncapsulation } from "@angular/core";

@Component({
    selector : 'app-view-encapsulation-two',
    templateUrl : './view-encapsulation-two.html',
    styles : [''],
    encapsulation : ViewEncapsulation.ShadowDom
})
export class ViewEncapsulationComponentTwo implements OnInit{
    constructor(){}
    ngOnInit() {
         
    }
}