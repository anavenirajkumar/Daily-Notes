import { Component, OnInit, ViewEncapsulation } from "@angular/core";

@Component({
    selector : 'app-view-encapsulation-one',
    templateUrl : './view-encapsulation-one.html',
    styleUrls : ['./view-encapsulation-one.css'],
    encapsulation : ViewEncapsulation.None
})
export class ViewEncapsulationComponentOne implements OnInit{
    constructor(){}
    ngOnInit() {
         
    }
}