import { AfterContentChecked, AfterContentInit, Component, ContentChild, ContentChildren, OnInit } from "@angular/core";

@Component({
    selector : 'app-content-projection-one',
    templateUrl : './content-projection.one.html',
    styles : ['']
})
export class ContentProjectionComponentOne implements OnInit, AfterContentInit, AfterContentChecked{
    @ContentChild('colorOne') colorOne :any;
    @ContentChild('colorTwo') colorTwo :any;
    @ContentChildren('numbers') numbers:any;
     constructor(){}
     ngOnInit() {
         
     }

     ngAfterContentInit(): void {
         this.colorOne.nativeElement.style.color = 'green';
         this.colorTwo.nativeElement.style.color = 'red';
         for(let i = 0; i<this.numbers.length; i++){
            if(i % 2 == 0){
                this.numbers._results[i].nativeElement.style.color = 'blue';
            } else{
                this.numbers._results[i].nativeElement.style.color = 'purple';
            }
         }
     }
     ngAfterContentChecked() {
        // if html elements changes then applying the colors
        console.log(this.numbers);
        for(let i = 0; i<this.numbers.length; i++){
            if(i % 2 == 0){
                this.numbers._results[i].nativeElement.style.color = 'blue';
            } else{
                this.numbers._results[i].nativeElement.style.color = 'purple';
            }
         }        
     }
}