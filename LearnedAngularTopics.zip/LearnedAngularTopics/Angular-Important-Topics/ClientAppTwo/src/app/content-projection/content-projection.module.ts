import { NgModule } from "@angular/core";
import { ContentProjectionComponentOne } from "./components/content-projection.one";
import { ContentProjectionRoutingModule } from "./content-projection-routing.module";
import { ContentProjectionComponent } from "./content-projection";
import { CommonModule } from "@angular/common";

@NgModule({
    declarations : [ContentProjectionComponent,ContentProjectionComponentOne],
    imports : [CommonModule, ContentProjectionRoutingModule]
})
export class ContentProjectionModule{}