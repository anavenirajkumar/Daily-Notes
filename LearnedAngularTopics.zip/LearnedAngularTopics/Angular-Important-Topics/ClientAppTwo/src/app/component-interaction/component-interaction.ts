import { Component, OnInit, ViewChild } from '@angular/core';
import { ComponentInteractionComponentOne } from './components/component-interaction-one';

@Component({
  selector: 'app-component-interaction',
  templateUrl: './component-interaction.html',
  styles: ['']
})
export class ComponentInteractionComponent implements OnInit {
  @ViewChild(ComponentInteractionComponentOne, { static: false }) child!: ComponentInteractionComponentOne;
  public total = 0;
  constructor() { }
  ngOnInit() {

  }

  public callChildMethod() {
    this.total = this.child.setCount(1);
  }
}
