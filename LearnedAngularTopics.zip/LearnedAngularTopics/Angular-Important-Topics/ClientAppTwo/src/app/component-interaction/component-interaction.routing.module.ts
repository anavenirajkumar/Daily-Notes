import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ComponentInteractionComponent } from "./component-interaction";

const routes:Routes = [
    { path: '', component: ComponentInteractionComponent }
];

@NgModule({
    imports : [RouterModule.forChild(routes)],
    exports : [RouterModule]
})
export class ContentInteractionRoutingModule{}