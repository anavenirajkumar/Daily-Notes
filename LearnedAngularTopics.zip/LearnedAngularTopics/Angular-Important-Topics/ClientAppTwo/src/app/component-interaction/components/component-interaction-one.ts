import { Component, OnInit, ViewChild } from '@angular/core';
import { ComponentInteractionComponentTwo } from './component-interaction-two';

@Component({
  selector: 'app-component-interaction-one',
  templateUrl: './component-interaction-one.html',
  styles: ['']
})
export class ComponentInteractionComponentOne implements OnInit {
  public count = 0;
  @ViewChild(ComponentInteractionComponentTwo, { static: false }) child!: ComponentInteractionComponentTwo;
  constructor() { }
  ngOnInit() {

  }

  public setCount(count: any) {
    this.count = this.count + count;
    let total = this.child.setCount(1); 
    return this.count + total;
  }
}

