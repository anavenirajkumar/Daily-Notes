import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-interaction-two',
  templateUrl: './component-interaction-two.html',
  styles: ['']
})
export class ComponentInteractionComponentTwo implements OnInit {
  public count = 0;
  constructor() { }
  ngOnInit() {

  }

  public setCount(count: any) {
    return this.count = this.count + count;
  }
}
