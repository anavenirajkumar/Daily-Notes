import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ComponentInteractionComponent } from "./component-interaction";
import { ContentInteractionRoutingModule } from "./component-interaction.routing.module";
import { ComponentInteractionComponentOne } from "./components/component-interaction-one";
import { ComponentInteractionComponentTwo } from "./components/component-interaction-two";

@NgModule({
    declarations: [ComponentInteractionComponent, ComponentInteractionComponentOne, ComponentInteractionComponentTwo],
    imports : [CommonModule,ContentInteractionRoutingModule]
})
export class ContentInteractionModule{}