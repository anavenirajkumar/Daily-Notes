import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-styles',
  templateUrl: './component-styles.component.html',
  styleUrls: ['./component-styles.css']
})
export class ComponentStyleComponent implements OnInit {
  public name='styles';
  public color = 'green';
  public valid: boolean = true;
  public dynamicVarible = 'dynamic';
  public numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  public numbersTwo = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];

  constructor() { }
  ngOnInit(): void {

  }

  public objColor = {
    color: 'red'
  }


  public applyGreen() {
      this.objColor.color = 'green';
  }

  public getClassName() {
    return "invalid";
  }

  /*  public rondomColors(each: any) {
      // rondom colors apply
      if (each) {
        let eachColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
        return eachColor;
      }
    }*/

}
