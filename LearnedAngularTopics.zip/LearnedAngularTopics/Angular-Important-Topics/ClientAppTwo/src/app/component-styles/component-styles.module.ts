import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ComponentStyleComponent } from "./component-styles.component";
import { ComponentStylesRoutingModule } from "./component-styles.routing.module";

@NgModule({
  declarations: [ComponentStyleComponent],
  imports: [CommonModule, ComponentStylesRoutingModule]
})
export class ComponentStylesModule {}
