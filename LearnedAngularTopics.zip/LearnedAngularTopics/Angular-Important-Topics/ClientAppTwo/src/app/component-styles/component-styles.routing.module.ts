import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { ComponentStyleComponent } from "./component-styles.component";

const routes = [
  { path: '', component: ComponentStyleComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComponentStylesRoutingModule { }
