import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ChildComponent } from "./components/child-component";
import { NestedChildComponent } from "./components/nested-child-component";
import { InputOutputRoutingModule } from "./inputoutput.routing.module";
import { ParentComponent } from "./parent-component";

@NgModule({
    declarations : [ParentComponent,ChildComponent,NestedChildComponent],
    imports : [CommonModule,InputOutputRoutingModule]
})
export class InputOutputModule {}