import { AfterViewChecked, AfterViewInit, Component, ElementRef, OnInit, ViewChild, ViewChildren } from "@angular/core";

@Component({
    selector : 'app-parent',
    templateUrl : './parent-component.html',
    styles : ['']
})
export class ParentComponent implements OnInit,AfterViewInit,AfterViewChecked{
    @ViewChildren('coursesColors') coursesColors:any;
    @ViewChild('docheck') docheck:any;

    public courses:string[] = ['Angular','.Net','SQL'];
    public sendMessage:string = '';
    public childMessage:string = '';
    constructor(){}
    ngOnInit() {
        
    }
    ngAfterViewInit() {
        console.log("ngAfterViewInit Called");
        this.docheck.nativeElement.style.color = 'blue';
        // this.docheck.nativeElement.setAttribute('style', 'background-color:red');
        console.log(this.coursesColors);
        for(let i = 0; i <this.coursesColors.length; i++){
            if(i % 2 == 0){
                this.coursesColors._results[i].nativeElement.style.color = 'green';
            } else{
                this.coursesColors._results[i].nativeElement.style.color = 'red';   
            }
        }
    }

    ngAfterViewChecked(){
        console.log("ngAfterViewChecked PARENT");
        for(let i = 0; i <this.coursesColors.length; i++){
            if(i % 2 == 0){
                this.coursesColors._results[i].nativeElement.style.color = 'green';
            } else{
                this.coursesColors._results[i].nativeElement.style.color = 'red';   
            }
        }
    }
    public sendMsgChild(event:any){
       this.sendMessage = event.target.value;
    }

    public checkNgDoCheck(){
        this.courses.push('Test');
    }
}