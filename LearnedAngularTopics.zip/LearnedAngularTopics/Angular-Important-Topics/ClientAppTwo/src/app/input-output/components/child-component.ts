import { AfterViewChecked,EventEmitter, AfterViewInit, Component, DoCheck, ElementRef, Input, OnChanges, OnInit, Output, QueryList, SimpleChange, SimpleChanges, ViewChild, ViewChildren, ChangeDetectionStrategy, } from "@angular/core";

@Component({
    selector : 'app-child',
    templateUrl : './child-component.html',
    styles : [''],
    //changeDetection : ChangeDetectionStrategy.OnPush // perticular component changes ni matrame check chestundi & ngOnInit initial inappudu changes check cheyadu
})
export class ChildComponent implements OnInit, OnChanges, DoCheck, AfterViewInit, AfterViewChecked{

    @ViewChildren('courseColors') public courseColors:any
    @Input() public sendMessage: any;
    @Input() public courses :any;
    @Output() sendtoParent = new EventEmitter<any>();
    public receiveDatafromChild:string = '';
    constructor(){}

    ngOnInit()  {
        
    }
    ngOnChanges(changes:SimpleChanges){
        console.log("ngOnChanges Called Child");
        const values:SimpleChange = changes['sendMessage'];
        console.log(values);
    }

    ngDoCheck() {
        console.log("ngDoCheck Called Child");
        console.log(this.courses);
    }

    ngAfterViewInit(): void {
        console.log("ngAfterViewInit Called Child");
        for(let i = 0; i<this.courseColors.length; i++){
            if(i % 2 == 0){
                this.courseColors._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColors._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    ngAfterViewChecked(): void {
        console.log("ngAfterViewChecked Called Child");
        console.log(this.courses);
        for(let i = 0; i<this.courseColors.length; i++){
            if(i % 2 == 0){
                this.courseColors._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColors._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    public receiveChild(data:any){
       this.receiveDatafromChild = data;
       this.sendtoParent.emit(this.receiveDatafromChild);
    }
    
}