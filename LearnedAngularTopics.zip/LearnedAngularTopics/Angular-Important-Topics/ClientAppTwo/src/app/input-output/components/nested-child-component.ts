import { Component, Input, OnInit,EventEmitter, Output, SimpleChange, SimpleChanges, ViewChildren } from "@angular/core";

@Component({
    selector : 'app-nested-child',
    templateUrl : './nested-child-component.html',
    styles : ['']
})
export class NestedChildComponent implements OnInit{
    @ViewChildren('courseColors') public courseColors:any
    @Input() public sendMessage :any;
    @Input() public courses:any;
    @Output() sendParent = new EventEmitter<any>();
    public sendMessageParent:string = '';
    constructor(){}
    ngOnInit(){
        
    }
    ngOnChanges(changes:SimpleChanges){
        console.log("ngOnChanges Called Nested Child");
        const values:SimpleChange = changes['sendMessage'];
        console.log(values);
    }

    ngDoCheck() {
        console.log("ngDoCheck Called Nested Child");
        console.log(this.courses);
    }

    ngAfterViewInit(): void {
        console.log("ngAfterViewInit Called Nested Child");
        for(let i = 0; i<this.courseColors.length; i++){
            if(i % 2 == 0){
                this.courseColors._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColors._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    ngAfterViewChecked(): void {
        console.log("ngAfterViewChecked Called Nested Child");
        console.log(this.courses);
        for(let i = 0; i<this.courseColors.length; i++){
            if(i % 2 == 0){
                this.courseColors._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColors._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    public sendMsgParent(event:any){
       this.sendMessageParent = event.target.value;
       this.sendParent.emit(this.sendMessageParent);
    }
}