import { Component, OnInit } from "@angular/core";

@Component({
    selector : 'app-elemets',
    templateUrl : './elements.component.html',
    styles : ['']
})
export class ElementsComponents implements OnInit{
    constructor(){}
    ngOnInit() {
       
       // creating main div and appending the body
       // let div = document.createElement('div'); // anni pages lo create avuthundi it is very bad.
       // div.className = 'container';
       // appending div to body
       // document.body.appendChild(div);

       let div = document.getElementById('div');  // get by id from html
       
       // create row
       let row = document.createElement('div');
       row.className = 'row';
        
       // create col
       let col = document.createElement('div');
       col.className = 'col-md-12';
       div?.appendChild(row);
       row.appendChild(col);

       // creating h4 tag
       let h4 = document.createElement('h4');
       h4.innerHTML = 'Elements';
       h4.style.color = 'red';
       col.appendChild(h4);

       // creating the child div in "main div"
       let childDiv = document.querySelector('.col-md-12');
       let subDiv:any = document.createElement('div'); // child div
       subDiv.className = 'elements';
       childDiv?.appendChild(subDiv);

       // creating elements
       let p1 = document.createElement('p');
       p1.innerHTML = 'Paragraph 1';
       p1.style.color = 'blue';
       subDiv.appendChild(p1);

       let p2 = document.createElement('p');
       p2.innerHTML = 'Paragraph 2';
       p2.style.color = 'red';
       subDiv.appendChild(p2);

       let p3 = document.createElement('p');
       p3.innerHTML = 'Paragraph 3';
       p3.style.color = 'purple';
       subDiv.appendChild(p3);

       let p4 = document.createElement('p');
       p4.innerHTML = 'Paragraph 4';
       p4.style.color = 'brown';
       subDiv.appendChild(p4);

       // insertbefore 
       let p5 = document.createElement('p');
       p5.innerHTML = 'Paragraph 5';
       p5.style.color = 'orange';
       subDiv.insertBefore(p5,p1);

       // applying the styles to h4 tag using with "Child div"
       console.log(subDiv);
       subDiv.parentElement.childNodes[0].style.color = 'red';

    }
}