import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ElementsComponents } from "./elements.component";
import { ElementsRoutingModule } from "./elements.routing.module";

@NgModule({
    declarations : [ElementsComponents],
    imports : [CommonModule, ElementsRoutingModule]
})
export class ElementsModule{}