import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path : 'inputoutput', loadChildren : () => import('./input-output/inputoutput.module').then(m=>m.InputOutputModule)},
  {path : 'lifecycles', loadChildren : () => import('./lifecycles/lifecycles.module').then(m=>m.LifecyclesModule)},
  {path : 'content-projection', loadChildren : () => import('./content-projection/content-projection.module').then(m=>m.ContentProjectionModule)},
  {path : 'elements', loadChildren : () => import('./elements/elements.module').then(m=>m.ElementsModule)},
  {path : 'view-encapsulation', loadChildren : () => import('./view-encapsulation/view-encapsulation.module').then(m=>m.ViewEncapsulationModule)},
  {path : 'dynamic', loadChildren:()=>import('./dynamic-component/dynamic.module').then(m=>m.DynamicModule)},
  {path : 'directives', loadChildren : () => import('./directives/directives.module').then(m=>m.DirectivesModule)},
  {path : 'changedetects', loadChildren : () => import('./changeDetection/changeDetection.module').then(m=>m.ChangeDetectionStrategyModule)},
  {path : 'component-interaction', loadChildren : () => import('./component-interaction/component-interaction.module').then(m => m.ContentInteractionModule)},
  { path: 'component-styles', loadChildren: () => import('./component-styles/component-styles.module').then(m => m.ComponentStylesModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
