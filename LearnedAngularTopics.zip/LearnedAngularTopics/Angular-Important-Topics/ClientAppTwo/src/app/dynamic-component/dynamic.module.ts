import { NgModule } from "@angular/core";
import { ContentProjectionComponentOne } from "../content-projection/components/content-projection.one";
import { ContentProjectionComponent } from "../content-projection/content-projection";
import { ChildComponent } from "../input-output/components/child-component";
import { NestedChildComponent } from "../input-output/components/nested-child-component";
import { ParentComponent } from "../input-output/parent-component";
import { LifecycleComponentOne } from "../lifecycles/components/lifecycle-component-one";
import { LifecycleComponentTwo } from "../lifecycles/components/lifecycle-component-two";
import { LifecycleComponent } from "../lifecycles/lifecycle.component";
import { ViewEncapsulationComponentOne } from "../view-encapsulation/components/view-encapsulation-one";
import { ViewEncapsulationComponentTwo } from "../view-encapsulation/components/view-encapsulation-two";
import { ViewEncapsulationComponent } from "../view-encapsulation/view-encapsulation";
import { DynamicComponent } from "./dynamic-component";
import { DynamicRoutingModule } from "./dynamic.routing.module";

@NgModule({
    declarations : [DynamicComponent],
    imports : [DynamicRoutingModule],
    entryComponents : [ // import components for dynamic
        LifecycleComponent,
        LifecycleComponentOne,
        LifecycleComponentTwo, 
        ContentProjectionComponent,
        ContentProjectionComponentOne,
        ParentComponent,
        ChildComponent,
        NestedChildComponent,
        ViewEncapsulationComponent,
        ViewEncapsulationComponentOne,
        ViewEncapsulationComponentTwo    
    ] 
})
export class DynamicModule{}