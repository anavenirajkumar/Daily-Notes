import { Component, ComponentFactoryResolver, OnInit, ViewContainerRef } from "@angular/core";
import { interval } from "rxjs";
import { ContentProjectionComponent } from "../content-projection/content-projection";
import { ParentComponent } from "../input-output/parent-component";
import { LifecycleComponent } from "../lifecycles/lifecycle.component";
import { ViewEncapsulationComponent } from "../view-encapsulation/view-encapsulation";

@Component({
    selector : 'app-dynamic',
    templateUrl : './dynamic-component.html',
    styles : ['']
})
export class DynamicComponent implements OnInit{
    public componentRef:any;
    public count:number = 0;
    constructor(private resolver:ComponentFactoryResolver,private container:ViewContainerRef){}
    ngOnInit() {
        let component = this.resolver.resolveComponentFactory<LifecycleComponent>(LifecycleComponent);
        this.componentRef = this.container.createComponent<LifecycleComponent>(component);
        interval(1000).subscribe((count) => {
            this.count = this.count + 1;
            this.loadComponets()
        })
    }

    public loadComponets(){
        this.container.clear();
        if(this.count == 1){
            let contentProjectionComponent = this.resolver.resolveComponentFactory<ContentProjectionComponent>(ContentProjectionComponent);
            this.componentRef = this.container.createComponent<ContentProjectionComponent>(contentProjectionComponent);
            // this.componentRef = this.container.createComponent<ContentProjectionComponent>(ContentProjectionComponent);

        } else if(this.count == 2){
            let viewEncapsulationComponent = this.resolver.resolveComponentFactory<ViewEncapsulationComponent>(ViewEncapsulationComponent);
            this.componentRef = this.container.createComponent<ViewEncapsulationComponent>(viewEncapsulationComponent);
            // this.componentRef = this.container.createComponent<ViewEncapsulationComponent>(ViewEncapsulationComponent)
        } else if(this.count == 3){
            let inputOutputComponents = this.resolver.resolveComponentFactory<ParentComponent>(ParentComponent);
            this.componentRef = this.container.createComponent<ParentComponent>(inputOutputComponents);
            // this.componentRef = this.container.createComponent<ParentComponent>(ParentComponent);
            this.count = 0;
        }
    }
}