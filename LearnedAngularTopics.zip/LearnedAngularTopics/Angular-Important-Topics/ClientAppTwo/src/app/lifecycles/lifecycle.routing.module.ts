import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LifecycleComponent } from "./lifecycle.component";

const routes:Routes = [
   {path : '', component : LifecycleComponent}
];

@NgModule({
    imports : [RouterModule.forChild(routes)],
    exports : [RouterModule]
})
export class LifecyclesRoutingModule{}