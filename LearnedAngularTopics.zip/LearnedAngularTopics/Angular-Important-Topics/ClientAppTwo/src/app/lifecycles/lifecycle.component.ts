import { AfterViewChecked, AfterViewInit, Component, ElementRef, OnInit, ViewChildren } from "@angular/core";

@Component({
    selector : 'app-lifecycles',
    templateUrl: './lifecycle.component.html',
    styles : ['']
})
export class LifecycleComponent implements OnInit, AfterViewInit, AfterViewChecked{
    public textMessage:string = '';
    public courses:string[] = ['Angular','.Net','SQL'];
    public nestedChildMessage:string = '';
    @ViewChildren('courseColor') courseColor:any;
    constructor(){}
    ngOnInit(): void {
        
    }

    ngAfterViewInit() {
        // html page loded after
        for(let i = 0; i < this.courseColor.length; i++){
            if(i % 2 == 0){
                this.courseColor._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColor._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    ngAfterViewChecked() {
        // when html element changes then this method call
        for(let i = 0; i < this.courseColor.length; i++){
            if(i % 2 == 0){
                this.courseColor._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColor._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    public sendMessage(event:any){
       this.textMessage = event.target.value;
    }

    public checkngDoCheck(){
        this.courses.push('Test');
    }
}