import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { LifecycleComponentOne } from "./components/lifecycle-component-one";
import { LifecycleComponentTwo } from "./components/lifecycle-component-two";
import { LifecycleComponent } from "./lifecycle.component";
import { LifecyclesRoutingModule } from "./lifecycle.routing.module";

@NgModule({
    declarations : [LifecycleComponent,LifecycleComponentOne,LifecycleComponentTwo],
    imports : [CommonModule, LifecyclesRoutingModule]
})
export class LifecyclesModule{}