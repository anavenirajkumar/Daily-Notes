import {AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChange, SimpleChanges, ViewChildren} from '@angular/core';

@Component({
    selector : 'app-lifecycle-one',
    templateUrl : './lifecycle-component-one.html',
    styles : ['']
})
export class LifecycleComponentOne implements OnInit,OnChanges,DoCheck,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {
    
    @Input() public textMessage:any;
    @Input() public courses:any;
    public childMessage:string = '';
    @Output() sendData = new EventEmitter<any>();
    @ViewChildren('courseColor') courseColor:any;

    constructor(){}
    ngOnChanges(changes: SimpleChanges) {
        const values:SimpleChange = changes['textMessage'];
        console.log(values);
        console.log("ngOnChanges Array Changes", this.courses);
    }
    ngOnInit() {
        console.log('ngOnInit');
    }

    ngDoCheck() {
        console.log("ngDoCheck Array Changes", this.courses);
    }
 
     ngAfterContentInit() {
        // Content Projection -> parent html data transfering to child component then Html page Initial then this mathod call
     }
     ngAfterContentChecked() {
        // Content Projection html elements changes then this method call
     }
     ngAfterViewInit() {
        // html page loded after
        for(let i = 0; i < this.courseColor.length; i++){
            if(i % 2 == 0){
                this.courseColor._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColor._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    ngAfterViewChecked() {
        // when html element changes then this method call
        for(let i = 0; i < this.courseColor.length; i++){
            if(i % 2 == 0){
                this.courseColor._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColor._results[i].nativeElement.style.color = 'red';
            }
        }
    }
    ngOnDestroy() {
        
    }
    public receiveData(data:any){
       this.childMessage = data;
       this.sendData.emit(data);
    }
}