import {AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChange, SimpleChanges, ViewChildren} from '@angular/core';

@Component({
    selector : 'app-lifecycle-two',
    templateUrl : './lifecycle-component-two.html',
    styles : ['']
})
export class LifecycleComponentTwo implements OnInit,OnChanges,DoCheck,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {
    
    @Input() public textMessage:any;
    @Input() public courses:any;
    @Output() sendData = new EventEmitter<any>();
    public sendMsg:string = '';
    @ViewChildren('courseColor') courseColor:any;

    constructor(){}


    ngOnChanges(changes: SimpleChanges) {
        const values:SimpleChange = changes['textMessage'];
        console.log(values);
        console.log("ngOnChanges Array Changes", this.courses);
    }
    ngOnInit() {
        console.log('ngOnInit');
    }

    ngDoCheck() {
        console.log("ngDoCheck Array Changes", this.courses);
    }
    ngAfterContentChecked() {
       // Content Projection html elements changes then this method call
    }

    ngAfterContentInit() {
        //Content Projection Html page loaded then this mathod call
    }
    ngAfterViewInit() {
        // html page loded after
        for(let i = 0; i < this.courseColor.length; i++){
            if(i % 2 == 0){
                this.courseColor._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColor._results[i].nativeElement.style.color = 'red';
            }
        }
    }

    ngAfterViewChecked() {
        // when html element changes then this method call
        for(let i = 0; i < this.courseColor.length; i++){
            if(i % 2 == 0){
                this.courseColor._results[i].nativeElement.style.color = 'green';
            } else{
                this.courseColor._results[i].nativeElement.style.color = 'red';
            }
        }
    }
  
    ngOnDestroy() {
        
    }

    public sendMessage(event:any){
        this.sendMsg = event.target.value;
        this.sendData.emit(this.sendMsg);
     }
}