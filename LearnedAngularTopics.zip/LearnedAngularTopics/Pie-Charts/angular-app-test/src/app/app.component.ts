import { AfterViewInit, Component, Inject, OnInit, Renderer2,ViewChild } from '@angular/core';
import { DOCUMENT } from '@angular/common';
declare const CanvasJS: any;

//
import * as Highcharts from 'highcharts';
import highcharts3d from 'highcharts/highcharts-3d';
highcharts3d(Highcharts);

//
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_animated);

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, AfterViewInit {
  title = 'angular-app-test';
  public name:any;
  public names = ['T', 'V','T', 'V','T', 'V'];
  count = 0;
  // example 2
  public activity: any;
  public xData: any;
  public label: any;
  options: any;
  public obsoleteTires = [
    {
        id: 1,
        partNumber: 'TMI0011387',
        inventoryQty: 3,
        aroControlledFlag: 'Yes',
        lastOrder: '01/26/2022',
        nonReturnable: 2,
        returnable: 1,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 2,
        partNumber: 'TPR1935900',
        inventoryQty: 4,
        aroControlledFlag: 'No',
        lastOrder: '',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 3,
        partNumber: 'TH30424807',
        inventoryQty: 2,
        aroControlledFlag: 'No',
        lastOrder: '12/28/2020',
        nonReturnable: 2,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 4,
        partNumber: 'TFS0002768',
        inventoryQty: 4,
        aroControlledFlag: 'Yes',
        lastOrder: '07/08/2021',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 5,
        partNumber: 'TBR0000439',
        inventoryQty: 4,
        aroControlledFlag: 'Yes',
        lastOrder: '07/08/2021',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 6,
        partNumber: 'Y732941500',
        inventoryQty: 2,
        aroControlledFlag: 'No',
        lastOrder: '',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 7,
        partNumber: 'TYK0002074',
        inventoryQty: 4,
        aroControlledFlag: 'No',
        lastOrder: '',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 8,
        partNumber: 'TBR0011918',
        inventoryQty: 2,
        aroControlledFlag: 'No',
        lastOrder: '07/01/2021',
        nonReturnable: 2,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 9,
        partNumber: 'TBR0094903',
        inventoryQty: 2,
        aroControlledFlag: 'No',
        lastOrder: '06/22/2021',
        nonReturnable: 2,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 10,
        partNumber: 'Y109086382',
        inventoryQty: 1,
        aroControlledFlag: 'No',
        lastOrder: '07/23/2021',
        nonReturnable: 1,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 11,
        partNumber: 'TMI0003266',
        inventoryQty: 4,
        aroControlledFlag: 'Yes',
        lastOrder: '06/21/2022',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 12,
        partNumber: 'TPR2655100',
        inventoryQty: 4,
        aroControlledFlag: 'No',
        lastOrder: '04/12/2022',
        nonReturnable: 4,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 13,
        partNumber: 'TYK0032370',
        inventoryQty: 2,
        aroControlledFlag: 'No',
        lastOrder: '',
        nonReturnable: 2,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 14,
        partNumber: 'TYK0033523',
        inventoryQty: 2,
        aroControlledFlag: 'No',
        lastOrder: '',
        nonReturnable: 2,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
    {
        id: 15,
        partNumber: 'TN16312NXK',
        inventoryQty: 1,
        aroControlledFlag: 'No',
        lastOrder: '',
        nonReturnable: 1,
        returnable: 0,
        showPartNumber: false,
        showInventory : false,
        showAro : false,
        showLastOrder : false,
        shownonReturnable : false
    },
]
  public phaseIn = [
     {
       id: 1,
       phaseInPart : 'Y151093203',
       yearlyPurchase : 15,
       aro : "Yes",
       sum : 5,
       showPhaseInPart : false,
       showPurchase : false
     },
     {
      id: 2,
      phaseInPart : 'Y1510434204',
      yearlyPurchase : 10,
      aro : "No",
      sum : 10,
      showPhaseInPart : false,
      showPurchase : false
    },
    {
      id: 3,
      phaseInPart : 'Y151093205',
      yearlyPurchase : 5,
      aro : "Yes",
      sum : 15,
      showPhaseInPart : false,
      showPurchase : false
    }
  ];
  public showInventory:any;
  public showARONumber:any;
  public showAROBool:boolean = false;
  public checkBool:boolean =false;
  constructor(
    private _renderer2: Renderer2,
    @Inject(DOCUMENT) private _document: Document
  ) {
    // example 2
    this.options = {
      chart: {
        type: 'pie',
        options3d: {
          enabled: true,
          alpha: 45,
          beta: 0,
        },
      },
      title: {
        text: 'Browser market shares',
      },
      accessibility: {
        point: {
          valueSuffix: '%',
        },
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>',
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          depth: 35,
          dataLabels: {
            enabled: true,
            format: '{point.name}',
          },
        },
      },
      series: [
        {
          type: 'pie',
          name: 'Browser share',
          data: [
            ['Chrome', 45.0],
            ['IE', 26.8],
            // {
            //   name: 'Firefox',
            //   y: 12.8,
            //   sliced: true,
            //   selected: true,
            // },
            // ['Safari', 8.5],
            // ['Opera', 6.2],
            // ['Others', 0.7],
          ],
        },
      ],
    };
  }
  ngAfterViewInit() {
    // let script = this._renderer2.createElement('script');
    // script.type = `text/javascript`;
    // script.text = ``;
    // script.src = `assets/js/code.js`
    // this._renderer2.appendChild(this._document.body, script);
    // console.log(script); 
   }
  ngOnInit() {
    // example 2
    
    Highcharts.chart('container', this.options);


    this.loadScriptByAngularWay();
    window.onload = function () {
      var chart = new CanvasJS.Chart("chartContainer", {
        theme: "light2",
        title: {
          text: "FCA"
        },
        data: [
          {
            type: "pie",
              enabled: true,
              alpha: 45,
              beta: 0,
            
            showInLegend: true,
            toolTipContent: "{y} - #percent %",
            yValueFormatString: "#,##0,,.## Million",
            legendText: "{indexLabel}",
            dataPoints: [
              { y: 69, indexLabel: `69%` },
              { y: 3.4, indexLabel: `3.4%` },
              { y: 27.6, indexLabel: `27.6%` }
            ]
          }
        ]
      });
      chart.render();
    };

    let chart = am4core.create("chartdiv", am4charts.PieChart3D);
    chart.fill = am4core.color("#ff5200");
    //chart.stroke = am4core.color("#ff5200");
chart.hiddenState.properties.opacity = 0; // this creates initial fade-in
chart.angle = 45; // angel
chart.legend = new am4charts.Legend();

chart.data = [{
  "country": "ARO",
  "litres": 60,
  "color": am4core.color("#0083ff")
}, {
  "country": "Spord",
  "litres": 40,
  "color": am4core.color("#e57b28") //#93d170, #f1ce00,#ff8f36

}];

var pieSeries = chart.series.push(new am4charts.PieSeries3D());
pieSeries.dataFields.value = "litres";
pieSeries.dataFields.category = "country";
pieSeries.slices.template.propertyFields.fill = "color";

// chart.legend = new am4charts.Legend();
// let series = chart.series.push(new am4charts.PieSeries3D());
// series.dataFields.value = "litres";
// series.dataFields.category = "country";

let piechart = am4core.create("divchart", am4charts.PieChart3D);
piechart.fill = am4core.color("#ff5200");
piechart.angle = 0;
piechart.hiddenState.properties.opacity = 0; 
piechart.legend = new am4charts.Legend();

chart.data = [{
    "country": "69.0",
    "litres": 69.0,
    "color": am4core.color("#93d170")
}, {
    "country": "27.8", //#93d170, #f1ce00,#ff8f36
    "litres": 27.8,
    "color": am4core.color("#f1ce00")
},
{
    "country": "3.4",
    "litres": 3.4,
    "color": am4core.color("#ff8f36")

}];
}

public loadScriptByAngularWay() {

  // let script = this._renderer2.createElement('script');
  // script.type = `text/javascript`;
  // script.text = ``;
  // script.src = `assets/js/code.js`
  // this._renderer2.appendChild(this._document.body, script);
  // console.log(script);

  let script = this._renderer2.createElement('script');
  script.type = `text/javascript`;
  script.text = ``;
  script.src = `https://canvasjs.com/assets/script/canvasjs.min.js`
  this._renderer2.appendChild(this._document.body, script);
  console.log(script);
}
 

  public partNumberColumn(number:any,event:any){
       this.obsoleteTires.forEach((ele:any, i:number) => {
         if(ele.id === number && event.target.checked){
             ele.showPartNumber = true;
         } else if(ele.id === number && event.target.checked === false){
            ele.showPartNumber = false;
         }
       })
  }

  public inventoryColumn(number:any,event:any){
    if(number){
       this.obsoleteTires.forEach((ele:any) => {
         if(ele.inventoryQty === number && event.target.checked && ele.showPartNumber === false){
           ele.showInventory = true;
         } else if(ele.inventoryQty === number && event.target.checked === false && ele.showInventory === true){
           ele.showInventory = false;
         }
       })
    } 
}

public AROColumn(qty:any,aroFlag:any, event:any){
    if(qty){

      // 1) using same qty
      // this.obsoleteTires.forEach((ele) => {
      //   if(ele.inventoryQty === qty &&  ele.aroControlledFlag === aroFlag && ele.showAro === false && event.target.checked && ele.showPartNumber === false && ele.showInventory === false){
      //       ele.showAro = true;
      //   } else if(ele.inventoryQty === qty &&  ele.aroControlledFlag === aroFlag && ele.showAro === true && event.target.checked === false && ele.showPartNumber === false && ele.showInventory === false){
      //      ele.showAro = false;
      //   }
      // })


      // 2) using only aroControlledFlagS => "YES", "NO"
      this.obsoleteTires.forEach((ele) => {
        if(ele.aroControlledFlag === aroFlag && ele.showAro === false && event.target.checked && ele.showPartNumber === false && ele.showInventory === false){
            ele.showAro = true;
        } else if(ele.aroControlledFlag === aroFlag && ele.showAro === true && event.target.checked === false && ele.showPartNumber === false && ele.showInventory === false){
           ele.showAro = false;
        }
      })
    }
}

public lastOrderColumn(lastOrder:any, event:any){
  this.obsoleteTires.forEach((ele) => {
    if(ele.lastOrder === lastOrder && ele.showLastOrder === false && event.target.checked && ele.showPartNumber === false && ele.showInventory === false){
        ele.showLastOrder = true;
    } else if(ele.lastOrder === lastOrder && ele.showLastOrder === true && event.target.checked === false && ele.showPartNumber === false && ele.showInventory === false){
       ele.showLastOrder = false;
    }
  })
}

public nonReturnbleColumn(nonReturnable:any, event:any){
    this.obsoleteTires.forEach((ele) => {
        if(ele.nonReturnable === nonReturnable && ele.shownonReturnable === false && event.target.checked && ele.showPartNumber === false && ele.showInventory === false && ele.showAro === false){
            ele.shownonReturnable = true;
        } else if(ele.nonReturnable === nonReturnable && ele.shownonReturnable === true && event.target.checked === false && ele.showPartNumber === false && ele.showInventory === false){
           ele.shownonReturnable = false;
        }
      })
}

public phaseInPart(id:any, event:any){
    if(id != ""){
       this.phaseIn.forEach((ele) => {
           if(ele.id === id && ele.showPhaseInPart === false && event.target.checked){
               ele.showPhaseInPart = true;
           } else if(ele.id === id && ele.showPhaseInPart === true){
            ele.showPhaseInPart = false;
           }
       })
    }
}

public purchase(qty:any,event:any){  
this.phaseIn.forEach((ele) => {
        if(ele.yearlyPurchase === qty && ele.showPhaseInPart === false && ele.showPurchase === false && event.target.checked){
            ele.showPurchase = true;
        } else if(ele.yearlyPurchase === qty && ele.showPhaseInPart === false && event.target.checked === false){
           ele.showPurchase = false;
        }
      })
}

public check(name :any){
    if(name === 'T'){
      this.name = name;
      return "Tire"
    } else{
      this.name = name;
       return "Vehicle";
    }
}

public submit(name:any){
  console.log(name);
}

  
}







/////////////////////////////////
// 1) 