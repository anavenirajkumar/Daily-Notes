import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PieChartComponent } from './components/pie-chart/pie-chart.component';
// import { HighchartsChartModule } from 'highcharts-angular';
import { HighchartsComponent } from './components/highcharts/highcharts.component';
import { AmChartsComponent } from './components/am-charts/am-charts.component';
import { AngularHighchartsComponent } from './components/angular-highcharts/angular-highcharts.component';
import { Angular4PieChartsComponent } from './components/angular4-pie-charts/angular4-pie-charts.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    PieChartComponent,
    HighchartsComponent,
    AmChartsComponent,
    AngularHighchartsComponent,
    Angular4PieChartsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
    // HighchartsChartModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
