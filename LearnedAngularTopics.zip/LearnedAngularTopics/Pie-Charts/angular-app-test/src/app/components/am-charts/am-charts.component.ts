import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";
am4core.useTheme(am4themes_animated);
@Component({
  selector: 'app-am-charts',
  templateUrl: './am-charts.component.html',
  styleUrls: ['./am-charts.component.css']
})
export class AmChartsComponent implements OnInit {

  constructor() { }
  public ngOnInit() {
      // chart 1
      let chart = am4core.create("chartdiv", am4charts.PieChart3D);
      chart.fill = am4core.color("#ff5200");
      //chart.stroke = am4core.color("#ff5200");
      chart.hiddenState.properties.opacity = 0; // this creates initial fade-in
      chart.angle = 45; // angel
      chart.legend = new am4charts.Legend();

      chart.data = [{
          "country": "ARO",
          "litres": 60,
          "color": am4core.color("#0083ff")
      }, {
          "country": "Spord",
          "litres": 40,
          "color": am4core.color("#e57b28")

      }];

      var pieSeries = chart.series.push(new am4charts.PieSeries3D());
      pieSeries.dataFields.value = "litres";
      pieSeries.dataFields.category = "country";
      pieSeries.slices.template.propertyFields.fill = "color";
      // chart.legend = new am4charts.Legend();
      // let series = chart.series.push(new am4charts.PieSeries3D());
      // series.dataFields.value = "litres";
      // series.dataFields.category = "country";

      let piechart = am4core.create("divchart", am4charts.PieChart);
      piechart.fill = am4core.color("#ff5200");
      //piechart.angle = 0;
      piechart.hiddenState.properties.opacity = 0; 
      piechart.legend = new am4charts.Legend();

      piechart.data = [{
          "country": "69.0%",
          "litres": 69.0,
          "color": am4core.color("#93d170")
      }, {
          "country": "27.8%", //#93d170, #f1ce00,#ff8f36
          "litres": 27.8,
          "color": am4core.color("#f1ce00")
      },
      {
          "country": "3.4%",
          "litres": 3.4,
          "color": am4core.color("#ff8f36")

          }];
      var pie = piechart.series.push(new am4charts.PieSeries());
      pie.dataFields.value = "litres";
      pie.dataFields.category = "country";
      pie.slices.template.propertyFields.fill = "color";
  }

}
