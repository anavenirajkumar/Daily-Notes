import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts'; // Angular 4 Old Version this 'line' was Not Require

@Component({
  selector: 'app-angular4-pie-charts',
  templateUrl: './angular4-pie-charts.component.html',
  styleUrls: ['./angular4-pie-charts.component.css']
})
export class Angular4PieChartsComponent implements OnInit {

  public pieChart3DData = [  
     ['ARO' , 60],
     ['Spord', 40]
  ]
public pieChartData = [ 
['69.0%', 69.0],
['27.8%', 27.8],
['3.4%', 3.4]]
  constructor() { }

  ngOnInit() {
    // Latest-PieCharts-3D-Working on Angular-4 Old Version Using Script Code  or index.html "script" code
    Highcharts.chart('pieChart3D', {
      title: {
          text: ''
      },
      chart: {
          type: 'pie',
          options3d: {
              enabled: true,
              alpha: 45,
              beta: 0
          }
      },
      credits: {
          enabled: false,
      },
      colors: ['#0083ff', '#e57b28'],
      accessibility: {
          enabled: false,
          point: {
              valueSuffix: '%'
          }
      },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              depth: 35,
              showInLegend : true,
              dataLabels: {
                  enabled: true,
                  format: '{point.name}',

              }
          }
      },
      series: [
        {
          type: 'pie',
          name: 'Share',
          data: [...this.pieChart3DData]
      }]
  });

  Highcharts.chart('pieChartOne', {
    title: {
        text: ''
    },
    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 0,
            beta: 0
        },
    },
    credits: {
        enabled: false,
    },
    colors: ['#93d170', '#f1ce00', '#ff8f36'],
    accessibility: {
        enabled: false,
        point: {
            valueSuffix: '%'
        }
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            showInLegend: true,
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },
    series: [{
        type: 'pie',
        name: 'Share',
        data: [...this.pieChartData]
    }]
});
  }

}
