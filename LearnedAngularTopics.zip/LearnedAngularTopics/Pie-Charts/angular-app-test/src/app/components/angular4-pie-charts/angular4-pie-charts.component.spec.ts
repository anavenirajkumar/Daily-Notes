import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Angular4PieChartsComponent } from './angular4-pie-charts.component';

describe('Angular4PieChartsComponent', () => {
  let component: Angular4PieChartsComponent;
  let fixture: ComponentFixture<Angular4PieChartsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Angular4PieChartsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Angular4PieChartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
