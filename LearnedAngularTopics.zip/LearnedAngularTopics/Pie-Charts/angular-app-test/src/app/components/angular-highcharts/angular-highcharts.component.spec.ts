import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularHighchartsComponent } from './angular-highcharts.component';

describe('AngularHighchartsComponent', () => {
  let component: AngularHighchartsComponent;
  let fixture: ComponentFixture<AngularHighchartsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AngularHighchartsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AngularHighchartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
