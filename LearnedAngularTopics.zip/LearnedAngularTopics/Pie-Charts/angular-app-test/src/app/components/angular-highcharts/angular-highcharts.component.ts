import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { NgModule, OnInit, ViewChild, ElementRef, VERSION, Renderer2, Inject } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Component } from '@angular/core';
import * as  Highcharts from 'highcharts';

// Load the exporting module.
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-angular-highcharts',
  templateUrl: './angular-highcharts.component.html',
  styleUrls: ['./angular-highcharts.component.css']
})
export class AngularHighchartsComponent implements OnInit {

  name = `Angular! v${VERSION.full}`;
  // @ViewChild("pieChartTwo", { read: ElementRef }) container: ElementRef | any;

  constructor() {
  }
  ngOnInit() {
    Highcharts.chart('pieChartTwo', {
      title: {
        text: ''
    },
      chart: {
          type: 'pie',
          options3d: {
              enabled: true,
              alpha: 45,
              beta: 0
          }
      },
      credits: {
        enabled: false,
      },
      colors: ['#0083ff', '#e57b28'],
      accessibility: {
          point: {
              valueSuffix: '%'
          }
      },
      tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
          pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              depth: 35,
              dataLabels: {
                  enabled: true,
                  format: '{point.name}',
                
              }
          }
      },
      series: [{
          type: 'pie',
          name: 'Share',
          data: [
              ['ARO', 60],
              ['Spord', 40]
          ],
          // startAngle: 0,
          // endAngle: 180
      }]
  });
    }
  } 
  


