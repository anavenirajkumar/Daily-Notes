import { NgModule } from '@angular/core';

// Angular Material Modules //
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatIconModule} from '@angular/material/icon';
import {MatBadgeModule} from '@angular/material/badge';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatSidenavModule} from '@angular/material/sidenav';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatMenuModule} from '@angular/material/menu';
import {MatListModule} from '@angular/material/list';
import {MatDividerModule} from '@angular/material/divider';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatRadioModule} from '@angular/material/radio';
import {MatTableModule} from '@angular/material/table';
import {MatCardModule} from '@angular/material/card';
import {MatTabsModule} from '@angular/material/tabs';
import {MatStepperModule} from '@angular/material/stepper';

import {MatFormFieldModule} from '@angular/material/form-field'; // for Input, Select, Textarea Fields
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatDatepickerModule} from '@angular/material/datepicker'; // for date picker
import { MatNativeDateModule } from '@angular/material/core'; // for date picker
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSortModule } from '@angular/material/sort'; // for table sorting
import { ScrollingModule } from '@angular/cdk/scrolling';
//import { MatPaginator } from '@angular/material/paginator'; // for paginator


const materialComponents = [MatButtonModule,ScrollingModule,MatDialogModule, MatSortModule,  MatSnackBarModule,MatTooltipModule,MatDatepickerModule,MatNativeDateModule, MatCheckboxModule,MatAutocompleteModule,MatSelectModule,MatRadioModule,MatInputModule,MatTableModule,MatExpansionModule,MatStepperModule,MatFormFieldModule,MatGridListModule,MatTabsModule,MatDividerModule,MatListModule,MatCardModule, MatMenuModule,MatSidenavModule,MatToolbarModule,MatProgressSpinnerModule,FormsModule, ReactiveFormsModule, MatBadgeModule, MatButtonToggleModule, MatIconModule]
@NgModule({
  imports: [materialComponents],
  exports : [materialComponents]
})
export class MaterialModule { }
