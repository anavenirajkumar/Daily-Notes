import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogEditComponent } from '../dialog-edit/dialog-edit.component';

export interface DialogData {
  animal: string;
  name: string;
}

@Component({
  selector: 'app-dialog-app',
  templateUrl: './dialog-app.component.html',
  styleUrls: ['./dialog-app.component.css']
})
export class DialogAppComponent implements OnInit {

  //public name:any;

  public user = {
    name  : '',
    email : '',
    mobile : ''
  }

  public animal:any;

  constructor(public dialog: MatDialog) {}
  
  ngOnInit(): void {
   
  }

  openDialog() {
    console.log("Dialog Clicked");
      const dialogRef = this.dialog.open(DialogEditComponent, {
        width: '250px',
        data: {name: this.user, animal: this.animal},
      });
  
      console.log("Enter Clicked");

      dialogRef.afterClosed().subscribe(result => {
        console.log('The dialog was closed');
        this.animal = result;
      });
     }
}


