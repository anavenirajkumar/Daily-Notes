import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from '../dialog-app/dialog-app.component';

@Component({
  selector: 'app-dialog-edit',
  templateUrl: './dialog-edit.component.html',
  styleUrls: ['./dialog-edit.component.css']
})
export class DialogEditComponent implements OnInit {

    public user:any; 

    constructor(
      public dialogRef: MatDialogRef<DialogEditComponent>,
      @Inject(MAT_DIALOG_DATA) public data: DialogData,
    ) {}

    ngOnInit() {
      // console.log(this.data);
       this.user = this.data;
    }
  
    onNoClick(): void {
      this.dialogRef.close();
    }


}
