import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.css']
})
export class DialogBoxComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<DialogBoxComponent>){}

  public user = {
    name : '',
    email : '',
    mobile : ''
  }

  public message:string = "Registration Successfully";
  public showMessage:boolean = false;

  ngOnInit(): void {
    
  }

  public register(){
    if(this.user.name !== '' && this.user.email !== '' && this.user.mobile !== ''){
      console.log(this.user);
      this.showMessage = true;
      setTimeout(() => {
         this.cancel();
      }, 1000);
    }
  }

  cancel() {
    this.dialogRef.close();
  }


}
