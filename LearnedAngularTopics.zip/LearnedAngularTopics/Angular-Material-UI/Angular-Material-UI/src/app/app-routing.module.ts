import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AngularMaterialComponent } from './angular-material/angular-material.component';
import { DialogAppComponent } from './dialog-app/dialog-app.component';
import { EncryptPasswordComponent } from './encrypt-password/encrypt-password.component';
import { FormBuilderComponent } from './form-builder/form-builder.component';
import { FormValidationComponent } from './form-validation/form-validation.component';

const routes: Routes = [
  {path : 'materialui', component : AngularMaterialComponent},
  {path : 'dialogbox', component : DialogAppComponent},
  {path : 'form-validation', component : FormValidationComponent},
  {path : 'validation', component : FormBuilderComponent},
  {path : 'encrypt-password', component : EncryptPasswordComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
