import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as CryptoJS from 'crypto-js';  


@Component({
  selector: 'app-encrypt-password',
  templateUrl: './encrypt-password.component.html',
  styleUrls: ['./encrypt-password.component.css']
})
export class EncryptPasswordComponent implements OnInit {

  constructor(private formBuilder: FormBuilder) { }

 public registerForm:any =  FormGroup;
 public submitted = false;

  //Add user form actions
  get f() { return this.registerForm.controls; }
  
  onSubmit() {
    
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }
    //True if all the fields are filled
    if(this.submitted)
    {
      //here we can see user form data in encrypted format in console
       
       console.log(CryptoJS.AES.encrypt( this.registerForm.value.email, "myemail").toString()); //email
       console.log(CryptoJS.AES.encrypt( this.registerForm.value.password, "mypassword").toString()); //password
      
    }
  
  }

  ngOnInit(){
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      });
  }

}
