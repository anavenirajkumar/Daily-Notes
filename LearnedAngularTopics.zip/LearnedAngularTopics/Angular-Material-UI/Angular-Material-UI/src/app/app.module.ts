import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// import Material Module
import { MaterialModule } from './material/material.module';
import { ReactiveFormsModule , FormsModule} from '@angular/forms';
import { CardsComponent } from './cards/cards.component';
import { DialogBoxComponent } from './dialog-box/dialog-box.component';
import { DialogAppComponent } from './dialog-app/dialog-app.component';
import { DialogEditComponent } from './dialog-edit/dialog-edit.component';
import { AngularMaterialComponent } from './angular-material/angular-material.component';
import { FormValidationComponent } from './form-validation/form-validation.component';
import { FormBuilderComponent } from './form-builder/form-builder.component';
import { EncryptPasswordComponent } from './encrypt-password/encrypt-password.component';

@NgModule({
  declarations: [
    AppComponent,
    CardsComponent,
    DialogBoxComponent,
    DialogAppComponent,
    DialogEditComponent,
    AngularMaterialComponent,
    FormValidationComponent,
    FormBuilderComponent,
    EncryptPasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    ReactiveFormsModule, 
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
