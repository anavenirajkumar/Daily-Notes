import { Component,OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar'; // SnackBar
import { MatDialog } from '@angular/material/dialog';
import { DialogBoxComponent } from '../dialog-box/dialog-box.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
// Tables
export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C'},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N'},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O'},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F'},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne'},
];

@Component({
  selector: 'app-angular-material',
  templateUrl: './angular-material.component.html',
  styleUrls: ['./angular-material.component.css']
})
export class AngularMaterialComponent implements OnInit, AfterViewInit {


  public minDateFrom :any;

  ngOnInit(): void {
    this.filterOption = this.myControl.valueChanges.pipe(startWith(''),
    map(value => this._filter(value)))

 }

 changeDate(){
  console.log(this.minDateFrom);
 }

 ngAfterViewInit(): void {
   this.dataSource.sort = this.sort; // for sorting
   this.dataSource.paginator = this.paginator; // for paginator

 }
 constructor(private snackBar: MatSnackBar,
            private dialogueBox : MatDialog){
         for(let i= 0; i<1000; i++){
            this.numbers.push(i);
         }
 }


 private _filter(value: string): string[] {
     const filterValue = value.toLowerCase();
     return this.options.filter((keyword) => keyword.toLowerCase().includes(filterValue));
 }

 title = 'angular-material';
 public Spinner:boolean = false;



 public selectedDropdown:any;

 public options:string[] = ["Angular", "ReactJS", "VuesJS", "Node JS", "C#", "JAVA"];

 public courses = [
   {name : 'Angular'},
   {name : 'React JS'},
   {name : 'Vue JS'},
   {name : 'C#'},
   {name : 'JAVA'},
   {name : 'Node JS'}
 ];

 // for autoComple KeyWord Filter
 public myControl = new FormControl()
 public filterOption:Observable<string[]> | any;

 public notification:number = 100;
 showSpinner(){
   this.Spinner = true; 
   setTimeout(() => {
     this.Spinner = false;
   }, 5000);
 }

 public opened:boolean = false;

// for DatePicker
public minDate = new Date();
public maxDate = new Date(2022, 11, 31); // 2022-jan-31
public dateFilter(date:any){
  const day = date.getDay();
  return day !=0 && day !=6; // disabling Sunday and Saturday
}
// Snackbar
public showSnackBar(msg:any, dismis:any){
 //this.snackBar.open(msg, dismis, {duration : 2000}); // dismiss  2seonds
 let ref =  this.snackBar.open(msg, dismis, {duration : 2000}); // dismiss  2seonds
 ref.afterDismissed().subscribe(() => {
   console.log("Action was Dismiss");
 });

 ref.onAction().subscribe(() => {
   console.log("Action was Triggered");
 });
}

// dialogueBox
public openDialog(){
 // this.dialogueBox.open(DialogBoxComponent)
 let ref =   this.dialogueBox.open(DialogBoxComponent);
 ref.afterClosed().subscribe((result)=> {
   console.log(`Dialog Result : ${result}`)
 });

}


public myChange(index:any){
    console.log(index);
 }

 public displayCourses(subject:any){
   return subject ? subject.name : undefined;
 }


 // Tables
 displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
 //dataSource = ELEMENT_DATA;
 dataSource = new MatTableDataSource(ELEMENT_DATA); // filter table

 public showDataTable(tableData:any){
   console.log(tableData)
 }

 public applyFilter(event:any){
   let eventValue = event.target.value;
   this.dataSource.filter = eventValue.trim().toLowerCase();
 }

 // for Sorting
 @ViewChild(MatSort) sort : MatSort | any;

 // for paginator
 @ViewChild(MatPaginator) paginator : MatPaginator | any;

 // for Scrolling
 public numbers:any = [];

}
