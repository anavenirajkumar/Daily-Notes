import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-form-validation',
  templateUrl: './form-validation.component.html',
  styleUrls: ['./form-validation.component.css']
})
export class FormValidationComponent implements OnInit {

  constructor(private formBuilder : FormBuilder) { }

  //public courses:string[]=['html','css','javascript','bootstrap','angular','reactjs']
  
  public courses:any = [
    {name : 'HTML'},
    {name : 'CSS'},
    {name : 'JavaScript'},
    {name : 'Angular'}
  ]

  public inputType : string = 'password';

  public showPassword2:boolean = false;

  public myForm: FormGroup | any;

  public genders:any = ['Male', 'Female', 'Others'];
  
  public countries:any = ['India', 'USA', 'UK', 'Japan'];

  ngOnInit(): void {
    // this.myForm = new FormGroup({
    //   name: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(20)]),
    //   email: new FormControl('', [Validators.required, Validators.maxLength(50)]),
    //   mobile: new FormControl('', [Validators.required, Validators.maxLength(10)])
    //   });

    this.myForm = this.formBuilder.group({
      name: ['',[Validators.required,Validators.minLength(5)]], 
      email : ['',[Validators.required, Validators.email]],
      phone: ['',[Validators.required,Validators.maxLength(10),Validators.minLength(10), Validators.pattern('[6-9]\\d{9}')]],
      date :  ['',[Validators.required]],
      password : ['',[Validators.required, Validators.minLength(8), 
         Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}')]],
      //conformpassword : ['',[Validators.required, Validators.minLength(8)]],
      showPassword: ['',false],
      address: ['', [Validators.required,
          Validators.minLength(20)]],
      address2: [''],
      AdreessCheckbox:['',false],
      course : ['',[Validators.required]],
      city : ['',[Validators.required]],

      // country : this.formBuilder.group({
      //   countryName : ['',[Validators.required,Validators.minLength(5)]],
      //   stateName : ['',[Validators.required,Validators.minLength(5)]],
      //   cityName: ['',[Validators.required,Validators.minLength(5)]]
      // }),
      gender: ['',[Validators.required]],
      isTCAccepted: ['',[Validators.requiredTrue]],
    });
  }


  public myError = (controlName: string, errorName: string) =>{
    return this.myForm.controls[controlName].hasError(errorName);
    }


    SubmitForm(){
      console.log(this.myForm.value)
      this.myForm.markAllAsTouched();
      if(this.myForm.valid){ // this.myForm.valid  && this.validatePassord()
        //this.myForm.value.password === this.myForm.value.conformpassword;
        console.log(this.myForm.value)
        //this.myForm.reset();
      }
    }


  public validatePassord(){
    // console.log(this.myForm.value.password);
    // console.log(this.myForm.value.conformpassword)
    console.log(this.myForm.value.password === this.myForm.value.conformpassword)

    return this.myForm.value.password === this.myForm.value.conformpassword;
  }


  public remember(e:any){
    console.log(e.checked);
    if(e.checked){
      // this.myForm.address2 = this.myForm.value.address;
      // console.log(this.myForm.address2)
      this.myForm.get('address2').setValue(this.myForm.value.address);
   }else{
    // this.myForm.address2 = '';
    this.myForm.get('address2').setValue('');

   }
  }

  public showPassword(){
    (this.inputType === 'password') ? this.inputType = 'text' : this.inputType = 'password';
  }

  // example 2
  public togglePasswordVisibility(): void {
    this.showPassword2 = !this.showPassword2;
  }
  
  public getToday(): string {
    return new Date().toISOString().split('T')[0]
 }

 public cities:any = [];

 public checked(event:any){
  
  // console.log(event);
   let filt = this.cities.findIndex((ele:any) => ele === event );
   console.log(filt);

   let filterCity = this.cities.filter((e:any) => e === event);
   if(filterCity.length){
    this.cities.splice(filt,1);
   } else{
    this.cities.push(event);
   }


   console.log(this.cities);
 }
 
}
