import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators, FormControl } from '@angular/forms';
@Component({
  selector: 'app-form-validations',
  templateUrl: './form-validations.component.html',
  styleUrls: ['./form-validations.component.css']
})
export class FormValidationsComponent implements OnInit {
  
  exform: FormGroup | any;
  submited:boolean = false;
  // address2 : any= '';
  // submitted = false;

  public courses:string[]=['html','css','javascript','bootstrap','angular','reactjs']
  public inputType:string= 'password'; //for password show and unshow
  ngOnInit() {
    this.exform = new FormGroup({
      name: new FormControl('', [Validators.required,Validators.pattern('[a-zA-Z ]*')]),
      email: new FormControl('', [Validators.required, Validators.email]),
      date : new FormControl('', [Validators.required]),
      password : new FormControl('',[Validators.required, Validators.minLength(8)]),
      // conformpassword : new FormControl('', [Validators.required, Validators.minLength(8)]),
      phone: new FormControl('', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"),Validators.maxLength(10)]
      // [
      //   Validators.required,
      //   Validators.pattern(
      //     '^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$'
      //   ),
      //   Validators.maxLength(10),
      // ]
      ),
      // add : new FormControl(this.add),
      address: new FormControl('', [
        Validators.required,
        Validators.minLength(20),
      ]),
      address2: new FormControl(''),
      course : new FormControl('',[Validators.required]),
      gender: new FormControl('', Validators.required),
      isTCAccepted: new FormControl('', Validators.requiredTrue)
      // acceptTerms: new FormControl([false, Validators.requiredTrue]),
    });
  }

  clicksub() {
    //debugger;
    this.submited =true;
    this.exform.markAllAsTouched();
    if(this.exform.valid){
      console.log(this.exform.value)
      this.exform.reset();
    }
    // console.log(this.exform.value);
    //this.exform.reset();
  }
  public name() {
    return this.exform.get('name');
  }
  public email() {
    return this.exform.get('email');
  }
  public password(){
    return this.exform.get('password')
  }
  // public conformpassword(){
  //   return this.exform.get('conformpassword')
  // }
  public phone() {
    return this.exform.get('phone');
  }
  public address() {
    return this.exform.get('address');
  }


  public getCourse(){
    return this.exform.get('course')
  }
  public date(){
    return this.exform.get('date')
  }

  public isTCAccepted() {
    //console.log(this.exform.value)
    return this.exform.get('isTCAccepted');
 }

 public gender(){
   return this.exform.get('gender')
 }

  // public acceptTerms(){
  //   return this.exform.get('acceptTerms')
  // }
  
  public remember(e:any){
    // console.log(this.exform.value.address2)
      if(e.target.checked){
      this.exform.address2 = this.exform.value.address;
      console.log(this.exform.address2);
      } else{
        this.exform.address2 = '';
      }
  }

  public showPassword(){
    (this.inputType === 'password') ? this.inputType = 'text' : this.inputType = 'password';
  }
  
}
