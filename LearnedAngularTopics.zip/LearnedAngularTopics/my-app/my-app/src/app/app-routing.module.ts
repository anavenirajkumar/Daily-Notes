import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CheckboxFilterTwoComponent } from './checkbox-filter-two/checkbox-filter-two.component';
import { CheckboxFilterComponent } from './checkbox-filter/checkbox-filter.component';
import { DataComponent } from './data/data.component';
import { DynamicDropdownTwoComponent } from './dynamic-dropdown-two/dynamic-dropdown-two.component';
import { DynamicDropdownComponent } from './dynamic-dropdown/dynamic-dropdown.component';
import { DynamicRowsThreeComponent } from './dynamic-rows-three/dynamic-rows-three.component';
import { DynamicRowsTwoComponent } from './dynamic-rows-two/dynamic-rows-two.component';
import { DynamicRowsComponent } from './dynamic-rows/dynamic-rows.component';
// import { FormValidationsComponent } from './form-validations/form-validations.component';
import { HttpComponent } from './http/http.component';
import { ReactiveFormBuilderComponent } from './reactive-form-builder/reactive-form-builder.component';
import { ReactiveFormsNgclassComponent } from './reactive-forms-ngclass/reactive-forms-ngclass.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { SearchFilterComponent } from './search-filter/search-filter.component';
import { SearchPipeComponent } from './search-pipe/search-pipe.component';
import { TemplateFormsComponent } from './template-forms/template-forms.component';

const routes: Routes = [
  {path : 'template-forms', component : TemplateFormsComponent},
  // {path : 'reactive-forms', component: FormValidationsComponent},
  {path : 'reactive-forms', component: ReactiveFormsComponent},
  {path : 'reactive-form-builder', component: ReactiveFormBuilderComponent},
  {path :  'data', component : DataComponent},
  {path : 'http', component : HttpComponent},
  {path : 'dynamic-rows', component : DynamicRowsComponent},
  {path : 'dynamic-rows-two', component : DynamicRowsTwoComponent},
  {path : 'dynamic-rows-three', component : DynamicRowsThreeComponent},
  {path : 'search-filter', component : SearchFilterComponent},
  {path : 'search-pipe', component : SearchPipeComponent},
  {path : 'checkbox-filter', component : CheckboxFilterComponent},
  {path : 'checkbox-filter-two', component : CheckboxFilterTwoComponent},
  {path : 'dynamic-dropdown', component : DynamicDropdownComponent},
  {path : 'dynamic-dropdown-two', component : DynamicDropdownTwoComponent},
  {path: 'reactiveforms', component : ReactiveFormsNgclassComponent},
  {path: 'contacts', loadChildren: () => import('./contacts/contacts.module').then(m => m.ContactsModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
