import { Component, OnInit } from '@angular/core';
import { IContactService } from '../services/icontact.service';
import { IContact } from '../model/IContact';
@Component({
  selector: 'app-search-pipe',
  templateUrl: './search-pipe.component.html',
  styleUrls: ['./search-pipe.component.css']
})
export class SearchPipeComponent implements OnInit {

  public contacts:IContact[]=[];

  public searchFilter:string = ''; // Search Filter
   
  constructor(private contactService : IContactService) { }

  ngOnInit(): void {
    this.contactService.getAllContacts().subscribe((data)=>{
      this.contacts = data;
    })
  }


}
