import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterSearch'
})
export class FilterSearchPipe implements PipeTransform {

  transform(value:any, searchFilter : string) {
     
    // Method 1
    // if(value.length === 0){
    //   return value
    // }
    //   const users = [];
    //   for(const user of value){
    //      if(user['name'] === searchFilter){
    //        users.push(user);
    //      }
    //   }
    //   return users;

    // Method 2

    // if (!value) {
    //   return [];
    // }
    // if (!searchFilter) {
    //   return value;
    // }
    // searchFilter = searchFilter.toLocaleLowerCase();

    // return value.filter((it:any) => {
    //   return it.toLocaleLowerCase().includes(searchFilter);
    // });

    if (searchFilter) {
      searchFilter = searchFilter.toLowerCase();
      //filter je filter() metod iz array.prototype.filter
      return value.filter(function (contact: any) {
   
          return ((contact.firstName.toLowerCase().indexOf(searchFilter)) && 
        (contact.name.toLowerCase().indexOf(searchFilter))) > -1;
         })
      }
      return value;

    // if (searchFilter) {
    //   return value.filter((val:any) => val.indexOf(searchFilter) >= 0);
    // } else {
    //   return value;
    // }
   
      }
  }
  



