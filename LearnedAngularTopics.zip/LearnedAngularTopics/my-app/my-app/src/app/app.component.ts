import { Component,Input,OnInit } from '@angular/core';
import { IContact } from './model/IContact';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';
  
  @Input() selectedContact:IContact | any  // Receive Data From Child

  ngOnInit() {

  }

}
