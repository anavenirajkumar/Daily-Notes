import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReactiveFormsNgclassComponent } from './reactive-forms-ngclass.component';

describe('ReactiveFormsNgclassComponent', () => {
  let component: ReactiveFormsNgclassComponent;
  let fixture: ComponentFixture<ReactiveFormsNgclassComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReactiveFormsNgclassComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReactiveFormsNgclassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
