import { Component, OnInit } from '@angular/core';
import { IUsers } from '../model/IUsers'; 
import { EmployeeService } from '../services/employee.service';
@Component({
  selector: 'app-http',
  templateUrl: './http.component.html',
  styleUrls: ['./http.component.css']
})
export class HttpComponent implements OnInit {

  constructor(private employeeService: EmployeeService) { }

  public data:IUsers[]= [];
  public show:IUsers[]= [];

  ngOnInit(): void {
    this.employeeService.fetchEmployees().subscribe((res)=>{
       this.data = res;
    })
  }

  public getData(){
    this.employeeService.fetchEmployees().subscribe((res)=>{
      this.show = res;
    })
  }

}
