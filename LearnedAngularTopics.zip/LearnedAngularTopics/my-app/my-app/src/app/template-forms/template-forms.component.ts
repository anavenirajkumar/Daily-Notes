import { Component, OnInit } from '@angular/core';
import { IUser } from '../model/IUser';

@Component({
  selector: 'app-template-forms',
  templateUrl: './template-forms.component.html',
  styleUrls: ['./template-forms.component.css']
})
export class TemplateFormsComponent implements OnInit {

  public user:IUser = {
    username: '',
    email :'',
    date : '',
    password: '',
    mobile : '',
    address : '',
    address2 : '',
    course : '',
    gender : '',
    isTCAccepted : ''
  };
  public isSubmitted:boolean = false;
  public courses:string[] = ['Angular' , 'React JS' , 'Ionic' , 'React Native'];
  constructor() { }

  ngOnInit(): void {
  }

  public submitEnroll(){
    console.log(this.user)
    this.isSubmitted = true;
    let {username , email , date, password ,mobile, address, address2, course, gender,isTCAccepted} = this.user;
    if(username !== '' && email !== '' && date !== '' && password !== '' && mobile !== '' && address !== '' && address2 !== '' && course !== '' && gender !== '' && isTCAccepted !== ''){
          console.log(this.user)   
    }
    else {
      this.isSubmitted = false;
    }
  }

  public remember(e:any){
    if(e.target.checked){
      this.user.address2 = this.user.address;
      console.log(this.user.address2)
    }
    else{
      this.user.address2 = '';
    }
  }


}
