import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormValidationsComponent } from './form-validations/form-validations.component';
import { DataComponent } from './data/data.component';
import { HttpClientModule } from '@angular/common/http';
import { NavbarComponent } from './navbar/navbar.component';
import { HttpComponent } from './http/http.component';
import { TemplateFormsComponent } from './template-forms/template-forms.component';
import { ReactiveFormsComponent } from './reactive-forms/reactive-forms.component';
import { DynamicRowsComponent } from './dynamic-rows/dynamic-rows.component';
import { SearchFilterComponent } from './search-filter/search-filter.component';
import {Ng2SearchPipeModule} from 'ng2-search-filter'; /// Search Filter
import {NgxPaginationModule} from 'ngx-pagination'; /// Search Filter
import {Ng2OrderModule} from 'ng2-order-pipe'; /// Search Filter
import {MatTableModule} from '@angular/material/table';
import { CheckboxFilterComponent } from './checkbox-filter/checkbox-filter.component';
import { DynamicDropdownComponent } from './dynamic-dropdown/dynamic-dropdown.component';
import { SearchPipeComponent } from './search-pipe/search-pipe.component';
import { FilterSearchPipe } from './search-pipe/pipes/filter-search.pipe';
import { DynamicDropdownTwoComponent } from './dynamic-dropdown-two/dynamic-dropdown-two.component';
import { ReactiveFormBuilderComponent } from './reactive-form-builder/reactive-form-builder.component';
import { CheckboxFilterTwoComponent } from './checkbox-filter-two/checkbox-filter-two.component';
import { DynamicRowsTwoComponent } from './dynamic-rows-two/dynamic-rows-two.component';
import { DynamicRowsThreeComponent } from './dynamic-rows-three/dynamic-rows-three.component';
import { ReactiveFormsNgclassComponent } from './reactive-forms-ngclass/reactive-forms-ngclass.component';


@NgModule({
  declarations: [
    AppComponent,
    FormValidationsComponent,
    DataComponent,
    NavbarComponent,
    HttpComponent,
    TemplateFormsComponent,
    ReactiveFormsComponent,
    DynamicRowsComponent,
    SearchFilterComponent,
    CheckboxFilterComponent,
    DynamicDropdownComponent,
    SearchPipeComponent,
    FilterSearchPipe,
    DynamicDropdownTwoComponent,
    ReactiveFormBuilderComponent,
    CheckboxFilterTwoComponent,
    DynamicRowsTwoComponent,
    DynamicRowsThreeComponent,
    ReactiveFormsNgclassComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    Ng2SearchPipeModule,
    NgxPaginationModule,
    Ng2OrderModule,
    MatTableModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
