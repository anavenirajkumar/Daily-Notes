export interface IEmployee{
    sno : string,
    name : string,
    age : number,
    location : string,
    designation : string
}