export interface IUser{
     username: string,
     email :string,
     date : string,
     password: string,
     mobile : string ,
     address : string,
     address2 : string,
     course : string,
     gender : string,
     isTCAccepted : string

}