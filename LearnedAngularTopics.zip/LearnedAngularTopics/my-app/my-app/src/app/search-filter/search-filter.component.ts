import { Component, OnInit } from '@angular/core';
import { IContactService } from '../services/icontact.service';
import { IContact } from '../model/IContact';
@Component({
  selector: 'app-search-filter',
  templateUrl: './search-filter.component.html',
  styleUrls: ['./search-filter.component.css']
})
export class SearchFilterComponent implements OnInit {

  public contacts:IContact[]=[];

  public searchFilter:string = ''; // Search Filter
   
  p:number = 1;  ///Pagination
  constructor(private contactService : IContactService) { }

  ngOnInit(): void {
    this.contactService.getAllContacts().subscribe((data)=>{
      this.contacts = data;
    })
  }

  public Search(){ // Search Filter
    if(this.searchFilter != ""){
      this.contacts = this.contacts.filter(res =>{
        console.log(this.searchFilter)
        return res.name.first.toLocaleLowerCase().match(this.searchFilter.toLocaleLowerCase());
      });
    } else if(this.searchFilter == ""){
      this.ngOnInit(); 
    }
  }

  key = 'first';  // Sort
  reverse : boolean = false;
  public sort(key:any){
      this.key = key;
      this.reverse = !this.reverse;
  }

}
