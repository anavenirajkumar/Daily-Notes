import { Component, OnInit, Output,EventEmitter } from '@angular/core';
import { IContactService } from '../../services/icontact.service';
import { IContact } from '../..//model/IContact';
@Component({
  selector: 'app-contact-list',
  templateUrl: './contact-list.component.html',
  styleUrls: ['./contact-list.component.css']
})
export class ContactListComponent implements OnInit {

  
  public contacts:IContact[]=[] //
  public errorMessage:string = '';// for ErrorMessage

  @Output() sendContact = new EventEmitter() /// Send Data to Parent

  constructor(private contactService:IContactService) { }

  ngOnInit(): void {
      this.contactService.getAllContacts().subscribe((data)=>{
        this.contacts = data;
      }, (error)=>{
        this.errorMessage = error;
      });
  }

  /// Send Data to Parent Each Row Click
  public selectContact(contact:IContact){
    this.sendContact.emit(contact)
  }

}
