import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../model/IEmployee';
import { FormGroup,FormControl,Validators } from '@angular/forms';
@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {

  public exform : any;

  public courses: string[] = ['html', 'css', 'javascript', 'bootstrap', 'angular','.Net'];

  constructor() { }

  ngOnInit() {
     this.exform = new FormGroup({
        name : new FormControl('',Validators.required),
        email : new FormControl('', [Validators.required,Validators.email]),
        address : new FormControl('', Validators.required),
        course : new FormControl('', Validators.required)
     })
  }

  public employees:IEmployee[] = [
    {
      sno : '00AA10',
      name : 'Rajkumar',
      age : 23,
      designation : 'Junior Software',
      location : 'Hyderabad'
    },
    {
      sno : '00AA11',
      name : 'John',
      age : 45,
      designation : 'Project Manager',
      location : 'Hyderabad'
    },
    {
      sno : '00AA12',
      name : 'Mahesh',
      age : 35,
      designation : 'Tech Lead',
      location : 'Bangalore'
    },
    {
      sno : '00AA13',
      name : 'Wilson',
      age : 55,
      designation : 'Director',
      location : 'Bangalore'
    }
  ]

  public submitForm(){
    console.log(this.exform.value);
    this.exform.reset();
  }


}
