import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CostomContactsComponent } from './costom-contacts.component';

describe('CostomContactsComponent', () => {
  let component: CostomContactsComponent;
  let fixture: ComponentFixture<CostomContactsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CostomContactsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CostomContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
