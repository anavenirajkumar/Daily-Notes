import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-costom-contacts',
  templateUrl: './costom-contacts.component.html',
  styleUrls: ['./costom-contacts.component.css']
})
export class CostomContactsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
