import { AbstractControl, ValidatorFn } from "@angular/forms";

export function nameValidator(forbiddenName:RegExp, name: string):ValidatorFn{
    debugger;
    let abcd = name;
    console.log(abcd);
    return (control : AbstractControl):{[name : string] : any} | null => {
        const forbidden  =  name.match(control.value);
        return forbidden ? {'forbiddenName' : {value : control.value}} : null;  // "admin" name not givin form
    }
}