// import { AbstractControl } from "@angular/forms";
// export function PasswordValidator(control:AbstractControl):{[key :string]:boolean} | null {
//     const password = control.get('password');
//     const conformpassword = control.get('conformpassword');

//     if(password?.pristine || conformpassword?.pristine){
//         return null
//     }

//     return password && conformpassword && password.value != conformpassword.value ?
//     {'misMatch' : true} | null; 
    
// }