import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicRowsThreeComponent } from './dynamic-rows-three.component';

describe('DynamicRowsThreeComponent', () => {
  let component: DynamicRowsThreeComponent;
  let fixture: ComponentFixture<DynamicRowsThreeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicRowsThreeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicRowsThreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
