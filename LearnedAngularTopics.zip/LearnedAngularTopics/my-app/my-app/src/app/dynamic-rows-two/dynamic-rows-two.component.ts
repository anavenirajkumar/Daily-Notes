import { Component, OnInit } from '@angular/core';
import { FormGroup,Validators,FormControl, FormBuilder,FormArray } from '@angular/forms';
@Component({
  selector: 'app-dynamic-rows-two',
  templateUrl: './dynamic-rows-two.component.html',
  styleUrls: ['./dynamic-rows-two.component.css']
})
export class DynamicRowsTwoComponent implements OnInit {

  form : FormGroup | any;

  constructor(private formBuilder : FormBuilder) { }

  ngOnInit(): void {
    this.form = this.formBuilder.group({
       
       items : this.formBuilder.array([
         this.formBuilder.group({
           //itemId : [],
           name : ['',Validators.required],
           email : ['',Validators.required],
           mobile : ['',Validators.required],
           add : ['Add',]
         })
       ])

    })
  }

  public submitForm(){
     if(this.form.valid)
      console.log(this.form.value);
      
  }

  get items(){
     return this.form.get('items') as FormArray;
  }
  public addRow(e:any){
    console.log(e)
     const itemsLength = this.items.length;
    if(e === 0){
      const newItems = this.formBuilder.group({
        name : ['', Validators.required],
        email : ['',Validators.required],
        mobile : ['',Validators.required],
        add : ['Remove',Validators.required]
      });
      this.items.push(newItems);
    }
    else{
      this.removeRow(e);
    }
  }

  public removeRow(id:any){
    this.items.removeAt(id);
 }

}
