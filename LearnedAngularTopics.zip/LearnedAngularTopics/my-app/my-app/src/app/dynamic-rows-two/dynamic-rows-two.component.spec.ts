import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicRowsTwoComponent } from './dynamic-rows-two.component';

describe('DynamicRowsTwoComponent', () => {
  let component: DynamicRowsTwoComponent;
  let fixture: ComponentFixture<DynamicRowsTwoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DynamicRowsTwoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicRowsTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
