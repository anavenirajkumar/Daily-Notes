﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace DapperEcommerceAPI.Models
{
    public class CategoryRepository : ICategory
    {
        private IDbConnection db;

        public CategoryRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }
        public Category AddCategory(Category category)
        {
            var sql = "INSERT INTO Categories(CategoryName) Values (@CategoryName);" +
                      "SELECT CAST(SCOPE_IDENTITY() AS int);";
            var id = db.Query<int>(sql, category).Single();
            category.CategoryId = id;
            return category;
       
         }

        public List<Category> GetAllCategories()
        {
            var sql = "SELECT * FROM Categories";
            return db.Query<Category>(sql).ToList();
        }

        public Category GetById(int id)
        {
            var sql = "SELECT * FROM Categories WHERE CategoryId = @CategoryId";
            return db.Query<Category>(sql, new { @CategoryId = id }).Single();
      
        }

        public Category UpdateCategory(Category category)
        {
            var sql = "UPDATE Categories SET CategoryName = @CategoryName WHERE CategoryId = @CategoryId";
            db.Execute(sql, category);
            return category;
        }

        public int DeleteCategory(int id)
        {
            var sql = "DELETE FROM Categories WHERE CategoryId = @Id";
            db.Execute(sql, new { id });
            return id;
        }
    }
}
