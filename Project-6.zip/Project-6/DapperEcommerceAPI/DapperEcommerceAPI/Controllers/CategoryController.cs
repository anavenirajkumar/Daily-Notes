﻿
using DapperEcommerceAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperEcommerceAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategory _compRepo;
        public CategoryController(ICategory compRepo)
        {
            _compRepo = compRepo;
        }

        // Get All Categories
        [HttpGet]
        [Route("GetAllCategories")]
        public List<Category> GetAll()
        {
            return _compRepo.GetAllCategories();
        }

        // Create Category
        [HttpPost]
        [Route("CreateCategory")]
        public Category Create([Bind("CategoryId,CategoryName")] Category category) // ModelState is valid
        {
            if (ModelState.IsValid)
            {
                _compRepo.AddCategory(category);
                return category;
            }
            return category;
        }


        // GET ID By Category
        [HttpGet("GetById/{id}")]
        public Category GetById(int? id)
        {
            if (id == null)
            {
                return null;
            }
            var category = _compRepo.GetById(id.GetValueOrDefault());
            if (category == null)
            {
                return null;
            }
            return category;
        }

        // Update Employee
        [HttpPut("editCategory")]
        public Category Edit([Bind("CategoryId,CategoryName")] Category category)
        {
            if (ModelState.IsValid)
            {
                _compRepo.UpdateCategory(category);
                return category;
            }
            return category;
        }

        // Delete By Id
        [HttpDelete("{id}")]
        public int Delete(int? id)
        {
            if (id == null)
            {
                return 0;
            }

            _compRepo.DeleteCategory(id.GetValueOrDefault());
            return 1;
        }
    }
}
