﻿/*namespace DapperCRUDWebApi2.Models
{
    public class SubCategory
    {
    }
}*/