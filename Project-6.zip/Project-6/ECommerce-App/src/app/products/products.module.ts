import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductsRoutingModule } from './products-routing.module';
import { ProductsComponent } from './products.component';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CategoriesComponent } from './inline-edit/categories/categories.component';
import { ProductListComponent } from './inline-edit/product-list/product-list.component';
import { ParamMapCategoriesComponent } from './paramMap-edit/param-map-categories/param-map-categories.component';
import { GetCIdComponent } from './paramMap-edit/param-map-categories/get-c-id/get-c-id.component';
import { ParamMapProductsComponent } from './paramMap-edit/param-map-products/param-map-products.component';
import { GetPIdComponent } from './paramMap-edit/param-map-products/get-p-id/get-p-id.component';
import { CategoriesPopupComponent } from './popup-edit/categories-popup/categories-popup.component';
import { ProductsPopupComponent } from './popup-edit/products-popup/products-popup.component';
import { ProductsPopupFormbuilderComponent } from './popup-edit/products-popup-formbuilder/products-popup-formbuilder.component';

@NgModule({
  declarations: [
    ProductsComponent,
    CategoriesComponent,
    ProductListComponent,
    ParamMapCategoriesComponent,
    GetCIdComponent,
    ParamMapProductsComponent,
    GetPIdComponent,
    CategoriesPopupComponent,
    ProductsPopupComponent,
    ProductsPopupFormbuilderComponent,
  ],
  imports: [
    CommonModule,
    ProductsRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class ProductsModule { }
