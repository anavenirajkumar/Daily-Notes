import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ICategory } from '../../models/ICategory';
import { IProduct } from '../../models/IProduct';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-products-popup-formbuilder',
  templateUrl: './products-popup-formbuilder.component.html',
  styleUrls: ['./products-popup-formbuilder.component.css']
})
export class ProductsPopupFormbuilderComponent implements OnInit {

  public products:IProduct[] = [];
  public categories:ICategory[] = [];
  public productform : FormGroup | any;
  public product:IProduct = {
    productId : 0,
    productName : '',
    productImage : '',
    productPrice : 0,
    productDescription : '',
    categoryId : 0,
    category : {
         categoryId : 0,
         categoryName: ''
    }
  }
  public title:any;
  public showAddProduct:boolean = false;
  public showUpdateProduct:boolean = false;
  public showItem:boolean = false;
  public selectCategory:any;
  
  constructor(private formBuilder : FormBuilder,
              private productService:ProductService) { }

  ngOnInit(): void {
    this.getAllProductsCategories();
    this.getCategories();
     ////////////////////// Form Builder //////////////////////
     this.productform = this.formBuilder.group({
      productName: ['',[Validators.required,Validators.minLength(5)]], // "admin" & "Rajkumar" & "password" not taking
      productImage : ['',[Validators.required]],
      productPrice :  ['',[Validators.required,Validators.minLength(3)]],
      productDescription:  ['',[Validators.required,Validators.minLength(5)]],
      productCategoryId: ['',[Validators.required,Validators.maxLength(3)]], // MaxLength is 3 Because "null" value Length is 4
     });
  }
  public getAllProductsCategories(){
    this.productService.getAllProductsWithCategories().subscribe((data)=>{
      this.products = data;
      console.log(this.products);
    })
  }
  public getCategories(){
    this.productService.getCategories().subscribe((data)=>{
      this.categories = data;
      console.log(this.categories);
    })
  }

  openPopup(){
    this.title = "Add Product";
    this.showItem = false;
    this.showAddProduct = true;
    this.showUpdateProduct = false;
    this.productform.reset();
    this.selectCategory = "--Select Category--";
    this.product.productId = 0; // when i edit popup storing productId so im removing empty
    this.product.productImage = "";
    this.getCategories();
  }

  createProduct(){
    this.productform.markAllAsTouched();
     console.log(this.productform);
     console.log(this.product);
     let categoryIdNumber : number = +this.productform.value.productCategoryId;
     this.product.categoryId = categoryIdNumber;
     console.log(this.product.categoryId);
    if(this.product.categoryId != 0 && this.product.productImage !== ""){
      // this.product.categoryId = this.productform.value.productCategoryId;
      this.product.productName = this.productform.value.productName;
      this.product.productImage = this.product.productImage;
      this.product.productDescription = this.productform.value.productDescription;
      this.product.productPrice = this.productform.value.productPrice;      
      console.log(this.product);      
      this.productService.addProduct(this.product).subscribe((data)=>{
        console.log(data);
        this.product.productId = 0;
        this.product.productName = "";
        this.product.productImage = "";
        this.product.productDescription = "";
        this.product.productPrice = 0;
        this.product.categoryId = 0;
        this.product.category.categoryId = 0;
        this.product.category.categoryName = "";
        this.getAllProductsCategories();
        this.productform.reset();
        let ref = document.getElementById('cancel');
        ref?.click();
      })
    }
  }

  editProduct(product:any){
    // debugger;
    console.log(product);
    this.showItem = true;
     this.title = "Edit Product";
     this.showAddProduct = false;
     this.showUpdateProduct = true;
     this.product.productId = product.productId;
     this.productform.controls['productName'].setValue(product.productName);
      this.productform.controls['productImage'].setValue(product.productImage);
      this.product.productImage = product.productImage; // showing for UI image
      this.productform.controls['productPrice'].setValue(product.productPrice);
      this.productform.controls['productCategoryId'].setValue(product.categoryId);
      this.productform.controls['productDescription'].setValue(product.productDescription);
      this.product.category.categoryId = this.product.categoryId;
      console.log(this.productform);
      
      //this.Product.category.categoryName = Product.category.categoryName;
  }

  updateProduct(){
    this.productform.markAllAsTouched();
    let categoryIdNumber : number = +this.productform.value.productCategoryId;
    this.product.categoryId = categoryIdNumber;
    if(this.product.categoryId != 0 ){
        this.product.productId = this.product.productId;
        this.product.categoryId = this.productform.value.productCategoryId;
        this.product.productName = this.productform.value.productName;
        this.product.productImage =  this.productform.value.productImage;
        this.product.productDescription = this.productform.value.productDescription;
        this.product.productPrice = this.productform.value.productPrice;
        this.product.category.categoryId = this.product.categoryId;
        //this.product.category.categoryName = this.product.category.categoryName;

        //console.log(this.product);
        //console.log( this.product.productImage);
        this.productService.updateProduct(this.product).subscribe((data) => {
          console.log(data);
          this.product.productId = 0;
          this.product.productName = "";
          this.product.productImage = "";
          this.product.productDescription = "";
          this.product.productPrice = 0;
          this.product.categoryId = 0;
          this.product.category.categoryId = 0;
          this.product.category.categoryName = "";
          // this.productform.value.productImage = "";
          this.getAllProductsCategories();
          let ref = document.getElementById('cancel');
          ref?.click();
          this.productform.reset();
        })
    }
}
deleteProduct(product:any){
   this.productService.deleteProduct(product.productId).subscribe((data)=> {
     console.log(data);
     this.getAllProductsCategories();
   })
}

public updateProductImage(event:any){
  if (event.target.files && event.target.files.length) {
    const [file] = event.target.files;
    let reader = new FileReader();
    reader.readAsDataURL(file);
    //this.imageFileName = file;
    reader.addEventListener('load', () => {
      if(reader.result){
        this.product = {
          ...this.product,
          productImage : String(reader.result)
        };
      }
      this.productform.value.productImage = this.product.productImage;
      console.log(this.product);
      //reader.result ? this.selectedProduct.image = String(reader.result) : '';
    });
  }
}

}
