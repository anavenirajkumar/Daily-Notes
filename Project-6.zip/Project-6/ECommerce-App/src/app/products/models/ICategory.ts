export class ICategory{
    categoryId: number = 0;
    categoryName : string = '';
}