import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParamMapProductsComponent } from './param-map-products.component';

describe('ParamMapProductsComponent', () => {
  let component: ParamMapProductsComponent;
  let fixture: ComponentFixture<ParamMapProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParamMapProductsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParamMapProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
