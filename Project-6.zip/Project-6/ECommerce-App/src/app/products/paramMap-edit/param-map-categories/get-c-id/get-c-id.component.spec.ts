import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetCIdComponent } from './get-c-id.component';

describe('GetCIdComponent', () => {
  let component: GetCIdComponent;
  let fixture: ComponentFixture<GetCIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetCIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetCIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
