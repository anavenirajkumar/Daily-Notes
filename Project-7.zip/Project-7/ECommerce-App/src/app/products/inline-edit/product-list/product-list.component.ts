import { Component, OnInit } from '@angular/core';
import { ICategory } from '../../models/ICategory';
import { IProduct } from '../../models/IProduct';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  public products:IProduct[] = [];

  public product:IProduct = {
    productId :  0,
    productName : '',
    productImage : '',
    productPrice : 0,
    productDescription :  '',
    categoryId : 0,
    category : {
         categoryId : 0,
         categoryName : ''
    }
  }

  public categories:ICategory[] = [];
  public productIndex:any;

  public imageFileName:any;

  constructor(private productService:ProductService) { }

  ngOnInit() {
    this.getAllProductWithCategories();
    this.getAllCategories();

  }
  getAllProductWithCategories(){
    this.productService.getAllProductsWithCategories().subscribe((data)=> {
      this.products = data;
      console.log(this.products);
    })
  }

  getAllCategories(){
    this.productService.getCategories().subscribe((data)=> {
      this.categories = data;
      console.log(this.categories);
    })
  }

  addProduct(){
    //console.log(this.product);
    this.productIndex = null
    if(this.product.categoryId != 0 && this.product.productImage != ""){ // 0 != 0; 0 anedi 0 kakapothe lopaliki vellu -> i check category and after change to 'Select category' 
          //  console.log(this.product.categoryId); return;
          console.log(this.product);
          this.productService.addProduct(this.product).subscribe((data)=> {
            console.log(data);
                this.product.productName = '',
                this.product.productImage = '',
                this.product.productPrice = 0,
                this.product.productDescription = '',
                this.product.categoryId = 0;
                this.imageFileName = "";
            console.log(this.product);
            this.getAllProductWithCategories();
          })
    } 
  }

  editProduct(product:any){
    this.productIndex = product.productId;
    // console.log(product.productImage);
    this.product.productImage = product.productImage;
  }
  deleteProduct(product:any){
    this.productIndex = null
    this.productService.deleteProduct(product.productId).subscribe((data)=>{
      console.log(data);
      this.getAllProductWithCategories();
    })
  }
  updateProduct(product:any){
   if(product.productImage == ""){
      product.productImage = this.product.productImage
      //console.log(product.productImage);
   }
   
   // product.productImage = this.product.productImage
     //console.log(product.productImage);
     product.productImage = this.product.productImage;
      if(product.categoryId != 0){
        //console.log(product);
         if(product.productImage.length > 0){
          this.productService.updateProduct(product).subscribe((data)=> {
            console.log(data);
            //console.log(product.productImage);
            // console.log(this.product);
            this.product.productImage = "",
            this.imageFileName = "";
            this.getAllProductWithCategories();
            this.productIndex = null;
          })
         }
      } 
  }

  cancelProduct(){
    this.productIndex = null;
  }

 // selectProductImage
 public selectProductImage(event:any){
  if (event.target.files && event.target.files.length) {
    const [file] = event.target.files;
    let reader = new FileReader();
    reader.readAsDataURL(file);
    this.imageFileName = file;
    reader.addEventListener('load', () => {
      return reader.result ? this.product.productImage = String(reader.result) : '';
    });

  }
}


 // selectProductImage
 public updateProductImage(event:any){
  if (event.target.files && event.target.files.length) {
    const [file] = event.target.files;
    let reader = new FileReader();
    reader.readAsDataURL(file);
    //this.imageFileName = file;
    reader.addEventListener('load', () => {
      if(reader.result){
        this.product = {
          ...this.product,
          productImage : String(reader.result)
        };
      }
      console.log(this.product);
      //reader.result ? this.selectedProduct.image = String(reader.result) : '';
    });
  }
}

}
