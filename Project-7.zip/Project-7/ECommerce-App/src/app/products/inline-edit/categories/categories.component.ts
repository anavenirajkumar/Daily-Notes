import { Component, OnInit } from '@angular/core';
import { ICategory } from '../../models/ICategory';
import { ProductService } from '../../services/product.service';
@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  public categories:ICategory[] = [];
  public category:ICategory = {
    categoryId : 0,
    categoryName : ''
  }

  public categoryIndex:any;

  constructor(private cateService:ProductService) { }

  ngOnInit() {
    this.getCategories();
  }

  getCategories(){
    this.cateService.getCategories().subscribe((data)=> {
      this.categories = data;
      console.log(this.categories);
    })
  }

  addCategory(){
    if(this.category.categoryName !== ''){
        console.log(this.category);
        this.cateService.addCategory(this.category).subscribe((data) => {
          console.log(data);
          this.getCategories();
          this.category.categoryName = '';
        })
    }
  }

  editCategory(category:any){
     console.log(category);
     this.categoryIndex = category.categoryId;
  }

  deleteCategory(category:any){
    console.log(category);
     this.cateService.deleteCategory(category.categoryId).subscribe((data)=>{
       console.log(data);
       this.getCategories();
     })
  }

  updateCategory(category:any){
    console.log(category);
    this.cateService.updateCategory(category).subscribe((data) => {
      console.log(data);
      this.getCategories();
      this.categoryIndex = null;
    })
  }
  cancelCategory(){
    this.categoryIndex = null;
  }

}
