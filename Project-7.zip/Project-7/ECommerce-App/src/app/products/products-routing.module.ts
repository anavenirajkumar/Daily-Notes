import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ColumnEditComponent } from './column-edit/column-edit.component';
import { EditPageComponent } from './edit-page/edit-page.component';
import { CategoriesComponent } from './inline-edit/categories/categories.component';
import { ProductListComponent } from './inline-edit/product-list/product-list.component';
import { GetCIdComponent } from './paramMap-edit/param-map-categories/get-c-id/get-c-id.component';
import { ParamMapCategoriesComponent } from './paramMap-edit/param-map-categories/param-map-categories.component';
import { GetPIdComponent } from './paramMap-edit/param-map-products/get-p-id/get-p-id.component';
import { ParamMapProductsComponent } from './paramMap-edit/param-map-products/param-map-products.component';
import { CategoriesPopupComponent } from './popup-edit/categories-popup/categories-popup.component';
import { ProductsPopupFormbuilderComponent } from './popup-edit/products-popup-formbuilder/products-popup-formbuilder.component';
import { ProductsPopupComponent } from './popup-edit/products-popup/products-popup.component';
import { ProductsComponent } from './products.component';

const routes: Routes = [
  { path: '', component: ProductsComponent },
  { path : 'categories-inline', component : CategoriesComponent },
  { path : 'products-inline', component : ProductListComponent },
  { path : 'categories-paramMap', component : ParamMapCategoriesComponent },
  { path : 'categories-paramMap/:id', component : GetCIdComponent },
  { path : 'products-paramMap', component : ParamMapProductsComponent },
  { path : 'products-paramMap/:id', component : GetPIdComponent },
  { path : 'categories-popup', component : CategoriesPopupComponent },
  { path : 'products-popup', component : ProductsPopupComponent },
  { path : 'products-popup-formbuilder', component : ProductsPopupFormbuilderComponent },
  { path : 'column-edit', component : ColumnEditComponent },
  { path : 'editPage', component : EditPageComponent },
];
 
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsRoutingModule { }
