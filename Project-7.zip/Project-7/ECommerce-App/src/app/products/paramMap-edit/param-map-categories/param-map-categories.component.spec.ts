import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParamMapCategoriesComponent } from './param-map-categories.component';

describe('ParamMapCategoriesComponent', () => {
  let component: ParamMapCategoriesComponent;
  let fixture: ComponentFixture<ParamMapCategoriesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParamMapCategoriesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParamMapCategoriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
