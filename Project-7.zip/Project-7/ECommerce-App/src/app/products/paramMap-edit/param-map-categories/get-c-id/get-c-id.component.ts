import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ICategory } from 'src/app/products/models/ICategory';
import { ProductService } from 'src/app/products/services/product.service';

@Component({
  selector: 'app-get-c-id',
  templateUrl: './get-c-id.component.html',
  styleUrls: ['./get-c-id.component.css']
})
export class GetCIdComponent implements OnInit {

  public categoryId:any;
   public category:ICategory = {
      categoryId : 0,
      categoryName : ''
   }
   constructor(private snapshot:ActivatedRoute,
               private categoryService:ProductService,
               private router:Router) { }

  ngOnInit(){
      this.snapshot.paramMap.subscribe((id)=>{
        this.categoryId = id.get('id');
        console.log(this.categoryId);
      });
     this.categoryService.getCategory(this.categoryId).subscribe((data)=> {
       this.category = data;
       console.log(this.category);
     })
  }

  updateCategory(){
    //console.log(this.category);
    if(this.category.categoryId != 0 ){
       //console.log(this.category); return;
      this.categoryService.updateCategory(this.category).subscribe((data)=>{
        console.log(data);
        this.router.navigate(['/products/categories-paramMap']);
      })
    }
  }

}
