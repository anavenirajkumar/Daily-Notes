import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ICategory } from 'src/app/products/models/ICategory';
import { IProduct } from 'src/app/products/models/IProduct';
import { ProductService } from 'src/app/products/services/product.service';

@Component({
  selector: 'app-get-p-id',
  templateUrl: './get-p-id.component.html',
  styleUrls: ['./get-p-id.component.css']
})
export class GetPIdComponent implements OnInit {

  public productId:any;
  public product:IProduct = {
    productId : 0,
    productName : '',
    productImage : '',
    productPrice : 0,
    productDescription : '',
    categoryId : 0,
    category : {
         categoryId : 0,
         categoryName: ''
    }
  }
  public categories:ICategory[] = [];
  
  constructor(
    private snapshot:ActivatedRoute,
    private productService:ProductService,
    private router:Router) { }

  ngOnInit() {
    this.snapshot.paramMap.subscribe((id)=> {
      this.productId = id.get('id');
      console.log(this.productId);
    });
    this.productService.getProduct(this.productId).subscribe((data)=> {
      this.product = data;
      console.log(this.product);
    })
    this.productService.getCategories().subscribe((data)=> {
      this.categories = data;
      console.log(this.categories);
    })
  }
  
  updateProduct(){
      // console.log(this.product);
      if(this.product.categoryId != 0 && this.product.productName !='' && this.product.productImage != '' && this.product.productPrice != 0 && this.product.productDescription != ''){
        console.log(this.product);
        this.productService.updateProduct(this.product).subscribe((data)=>{
          console.log(data);
           this.router.navigate(['products/products-paramMap']);
        })
    }
  }

  public updateProductImage(event:any){
    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      let reader = new FileReader();
      reader.readAsDataURL(file);
      //this.imageFileName = file;
      reader.addEventListener('load', () => {
        if(reader.result){
          this.product = {
            ...this.product,
            productImage : String(reader.result)
          };
        }
        console.log(this.product);
        //reader.result ? this.selectedProduct.image = String(reader.result) : '';
      });
    }
  }
}
