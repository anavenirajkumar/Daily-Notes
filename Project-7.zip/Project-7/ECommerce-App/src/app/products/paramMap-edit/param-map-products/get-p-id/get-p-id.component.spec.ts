import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetPIdComponent } from './get-p-id.component';

describe('GetPIdComponent', () => {
  let component: GetPIdComponent;
  let fixture: ComponentFixture<GetPIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetPIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetPIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
