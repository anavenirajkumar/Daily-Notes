import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ICategory } from '../models/ICategory';
import { IProduct } from '../models/IProduct';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  readonly ApiUrl = 'http://localhost:21575/api'
  constructor(private httpClient:HttpClient) { }

  addCategory(category:ICategory):Observable<ICategory>{
     return this.httpClient.post<ICategory>(this.ApiUrl + '/Category/CreateCategory', category);
  }

  getCategories():Observable<ICategory[]>{
    return this.httpClient.get<ICategory[]>(this.ApiUrl + '/Category/GetAllCategories')
  }

  updateCategory( category:ICategory):Observable<ICategory>{
     return this.httpClient.put<ICategory>(this.ApiUrl + '/Category/editCategory', category)
  }

  getCategory(categoryId:any):Observable<ICategory>{ // Get Category by ParamMap
    return this.httpClient.get<ICategory>(this.ApiUrl + '/Category/GetById/'+ categoryId);
  }

  deleteCategory(categoryId:ICategory):Observable<ICategory>{
    return this.httpClient.delete<ICategory>(this.ApiUrl + '/Category/' + categoryId);
  }

  getAllCategoriesWithProducts():Observable<any[]>{ // GET All Categories With Products
    return this.httpClient.get<any[]>(this.ApiUrl + '/Products/GetAllCategoriesWithProducts');
  }


  /////////////////// Products Api's //////////////////////////
 getProducts():Observable<IProduct[]>{ // GET Only Products
   return this.httpClient.get<IProduct[]>(this.ApiUrl + '/Product/getAllProducts');
 }

 getAllProductsWithCategories():Observable<IProduct[]>{  // GET All Products With Categories
  return this.httpClient.get<IProduct[]>(this.ApiUrl + '/Product/GetAllProductsWithCategories');
}

 addProduct(product:IProduct):Observable<IProduct>{
   return this.httpClient.post<IProduct>(this.ApiUrl + '/Product/CreateProduct', product);
 }

 getProduct(getId:any):Observable<IProduct>{
   return this.httpClient.get<IProduct>(this.ApiUrl + '/Product/GetByProductId/' + getId)
 }

 deleteProduct(id:any):Observable<any>{
    return this.httpClient.delete<any>(this.ApiUrl + '/Product/product/' + id);
 }

 updateProduct(product:IProduct):Observable<IProduct>{
   return this.httpClient.put<IProduct>(this.ApiUrl + '/Product/editProduct/', product)
 }
 
}
