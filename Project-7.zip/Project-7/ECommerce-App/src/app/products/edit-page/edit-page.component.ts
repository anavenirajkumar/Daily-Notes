import { Component, OnInit } from '@angular/core';
import { ICategory } from '../models/ICategory';
import { IProduct } from '../models/IProduct';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-edit-page',
  templateUrl: './edit-page.component.html',
  styleUrls: ['./edit-page.component.css']
})
export class EditPageComponent implements OnInit {

  public products:IProduct[] = [];
  public product:IProduct = {
    productId : 0,
    productName : '',
    productImage : '',
    productPrice : 0,
    productDescription : '',
    categoryId : 0,
    category : {
         categoryId : 0,
         categoryName: ''
    }
  }
  public categories:ICategory[] = [];
  public imageFileName:any;
  public showImage:boolean = false;
  constructor(private productService:ProductService) { }

  ngOnInit() {
    this.getAllProductsCategories();
    this.getCategories();
  }
  getAllProductsCategories(){
    this.productService.getAllProductsWithCategories().subscribe((data)=>{
      this.products = data;
      console.log(this.products);
    })
  }
  getCategories(){
    this.productService.getCategories().subscribe((data)=> {
      this.categories = data;
      console.log(this.categories);
    })
  }
  addProduct(){
    if(this.product.categoryId != 0 && this.product.productName !='' && this.product.productImage !='' && this.product.productPrice != 0 && this.product.productDescription !=''){
       console.log(this.product);
       this.productService.addProduct(this.product).subscribe((data)=>{
         console.log(data);
         this.product.productName = '',
         this.product.productImage = '',
         this.product.productPrice = 0,
         this.product.productDescription = '',
         this.product.categoryId = 0
         this.getAllProductsCategories();
       })
    }
  }
  deleteProduct(productId:any){
     this.productService.deleteProduct(productId).subscribe((data)=> {
        console.log(data);
        this.getAllProductsCategories();
     })
  }

  public selectProductImage(event:any){
    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      let reader = new FileReader();
      reader.readAsDataURL(file);
      this.imageFileName = file;
      reader.addEventListener('load', () => {
        return reader.result ? this.product.productImage = String(reader.result) : '';
      });
  
    }
  }

  public editProduct(product:any){
    this.showImage = true;
     this.product.productId = product.productId;
     this.product.productName = product.productName;
     this.product.productPrice = product.productPrice;
     this.product.productDescription = product.productDescription;
     this.product.categoryId = product.categoryId;
     this.product.productImage = product.productImage;
  }

 public cancel(){
  this.showImage = false;
  this.product.productId = 0;
  this.product.productName = '';
  this.product.productImage = '';
  this.product.productPrice = 0;
  this.product.categoryId = 0;
  this.product.productDescription = '';
 }

 updateProduct(){
  if(this.product.categoryId != 0 && this.product.productName !='' && this.product.productImage != '' && this.product.productPrice != 0 && this.product.productDescription != ''){
    console.log(this.product);
    this.productService.updateProduct(this.product).subscribe((data)=>{
      console.log(data);
      window.location.reload();
    })
}
}

}
