import { ICategory } from "./ICategory";

export class IProduct {
    productId :number = 0;
    productName :  string = '';
    productImage : string = '';
    productPrice : number = 0;
    productDescription : string = '';
    categoryId : number = 0;
    category:ICategory = {
         categoryId : 0,
         categoryName: ''
    }
}
