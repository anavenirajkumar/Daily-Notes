import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsPopupFormbuilderComponent } from './products-popup-formbuilder.component';

describe('ProductsPopupFormbuilderComponent', () => {
  let component: ProductsPopupFormbuilderComponent;
  let fixture: ComponentFixture<ProductsPopupFormbuilderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductsPopupFormbuilderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsPopupFormbuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
