import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ICategory } from '../../models/ICategory';
import { ProductService } from '../../services/product.service';

@Component({
  selector: 'app-categories-popup',
  templateUrl: './categories-popup.component.html',
  styleUrls: ['./categories-popup.component.css']
})
export class CategoriesPopupComponent implements OnInit {

  public categories:ICategory[] = [];
  public categoryform : any;
  public title:any;

  public category:ICategory = {
    categoryId : 0,
    categoryName : ''
  }
  public showAddCategory:boolean = false;
  public showUpdateCategory:boolean = false;

  constructor(private categoryService:ProductService) { }

  ngOnInit(){
     this.getCategories();
     this.categoryform  = new FormGroup({
         categoryName :  new FormControl('',[Validators.required])
     })
  }
  getCategories(){
    this.categoryService.getCategories().subscribe((data)=>{
      this.categories = data;
      console.log(this.categories);
    })
  }
  openPopup(){
          this.title = 'Add Category';
          this.categoryform.reset();
          this.showAddCategory = true;
          this.showUpdateCategory = false;
          //this.category.categoryId = this.category.categoryId;
  }

  createCategory(){
    this.categoryform.markAllAsTouched();
    console.log(this.categoryform.valid);
    if(this.categoryform.valid){
    this.showAddCategory = true;
      this.category.categoryId = this.category.categoryId;
      this.category.categoryName = this.categoryform.value.categoryName;
      console.log(this.category);
      console.log(this.categoryform.valid);
      
          this.categoryService.addCategory(this.category).subscribe((data) => {
            //alert('category Creation Sucessfully Submited');
            let ref = document.getElementById('cancel');
            ref?.click();
            this.categoryform.reset();
            this.getCategories();
        },err=>{
         alert('Something Went Wrong')
        });
      }
    }

  editCategory(category:any){
    //console.log(category);
    this.showUpdateCategory = true;
    this.showAddCategory = false;
    this.title = 'Edit Category';
    this.category.categoryId = category.categoryId;
    this.categoryform.controls['categoryName'].setValue(category.categoryName);
  }

  deleteCategory(category:any){
    console.log(category);
      this.categoryService.deleteCategory(category.categoryId).subscribe((data)=> {
        console.log(data);
        this.getCategories();
      })
  }

  updateCategory(){
    this.categoryform.markAllAsTouched();
    if(this.categoryform.valid){
      console.log(this.category);
        this.category.categoryId = this.category.categoryId;
        this.category.categoryName = this.categoryform.value.categoryName;
        this.categoryService.updateCategory(this.category).subscribe((data)=>{
        console.log(data);
        let ref = document.getElementById('cancel');
        ref?.click();
        this.categoryform.reset();
        this.getCategories();
     })
    }
  }

  public categoryName(){
   return this.categoryform.get('categoryName');
  }

}
