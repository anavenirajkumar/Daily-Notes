import { Component, OnInit } from '@angular/core';
import { ICategory } from '../models/ICategory';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-column-edit',
  templateUrl: './column-edit.component.html',
  styleUrls: ['./column-edit.component.css']
})
export class ColumnEditComponent implements OnInit {

  public categories:ICategory[] = [];
  public category:ICategory = {
    categoryId : 0,
    categoryName : ''
 }
  constructor(private categoryService:ProductService) { }

  ngOnInit() {
    this.getCategories();
  }

  getCategories(){
    this.categoryService.getCategories().subscribe((data)=>{
      this.categories = data;
      console.log(this.categories);
    })
  }
  addCategory(){
     if(this.category.categoryName !==''){
      this.categoryService.addCategory(this.category).subscribe((data)=>{
        console.log(data);
        this.getCategories();
        this.category.categoryName ='';
      })
     }
  }
  deleteCategory(categoryId:any){
     this.categoryService.deleteCategory(categoryId).subscribe((data)=>{
       console.log(data);
       this.getCategories();
     })
  }

  editCategory(category:any){
      this.category.categoryName = category.categoryName;
  }


}
