﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace DapperEcommerceAPI.Models
{
    public class ProductRepository : IProduct
    {
        private IDbConnection db;

        public ProductRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }
        public Product AddProduct(Product product)
        {
            var sql = "INSERT INTO Products (ProductName, ProductPrice, ProductImage,ProductDescription, CategoryId) VALUES(@ProductName, @ProductPrice, @ProductImage, @ProductDescription, @CategoryId);"
                        +"SELECT CAST(SCOPE_IDENTITY() as int); "; // This line of code returns the last inserted identity ID of the table.
            var id = db.Query<int>(sql, product).Single();
            product.ProductId = id;
            return product;
        }

        public int DeleteProduct(int id)
        {
            var sql = "DELETE FROM Products WHERE ProductId = @Id";
            db.Execute(sql, new { id });
            return id;
        }

        public List<Product> GetAllProducts()
        {
            var sql = "SELECT * FROM Products";
            return db.Query<Product>(sql).ToList();
        }

        public Product GetById(int id)
        {
            var sql = "SELECT * FROM Products WHERE ProductId = @ProductId";
            return db.Query<Product>(sql, new { @ProductId = id }).Single();
        }

        public Product UpdateProduct(Product product)
        {
            var sql = "UPDATE Products SET ProductName = @ProductName, ProductPrice = @ProductPrice, ProductImage = @ProductImage, ProductDescription = @ProductDescription, CategoryId = @CategoryId WHERE ProductId = @ProductId";
            db.Execute(sql, product);
            return product;
        }

        public List<Product> GetAllProductsWithCategories(int id)
        {
            var sql = "SELECT P.*,C.* FROM Products AS P INNER JOIN Categories AS C ON P.CategoryId = C.CategoryId";
            if (id != 0) // if CategoryId there Show CategoryId Based Products
            {
                sql += " WHERE P.CategoryId = @Id ";
            }

            var product = db.Query<Product, Category, Product>(sql, (p, c) =>
            {
                p.Category = c;
                //p.SubCategories = s;
                return p;
            }, new { id }, splitOn: "CategoryId");

            return product.ToList();
        }


        public List<Category> GetAllCategoriesWithProducts()
        {
            var sql = "SELECT C.*,P.* FROM Products AS P INNER JOIN Categories AS C ON P.CategoryId = C.CategoryId ";

            var categoryDic = new Dictionary<int, Category>();

            var category = db.Query<Category, Product, Category>(sql, (c, p) =>
            {
                if (!categoryDic.TryGetValue(c.CategoryId, out var currentCategory))
                {
                    currentCategory = c;
                    categoryDic.Add(currentCategory.CategoryId, currentCategory);
                }
                currentCategory.Products.Add(p);
                return currentCategory;
            }, splitOn: "ProductId");

            return category.Distinct().ToList();
        }
    }
}
