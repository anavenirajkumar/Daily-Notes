﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperEcommerceAPI.Models
{
    public interface IProduct
    {
        Product AddProduct(Product product);
        Product UpdateProduct(Product product);
        Product GetById(int id);
        int DeleteProduct(int id);
        List<Product> GetAllProducts();
        List<Product> GetAllProductsWithCategories(int id);
        List<Category> GetAllCategoriesWithProducts();
    }
}
