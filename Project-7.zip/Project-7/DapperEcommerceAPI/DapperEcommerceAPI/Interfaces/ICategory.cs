﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperEcommerceAPI.Models
{
    public interface ICategory
    {
        Category AddCategory(Category category);
        Category UpdateCategory(Category category);
        Category GetById(int id);
        int DeleteCategory(int id);
        List<Category> GetAllCategories();

    }
}
