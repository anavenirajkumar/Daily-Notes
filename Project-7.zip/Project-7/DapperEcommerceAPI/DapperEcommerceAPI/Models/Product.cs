﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperEcommerceAPI.Models
{
    public class Product
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductPrice { get; set; }
        public string ProductImage { get; set; }
        public string ProductDescription { get; set; }
        public int CategoryId { get; set; } // Foreign Key
        public virtual Category Category { get; set; }

        //public int SubCategoryId { get; set; } // Foreign Key
        //public virtual  SubCategory SubCategories { get; set; }
    }
}
