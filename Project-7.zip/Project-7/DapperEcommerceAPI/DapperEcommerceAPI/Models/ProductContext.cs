﻿using DapperEcommerceAPI.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Models
{
    public class ProductContext : DbContext
    {
        public ProductContext(DbContextOptions<ProductContext> options) : base(options) { }
        public DbSet<Category> Categories { get; set; }
        //public DbSet<SubCategory> SubCategories { get; set; }
        public DbSet<Product> Products { get; set; }

    }
}
