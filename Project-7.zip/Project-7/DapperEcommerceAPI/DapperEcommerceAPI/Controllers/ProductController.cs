﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using DapperEcommerceAPI.Models;

namespace DapperEcommerceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProduct _compRepo;
        private readonly ICategory _categoryRepo;
        //private readonly ISubCategory _subRepo;

        public ProductController(IProduct compRepo, ICategory category)
        {
            _compRepo = compRepo;
            _categoryRepo = category;
            //_subRepo = subCategory;
        }

        // Get All Products Only
        [HttpGet("getAllProducts")]
        public List<Product> GetAll()
        {
            return _compRepo.GetAllProducts();
        }

        // Get All Products with Categories
        [HttpGet]
        [Route("GetAllProductsWithCategories")]
        public List<Product> GetAllProductsCategories(int id)
        {
            return _compRepo.GetAllProductsWithCategories(id);
        }

        // Get All Categories with Products
        [HttpGet]
        [Route("GetAllCategoriesWithProducts")]
        public List<Category> GetAllCategoriesProducts()
        {
            return _compRepo.GetAllCategoriesWithProducts();
        }

        // Create Product
        [HttpPost]
        [Route("CreateProduct")]
        public Product Create([Bind("ProductId,ProductName, ProductPrice, ProductImage, ProductDescription")] Product product) // ModelState is valid
        {
            if (ModelState.IsValid)
            {
                _compRepo.AddProduct(product);
                return product;
            }
            return product;
        }


        // GET ID By Product
        [HttpGet("GetByProductId/{id}")]
        public Product GetById(int? id)
        {
            if (id == null)
            {
                return null;
            }
            Product product = _compRepo.GetById(id.GetValueOrDefault());
            if (product == null)
            {
                return null;
            }
            Category category = _categoryRepo.GetById((int)product.CategoryId);
            var categoryList = category;
            product.Category = categoryList;
            /*  SubCategory subcategory = _subRepo.GetById((int)product.SubCategoryId);
              var subcategoryList = subcategory;
              product.SubCategories = subcategoryList;*/
            return product;
        }

        // Update Product
        [HttpPut("editProduct")]
        public Product Edit([Bind("ProductId, ProductName, ProductPrice, ProductImage, ProductDescription")] Product product)
        {
            if (ModelState.IsValid)
            {
                _compRepo.UpdateProduct(product);
                return product;
            }
            return product;
        }

        // Delete By ProductId
        [HttpDelete("product/{id}")]
        public int Delete(int? id)
        {
            if (id == null)
            {
                return 0;
            }

            _compRepo.DeleteProduct(id.GetValueOrDefault());
            return 1;
        }
    }
}
