﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using OfficeOpenXml;
using OfficeOpenXml.Core.ExcelPackage;

namespace WebAPI.Interfaces
{
    public interface IUser
    {
         Task<RegisterUserResponse> RegisterUser(RegisterUser request);
         Task<UserLoginResponse> UserLogin(UserLoginRequest request);
        Task<UserLoginResponse> GetRefreshUser(string email, string userId);
         Task<GetInfoByEmail> GetLoggedUser(int userId);
         Task<bool> UserDetails(UserLoginResponse user);
         Task<AddInformationResponse> AddInformation(AddInformationRequest request);
         Task<GetInformationResponse> GetInformation();
         Task<GetInformation> GetUserInfo(int id);
         Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation updateUser);

        // for User Multiple Images Upload
         Task<AddUser> AddUser(AddUser request);
         Task<GetUsers> GetUsers();
         Task<GetUser> GetUserById(int id);
         Task<AddUser> UpdateUser(AddUser request);
         Task<UserAddressResponce> DeleteUserById(int id);

         Task<bool> DeleteSpecificImage(int id);

        // for only upload multiple images
         Task<ImageUser> UploadImages(ImageUser request);


        // 
         Task<AddNewUserRequest> AddNewUserRequest(AddNewUserRequest request);
        Task<IEnumerable<GetNewUsers>> GetNewUsers();
        Task<GetNewUsers> GetNewUserById(int UserId);
         Task<AddNewUserRequest> UpdateNewUserRequest(AddNewUserRequest request);
         Task<bool> DeleteNewUserById(int id);
         Task<bool> DeleteUserImage(int id);
         Task<UpdateUserImages> UpdateImages(UpdateUserImages request);

        // Logout User && LastLagin
         Task<string> LogoutUser(UserLoginResponse user, string token);

        // Xml Download
         Task<OfficeOpenXml.ExcelPackage> GetUsersXMLFile();

        // Place Order
         Task<int> PlaceUserOrder(UserLoginResponse user);

        // Get User Orders
         Task<List<Order>> GetUserOrders(UserLoginResponse user);

         Task<List<Order>> GetAllOrders(UserLoginResponse user);

    }
}
