﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.DTOS;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface ICategory
    {

        // CREATE Methods
         Task<CategoryResponce> Category(Category category);
         Task<SubCategoryResponce> SubCategory(SubCategory subcategory);
         Task<CategoryProductResponce> Product(CategoryProduct product);

        // GET Methods
         Task<CategoryResponce> GetCategories();
         Task<SubCategoryResponce> GetSubCategories();

         Task<CategoryProductResponce> GetProducts();

        /* Task<SubCategoryResponce> GetSubCategoriesById(int categoryId);*/


        // GET By ID Methods
         Task<CategoryResponce> GetCategory(int categoryId);
         Task<SubCategoryResponce> GetSubCategory(int subcategoryId);
         Task<CategoryProductResponce> GetProduct(int productId);

        // Update Methods
         Task<CategoryResponce> UpdateCategory(Category category);
         Task<SubCategoryResponce> UpdateSubCategory(SubCategory subcategory);
         Task<CategoryProductResponce> UpdateProduct(CategoryProduct product);

        // Delete By ID Methods
         Task<CategoryResponce> DeleteCategory(int categoryId);
         Task<SubCategoryResponce> DeleteSubCategory(int subcategoryId);
         Task<CategoryProductResponce> DeleteProduct(int productId);


    }
}
