﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface IUploadFile
    {
         Task<UploadXMLFileResponse> UploadXMLFile(UploadXMLFile request, string Path);

         Task<UploadCSVFileResponse> UploadCSVFile(UploadCSVFileRequest request, string Path);

         Task<ReadRecordResponse> ReadRecord(ReadRecordRequest request);

         Task<ReadRecordResponse> ReadRecords();

         Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request);

         Task<DeleteRecordResponse> DeleteAllRecords();

         Task<DeleteRecordResponse> DeletebyId(int recordId);

         Task<ReadRecord> GetIdByRecord(int id);

         Task<ReadRecord> UpdateRecord(ReadRecord record);



    }
}
