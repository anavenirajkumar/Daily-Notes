﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class UploadXMLFile
    {
        public IFormFile File { get; set; }
    }

    public class UploadCSVFileRequest
    {
        public IFormFile File { get; set; }
    }

    public class ReadRecordRequest
    {
        public int RecordPerPage { get; set; }
        public int PageNumber { get; set; }
    }

    public class DeleteRecordRequest
    {
        public int UserID { get; set; }
    }
}
