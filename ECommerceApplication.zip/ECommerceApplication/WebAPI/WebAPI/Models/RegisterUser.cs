﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class RegisterUser
    {
        //[Required(ErrorMessage = "UserName Is Mandetory")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password Is Mandetory")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password Is Mandetory")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Email Is Mandetory")]
        public string Email { get; set; }

        //[Required(ErrorMessage = "Role Is Mandetory")]
        public string Role { get; set; } // Default Role is "User"

    }


    public static class Global
    {
        public static List<RegisterUser> Users { get; set; } = new List<RegisterUser>();

    }


    public class UserLoginRequest
    {
        [Required(ErrorMessage = "Email Is Mandetory")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password Is Mandetory")]
        public string Password { get; set; }
        public DateTime? LastLogin { get; set; }

    }

    public class AddInformationRequest
    {
        //UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate
        [Required(ErrorMessage = "UserName Is Mandetory")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "EmailID Is Mandetory")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "MobileNumber Is Mandetory")]
        public string MobileNumber { get; set; }

        [Required(ErrorMessage = "Salary Is Mandetory")]
        public int Salary { get; set; }

        [Required(ErrorMessage = "Gender Is Mandetory")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "MarriedStatus Is Mandetory")]
        public bool Marrried { get; set; }

        [Required(ErrorMessage = "Designation Is Mandetory")]
        public int DesignationId { get; set; }

        [Required(ErrorMessage = "uploadedDate Is Mandetory")]
        public DateTime uploadedDate { get; set; }

        [Required(ErrorMessage = "updatedDate Is Mandetory")]
        public DateTime updatedDate { get; set; }

    }

    public class UpdateUserInformation {
        public int UserId { get; set; } // userId, UserName, EmailID, MobileNumber, Salary, Gender, Marrried, DesignationId, uploadedDate, updatedDate
        public string UserName { get; set; }
        public string EmailID { get; set; }
        public string MobileNumber { get; set; }
        public string Salary { get; set; }
        public string Gender { get; set; }
        public bool Married { get; set; }
        public int DesignationId { get; set; }
        public string uploadedDate { get; set; }
        public string updatedDate { get; set; }
    }


    public class AddUser
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public IEnumerable<IFormFile> ImageFiles { get; set; }
        public IEnumerable<Images> userImages { get; set; }
    }

    public class AddUserResponce
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public IEnumerable<Images> UserImages { get; set; }
    }

    public class Images {

        public int ImageId { get; set; }
        public string Image { get; set; }
        public IFormFile ImageFile { get; set; }
        public string Name { get; set; }
        public int Id { get; set; }
        public string Imagetype { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedUser { get; set; }
        public DateTime LastUpdateDate { get; set; }
        public string LastUpdateUser { get; set; }
    }


    // for only upload multiple images
    public class ImageUser { 
        public int Id { get; set; }
        public string Name { get; set; }
        public IEnumerable<IFormFile> ImageFiles { get; set; }
        public IEnumerable<MultipleImages> UploadImages { get; set; }
    }

    public class MultipleImages { 
       public int Id { get; set; }
        public string Imagetype { get; set; }
        public string Imageurl { get; set; }
        public IFormFile ImageFile { get; set; }
    }


    public class AddNewUserRequest
    {
        //UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string Gender { get; set; }
        public bool Married { get; set; }
        public string DateOfJoining { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public IEnumerable<IFormFile> Images { get; set; }
        public IEnumerable<UserImage> userImages { get; set; }
        public IEnumerable<Froots> SelectedFroots { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class Froots { 
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Checked { get; set; }
        public int UserId { get; set; }
    }

    public class UserImage {

        public int ImageId { get; set; }
        public string ImageName { get; set; }
        public IFormFile ImageFile { get; set; }
        public int UserId { get; set; }
        public string ImageType { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? LastUpdatedDate { get; set; }
    }

    public class GetNewUsers
    {
        //UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string Gender { get; set; }
        public bool Married { get; set; }
        public string DateOfJoining { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public List<UserImage> userImages { get; set; }
        public List<Froots> SelectedFroots { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class UpdateNewUserRequest
    {
        //UserName, EmailID, MobileNumber, Salary, Gender, Married, DesignationId, uploadedDate, updatedDate
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }
        public string Gender { get; set; }
        public bool Married { get; set; }
        public string DateOfJoining { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public IEnumerable<IFormFile> Images { get; set; }
        public IEnumerable<UserImage> userImages { get; set; }
        public IEnumerable<Froots> SelectedFroots { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }

    public class UpdateUserImages
    {
        public int UserId { get; set; }
        public IEnumerable<IFormFile> Images { get; set; }
        public IEnumerable<UserImage> userImages { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
