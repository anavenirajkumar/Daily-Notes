﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;
using WebAPI.DTOS;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Services
{
    public class CategoryService : ICategory
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        string connectionString = "Server=SBSLPT-34; Initial Catalog=MiniProject; user id=sa; password=sql@123;";


        public CategoryService(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);

        }
        // Create Country
        public async Task<CategoryResponce> Category(Category category)
        {
            CategoryResponce responce = new CategoryResponce();
            responce.Message = "Category Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO Category (CategoryName) Values (@CategoryName);";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@CategoryName", category.CategoryName);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "Category Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }

        public async Task<SubCategoryResponce> SubCategory(SubCategory subcategory)
        {
            int CategoryId = subcategory.CategoryId;
            SubCategoryResponce responce = new SubCategoryResponce();
            responce.Message = "SubCategory Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                //string SqlQuery = @"UPDATE registerUser SET Village = @Village, Mandal = @Mandal, District = @District WHERE UserId = @UserID";

                string SqlQuery = @"INSERT INTO SubCategory (SubCategoryName, CategoryId ) Values (@SubCategoryName, @CategoryId);";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@SubCategoryName", subcategory.SubCategoryName);
                    sqlCommand.Parameters.AddWithValue("@CategoryId ", CategoryId);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "SubCategory Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }


        public async Task<CategoryProductResponce> Product(CategoryProduct product)
        {
            int CategoryId = product.CategoryId;
            int SubCategoryId = product.SubCategoryId;
            //int productPrice = product.ProductPrice;

            CategoryProductResponce responce = new CategoryProductResponce();
            responce.Message = "Product Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                //string SqlQuery = @"UPDATE registerUser SET Village = @Village, Mandal = @Mandal, District = @District WHERE UserId = @UserID";

                string SqlQuery = @"INSERT INTO Product (ProductName, ProductPrice, CategoryId, SubCategoryId) Values (@ProductName, @ProductPrice, @CategoryId, @SubCategoryId);";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@ProductName", product.ProductName);
                    sqlCommand.Parameters.AddWithValue("@ProductPrice", product.ProductPrice);
                    sqlCommand.Parameters.AddWithValue("@CategoryId ", CategoryId);
                    sqlCommand.Parameters.AddWithValue("@SubCategoryId ", SubCategoryId);

                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "Product Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }

        public async Task<CategoryResponce> GetCategories()
        {
            {
                CategoryResponce response = new CategoryResponce();
                response.Message = "Get Categories SuccessFul";
                // GetInformation userResponce = new GetInformation();
                try
                {
                    if (_SqlConnection.State != System.Data.ConnectionState.Open)
                    {
                        await _SqlConnection.OpenAsync();
                    }

                    string SqlQuery = @"SELECT * FROM Category";

                    using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                    {
                        sqlCommand.CommandType = System.Data.CommandType.Text;
                        sqlCommand.CommandTimeout = 180;
                        using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (dataReader.HasRows)
                            {
                                response.Categories = new List<Categories>();

                                while (await dataReader.ReadAsync())
                                {
                                    Categories data = new Categories();

                                    data.CategoryId = dataReader["CategoryId"] != DBNull.Value ? Convert.ToString(dataReader["CategoryId"]) : string.Empty;
                                    data.CategoryName = dataReader["CategoryName"] != DBNull.Value ? Convert.ToString(dataReader["CategoryName"]) : string.Empty;

                                    response.Categories.Add(data);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    response.Message = ex.Message;
                }
                finally
                {
                    await _SqlConnection.CloseAsync();
                    await _SqlConnection.DisposeAsync();
                }

                return response;
            }
        }

        public async Task<SubCategoryResponce> GetSubCategories()
        {
            {
                SubCategoryResponce response = new SubCategoryResponce();
                response.Message = "Get SubCategories SuccessFul";
                // GetInformation userResponce = new GetInformation();
                try
                {
                    if (_SqlConnection.State != System.Data.ConnectionState.Open)
                    {
                        await _SqlConnection.OpenAsync();
                    }

                    string SqlQuery = @"SELECT * FROM SubCategory";

                    using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                    {
                        sqlCommand.CommandType = System.Data.CommandType.Text;
                        sqlCommand.CommandTimeout = 180;
                        using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (dataReader.HasRows)
                            {
                                response.SubCategories = new List<SubCategories>();

                                while (await dataReader.ReadAsync())
                                {
                                    SubCategories data = new SubCategories();

                                    data.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                                    data.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                                    data.SubCategoryName = dataReader["SubCategoryName"] != DBNull.Value ? Convert.ToString(dataReader["SubCategoryName"]) : string.Empty;

                                    response.SubCategories.Add(data);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    response.Message = ex.Message;
                }
                finally
                {
                    await _SqlConnection.CloseAsync();
                    await _SqlConnection.DisposeAsync();
                }

                return response;
            }
        }

        public async Task<CategoryResponce> GetCategory(int categoryId)
        {
            CategoryResponce response = new CategoryResponce();
            response.Message = "Get Category";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT CategoryId, CategoryName FROM Category WHERE CategoryId = " + categoryId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = "Get Category Successful";
                            response.CategoryId = dataReader["CategoryId"] != DBNull.Value ? Convert.ToString(dataReader["CategoryId"]) : string.Empty;
                            response.CategoryName = dataReader["CategoryName"] != DBNull.Value ? Convert.ToString(dataReader["CategoryName"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;

        }

        public async Task<SubCategoryResponce> GetSubCategory(int subcategoryId)
        {
            SubCategoryResponce response = new SubCategoryResponce();
            response.Message = "Get SubCategory";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT SubCategoryId, SubCategoryName, CategoryId FROM SubCategory WHERE SubCategoryId = " + subcategoryId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = "Get SubCategory Successful";
                            response.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                            response.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                            response.SubCategoryName = dataReader["SubCategoryName"] != DBNull.Value ? Convert.ToString(dataReader["SubCategoryName"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CategoryProductResponce> GetProduct(int productId)
        {
            CategoryProductResponce response = new CategoryProductResponce();
            response.Message = "Get Product";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT ProductId, ProductName, ProductPrice, CategoryId, SubCategoryId FROM Product WHERE ProductId = " + productId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = "Get Product Successful";
                            response.ProductId = Convert.ToInt32(dataReader["ProductId"]);
                            response.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                            response.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                            response.ProductName = dataReader["ProductName"] != DBNull.Value ? Convert.ToString(dataReader["ProductName"]) : string.Empty;
                            response.ProductPrice = Convert.ToInt32(dataReader["ProductPrice"]);
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CategoryResponce> UpdateCategory(Category category)
        {
            var categoryId = Convert.ToInt32(category.CategoryId);
            string categoryName = category.CategoryName;

            CategoryResponce response = new CategoryResponce();
            response.Message = "Category Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (categoryId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE Category SET CategoryName = @CategoryName WHERE CategoryId = @categoryId";



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@CategoryId", categoryId);
                    sqlCommand.Parameters.AddWithValue("@CategoryName", categoryName);

                    response.CategoryId = Convert.ToString(categoryId);
                    response.CategoryName = categoryName;

                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        response.Message = "Category Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<SubCategoryResponce> UpdateSubCategory(SubCategory subcategory)
        {
            var subcatedoryId = Convert.ToInt32(subcategory.SubCategoryId);
            string subcategoryName = subcategory.SubCategoryName;

            SubCategoryResponce response = new SubCategoryResponce();
            response.Message = "SubCategory Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (subcatedoryId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE SubCategory SET SubCategoryName = @SubCategoryName, CategoryId = @CategoryId WHERE SubCategoryId = " + subcatedoryId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@SubCategoryId", subcatedoryId);
                    sqlCommand.Parameters.AddWithValue("@SubCategoryName", subcategoryName);
                    sqlCommand.Parameters.AddWithValue("@CategoryId", subcategory.CategoryId);

                    response.CategoryId = subcategory.CategoryId;
                    response.SubCategoryId = subcatedoryId;
                    response.SubCategoryName = subcategory.SubCategoryName;

                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        response.Message = "SubCategory Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CategoryProductResponce> UpdateProduct(CategoryProduct product)
        {
            var productId = Convert.ToInt32(product.ProductId);

            CategoryProductResponce response = new CategoryProductResponce();
            response.Message = "Product Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (productId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE Product SET ProductName = @ProductName, ProductPrice = @ProductPrice, CategoryId = @CategoryId, SubCategoryId = @SubCategoryId  WHERE ProductId = " + productId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@ProductId", productId);
                    sqlCommand.Parameters.AddWithValue("@ProductName", product.ProductName);
                    sqlCommand.Parameters.AddWithValue("@ProductPrice", product.ProductPrice);
                    sqlCommand.Parameters.AddWithValue("@CategoryId", product.CategoryId);
                    sqlCommand.Parameters.AddWithValue("@SubCategoryId", product.SubCategoryId);

                    response.CategoryId = product.CategoryId;
                    response.SubCategoryId = product.SubCategoryId;
                    response.ProductName = product.ProductName;
                    response.ProductPrice = product.ProductPrice;
                  
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        response.Message = "Product Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CategoryResponce> DeleteCategory(int categoryId)
        {
            CategoryResponce response = new CategoryResponce();
            response.Message = "Sub Category Deleted";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM Category WHERE CategoryId = " + categoryId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Message = "Category Delete Successful";
                            response.CategoryId = dataReader["CategoryId"] != DBNull.Value ? Convert.ToString(dataReader["CategoryId"]) : string.Empty;
                            response.CategoryName = dataReader["CategoryName"] != DBNull.Value ? Convert.ToString(dataReader["CategoryName"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<SubCategoryResponce> DeleteSubCategory(int subcategoryId)
        {
            SubCategoryResponce response = new SubCategoryResponce();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM SubCategory WHERE SubCategoryId = " + subcategoryId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        response.Message = "SubCategory Deleted Successful";

                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                            response.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                            response.SubCategoryName = dataReader["SubCategoryName"] != DBNull.Value ? Convert.ToString(dataReader["SubCategoryName"]) : string.Empty;
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CategoryProductResponce> DeleteProduct(int productId)
        {
            CategoryProductResponce response = new CategoryProductResponce();
            response.Message = " Product Deleted Successful";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM Product WHERE ProductId = " + productId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = " Product Deleted Successful";
                            response.ProductId = Convert.ToInt32(dataReader["ProductId"]);
                            response.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                            response.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                            response.ProductName = dataReader["ProductName"] != DBNull.Value ? Convert.ToString(dataReader["ProductName"]) : string.Empty;
                            response.ProductPrice = Convert.ToInt32(dataReader["ProductPrice"]);
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }





        public async Task<SubCategoryResponce> GetSubCategoriesById(int categoryId)
        {
            SubCategoryResponce response = new SubCategoryResponce();
            //response. = true;
            response.Message = "Get GetSubCategories Data SuccessFully";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                var SqlQuery = "SELECT C.*,P.* FROM Category AS P INNER JOIN SubCategory AS C ON (P.CategoryId = C.CategoryId) where P.CategoryId = " + categoryId; // if pass 1 GET Proper Data

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.SubCategories = new List<SubCategories>();

                            while (await dataReader.ReadAsync())
                            {
                                SubCategories data = new SubCategories();

                                data.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                                data.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                                data.SubCategoryName = dataReader["SubCategoryName"] != DBNull.Value ? Convert.ToString(dataReader["SubCategoryName"]) : string.Empty;
                                response.SubCategories.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CategoryProductResponce> GetProducts()
        {
            {
                CategoryProductResponce response = new CategoryProductResponce();
                response.Message = "Get Products SuccessFul";
                try
                {
                    if (_SqlConnection.State != System.Data.ConnectionState.Open)
                    {
                        await _SqlConnection.OpenAsync();
                    }

                    string SqlQuery = @"SELECT * FROM Product";

                    using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                    {
                        sqlCommand.CommandType = System.Data.CommandType.Text;
                        sqlCommand.CommandTimeout = 180;
                        using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                        {
                            if (dataReader.HasRows)
                            {
                                response.Products = new List<CategoryProducts>();

                                while (await dataReader.ReadAsync())
                                {
                                    CategoryProducts data = new CategoryProducts();

                                    data.ProductId = Convert.ToInt32(dataReader["ProductId"]);
                                    data.ProductName = dataReader["ProductName"] != DBNull.Value ? Convert.ToString(dataReader["ProductName"]) : string.Empty;
                                    data.ProductPrice = Convert.ToInt32(dataReader["ProductPrice"]);
                                    data.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                                    data.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);

                                    response.Products.Add(data);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    response.Message = ex.Message;
                }
                finally
                {
                    await _SqlConnection.CloseAsync();
                    await _SqlConnection.DisposeAsync();
                }

                return response;
            }
        }

        /* public async Task<ProductResponce> GetProducts(int subcategoryId)
         {
             ProductResponce response = new ProductResponce();
             //response. = true;
             response.Message = "Get Products Data SuccessFully";
             // GetInformation userResponce = new GetInformation();
             try
             {
                 if (_SqlConnection.State != System.Data.ConnectionState.Open)
                 {
                     await _SqlConnection.OpenAsync();
                 }
                 var SqlQuery = "SELECT A.*,B.*,C.* FROM Category AS A INNER JOIN SubCategory AS B INNER JOIN Product AS C ON (A.CategoryId = B.CategoryId) where C.CategoryId = " + subcategoryId; // if pass 1 GET Proper Data

                 using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                 {
                     sqlCommand.CommandType = System.Data.CommandType.Text;
                     sqlCommand.CommandTimeout = 180;
                     using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                     {
                         if (dataReader.HasRows)
                         {
                             response.Products = new List<Products>();

                             while (await dataReader.ReadAsync())
                             {
                                 Products data = new Products();

                                 data.CategoryId = Convert.ToInt32(dataReader["CategoryId"]);
                                 data.SubCategoryId = Convert.ToInt32(dataReader["SubCategoryId"]);
                                 data.ProductId = Convert.ToInt32(dataReader["ProductId"]);
                                 data.ProductName = dataReader["ProductName"] != DBNull.Value ? Convert.ToString(dataReader["ProductName"]) : string.Empty;
                                 response.Products.Add(data);
                             }
                         }
                     }
                 }
             }
             catch (Exception ex)
             {
                 //response.IsSuccess = false;
                 response.Message = ex.Message;
             }
             finally
             {
                 await _SqlConnection.CloseAsync();
                 await _SqlConnection.DisposeAsync();
             }

             return response;
         }*/
    }
}
