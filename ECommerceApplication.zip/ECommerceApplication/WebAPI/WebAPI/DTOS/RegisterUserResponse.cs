﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class RegisterUserResponse  // DTOs -> Data transfer object structure Responce's
    {
        public string UserID { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }

    public class UserLoginResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        //
        //public UserLoginInformation data { get; set; }
        public string Token { get; set; }

        public string UserID { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }
        public string Village { get; set; }
        public string Mandal { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string District { get; set; }
        public string MobileNumber { get; set; }
        public DateTime? LastLogin { get; set; }
        public List<ProductOrder> Cart { get; set; }
        public List<string> Roles { get; set; }



    }

    public class GetInfoByEmail {
       // public string Token { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }
        public string Village { get; set; }
        public string Mandal { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string District { get; set; }
        public DateTime? LastLogin { get; set; }

    }

    public class AddInformationResponse
    {
        //public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }

    public class GetInformationResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }

        public List<GetInformation> getInformation { get; set; }
    }

    public class GetInformation
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string EmailID { get; set; }
        public string MobileNumber { get; set; }
        public string Salary { get; set; }
        public string Gender { get; set; }
        public bool Marrried { get; set; }
        public int DesignationId { get; set; }
        public string uploadedDate { get; set; }
        public string updatedDate { get; set; }
    }
    public class UserAddressResponce
    {
        public string Message { get; set; }

    }

    public class GetUsers
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public List<Users> users { get; set; }
        public List<UserImages> userImages { get; set; }
    }

    public class Users {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
    }

    public class UserImages { 
      public int ImageId { get; set; }
      public string Name { get; set; }
      public string Image { get; set; }
      public int UserId { get; set; }
    }


    public class GetUser {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        //public string Message { get; set; }
        public List<UserImages> userImages { get; set; }

    }

   /* public class UserOrder
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public string Token { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }
        public string Village { get; set; }
        public string Mandal { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string District { get; set; }
        public string LastLogin { get; set; }
        public List<ProductOrder> Cart { get; set; }

    }*/

    public class ProductOrder
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string PictureUrl { get; set; }
        public int ProductType { get; set; }
        public int ProductBrand { get; set; }
    }
}
