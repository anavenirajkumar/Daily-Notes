﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.DTOS
{
    public class CategoryResponce
    {
        public string Message { get; set; }
        public string CategoryId { get; set; }
        public string CategoryName { get; set; }
        public List<Categories> Categories { get; set; }
    }

    public class Categories
    {
        public string CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
    public class SubCategoryResponce
    {
        public string Message { get; set; }
        public int SubCategoryId { get; set; }
        public string SubCategoryName { get; set; }
        public int CategoryId { get; set; }
        public List<SubCategories> SubCategories { get; set; }
    }

    public class SubCategories
    {
        public int SubCategoryId { get; set; }
        public string SubCategoryName { get; set; }
        public int CategoryId { get; set; }
    }
    public class CategoryProductResponce
    {
        public string Message { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductPrice { get; set; }
        public int CategoryId { get; set; }
        public int SubCategoryId { get; set; }
        public List<CategoryProducts> Products { get; set; }
    }

    public class CategoryProducts
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductPrice { get; set; }
        public int CategoryId { get; set; }
        public int SubCategoryId { get; set; }
    }
}
