﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
    public class UserController : ControllerBase
    {

        public readonly IUser _user;

        public UserController(IUser user)
        {
            _user = user;
        }

        [Route("RegisterUser")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> RegisterUser(RegisterUser request)
        {
            var response = await _user.RegisterUser(request);
            return Ok(response);
        }

        [Route("LoginUser")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> UserLogin(UserLoginRequest request)
        {
            var response = await _user.UserLogin(request);
            return Ok(response);
        }



        [Route("GetRefreshUser/{email}/{userId}")]
        [HttpGet]
        public async Task<IActionResult> GetRefreshUser(string email, string userId) {
            var response = await _user.GetRefreshUser(email, userId);
            return Ok(response);
        }

        [Route("GetLoggedUser/{userId}")]
        [HttpGet]
        //[Authorize(Roles = "User, Admin")]
        public async Task<IActionResult> GetLoggedUser(int userId)
        {
            var response = await _user.GetLoggedUser(userId);
            return Ok(response);
        }

        [Route("Address")]
        [HttpPost]
        [Authorize(Roles = "User, Admin")]
        public async Task<IActionResult> UpdateAddress(UserLoginResponse user) // Get All Users Information
        {
            var  response = await _user.UserDetails(user);
            return Ok(response);
        }

        [Route("Admin/Add")]
        [HttpPost]
        [Authorize(Roles = "Admin")] // Admin Can Add Anything
        public async Task<IActionResult> AddInformation(AddInformationRequest request)
        {
            var  response = await _user.AddInformation(request);
            return Ok(response);
        }

        [Route("Admin/Get")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<IActionResult> GetInformation() // Get All Users Information
        {
            GetInformationResponse response = new GetInformationResponse();
            try
            {
                response = await _user.GetInformation();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);

        }

        [Route("Admin/GetUserInfo")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<GetInformation> GetUserInformation(int Id)
        {
            var response = await _user.GetUserInfo(Id);
            if (response == null)
            {
                return null;
            }
            return response;
        }


        [Route("Admin/UpdateUserInfo")]
        [HttpPut]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation userInfo)
        {
            var user = await _user.UpdateUserInformation(userInfo);
            return user;
        }

        [Route("Admin/AddUser")]
        [HttpPost]
        [Authorize(Roles = "Admin")] // Admin Can Add Anything
        public async Task<IActionResult> AddUser([FromForm] AddUser request)
        {
            AddUser response = new AddUser();
            if (request.Id == 0)
            {
                response = await _user.AddUser(request);
            }
            else
            {
                response = await _user.UpdateUser(request);
            }
            return Ok(response);
        }

        [Route("Admin/GetUsers")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<GetUsers> GetUsers() // Get All Users Information
        {
            GetUsers response = new GetUsers();
            try
            {
                response = await _user.GetUsers();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;

        }


        [Route("Admin/GetUser")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<GetUser> GetUserById(int id) // Get All Users Information
        {
            GetUser response = new GetUser();
            try
            {
                response = await _user.GetUserById(id);
            }
            catch (Exception ex)
            {
                //response.Message = ex.Message;
                Console.WriteLine(ex.Message);
            }

            return response;

        }

        [Route("Admin/DeleteUser")]
        [HttpDelete]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<UserAddressResponce> DeleteUser(int id)
        {
            var response = await _user.DeleteUserById(id);
            if (response == null)
            {
                return null;
            }
            return response;
        }

        [Route("Admin/DeleteImage")]
        [HttpDelete]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<bool> DeleteSpecificImage(int id)
        {
            var response = await _user.DeleteSpecificImage(id);
            if (response == false)
            {
                return false;
            }
            return true;
        }

        [Route("Admin/AddNewUser")]
        [HttpPost]
        [Authorize(Roles = "Admin")] // Admin Can Add Anything
        public async Task<IActionResult> AddNewUser([FromForm] AddNewUserRequest request)
        {
            AddNewUserRequest response = new AddNewUserRequest();
            try
            {
                if (request.UserId == 0)
                {
                    response = await _user.AddNewUserRequest(request);
                }
                else
                {
                    response = await _user.UpdateNewUserRequest(request);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return Ok(response);
        }

        [Route("Admin/GetNewUsers")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        [HttpGet]
        public async Task<IActionResult> GetNewUsers()
        {
            var result = await _user.GetNewUsers();
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return StatusCode(500);
            }
        }

        [Route("Admin/GetNewUserById/{UserId}")]
        [HttpGet]
        [Authorize(Roles = "Admin")] // Admin, User
        [HttpGet]
        public async Task<IActionResult> GetNewUserById(int UserId)
        {
            var result = await _user.GetNewUserById(UserId);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return StatusCode(500);
            }
        }


        [Route("Admin/DeleteNewUser/{id}")]
        [HttpDelete]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<bool> DeleteNewUser(int id)
        {
            var response = await _user.DeleteNewUserById(id);
            if (response == false)
            {
                return false;
            }
            return response;
        }


        [Route("Admin/DeleteUserImage")]
        [HttpDelete]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<bool> DeleteUserImage(int id)
        {
            var response = await _user.DeleteUserImage(id);
            if (response == false)
            {
                return false;
            }
            return true;
        }


        [Route("Admin/UserImages")]
        [HttpPost]
        [Authorize(Roles = "Admin")] // Admin, User
        public async Task<IActionResult> GetUserImages([FromForm] UpdateUserImages request)
        {
            var result = await _user.UpdateImages(request);
            if (result != null)
            {
                return Ok(result);
            }
            else
            {
                return StatusCode(500);
            }
        }



        [Route("Admin/uploadIMages")]
        [HttpPost]
        //[Authorize(Roles = "Admin")] // Admin Can Add Anything
        public async Task<IActionResult> uploadImages([FromForm] ImageUser request)
        {
            UserImages response = new UserImages();
            return null;
        }

        [Route("User/Logout")]
        [HttpPost]
        public async Task<string> LogoutUser(UserLoginResponse user, string token)
        {
            var responce = "";
            try
            {
                responce = await _user.LogoutUser(user, token);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                responce = "Token Not Wxpired";
            }
            return responce;
        }

        [HttpGet("GetUsers/Download")]
        [AllowAnonymous]
        public async Task<IActionResult> GetUsersReportDownload()
        {
            var reportData = await _user.GetUsersXMLFile();
            return reportData != null ? File(reportData.GetAsByteArray(), "application/octet-stream", "GetUsers.xlsx") : (IActionResult)BadRequest();
        }
        /// <summary>
        /// /////////////////////////////////////////////////////////////////
        /// </summary>
        /// <returns></returns>
        [Route("Product/PlaceOrder")]
        [HttpPost]
       // [Authorize(Roles = "User, Admin")]
        public async Task<IActionResult> PlaceUserOrder([FromForm] UserLoginResponse user)
        {
            var placedOrders = await _user.PlaceUserOrder(user);
            return Ok(placedOrders);
        }

        [Route("GetUserOrders")]
        [HttpGet]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetUserOrders([FromForm] UserLoginResponse user)
        {
            var userOrders = await _user.GetUserOrders(user);
            return Ok(userOrders);
        }

        [Route("GetAllUsersOrders")]
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllOrders([FromBody] UserLoginResponse user)
        {
            var allOrders = await _user.GetAllOrders(user);
            return Ok(allOrders);
        }

    }
}
