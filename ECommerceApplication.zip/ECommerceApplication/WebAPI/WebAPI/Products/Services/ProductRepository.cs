﻿using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebAPI.Core.Entities;
using WebAPI.Interfaces;

namespace WebAPI.Services
{
    public class ProductRepository : IProductRepository
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        string connectionString = "Server=SBSLPT-34; Initial Catalog=MiniProject; user id=sa; password=sql@123;";


        public ProductRepository(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);

        }
        public async Task<bool> AddBrand(ProductBrand request)
        {
           using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                try
                {
                    await con.OpenAsync();
                    await con.ExecuteAsync(@"INSERT INTO ProductBrands (Name,ProductTypeId) Values (@Name, @ProductTypeId)", request);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                return false;
            }

        }
        public async Task<ProductBrandResponce> GetBrand(int id)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var response = await _SqlConnection.QuerySingleAsync<ProductBrandResponce>(@"SELECT * FROM ProductBrands WHERE Id = @id", new { Id = id });
                    return response;
                }
            }
            catch (Exception ex) {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
        public async Task<bool> UpdateBrand(ProductBrand request)
        {
            int Id = request.Id;
          try
            {
               using (var con = new SqlConnection(_SqlConnection.ConnectionString)) {
                    await _SqlConnection.OpenAsync();
                    await _SqlConnection.ExecuteAsync(@"UPDATE ProductBrands SET Name = @Name, ProductTypeId = @ProductTypeId WHERE Id = @Id", request);
                    return true;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;

        }

        public async Task<bool> DeleteBrand(int brandId)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    await con.ExecuteAsync(@"DELETE FROM ProductBrands WHERE Id = @Id", new { Id = brandId });
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;

        }
        public async Task<bool> AddType(ProductType request)
        {
            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                try
                {
                    await con.OpenAsync();
                    await con.ExecuteAsync(@"INSERT INTO ProductTypes (Name) Values (@Name)", request);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                return false;
            }
        }
        public async Task<bool> DeleteType(int Id)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    await con.ExecuteAsync(@"DELETE FROM ProductTypes WHERE Id = @Id", new { Id = Id });
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        public async Task<ProductTypeResponce> GetType(int Id)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var response = await _SqlConnection.QuerySingleAsync<ProductTypeResponce>(@"SELECT Id, Name FROM ProductTypes WHERE Id = @Id", new { Id = Id });
                    return response;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        public async Task<bool> UpdateType(ProductType request)
        {
            int Id = request.Id;
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    await _SqlConnection.ExecuteAsync(@"UPDATE ProductTypes SET Name = @Name WHERE Id = @Id", request);
                    return true;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }

        public async Task<bool> AddProduct(Product request)
        {

            using (var con = new SqlConnection(_SqlConnection.ConnectionString))
            {
                try
                {
                    await con.OpenAsync();
                    await con.ExecuteAsync(@"INSERT INTO Products (Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId) Values
                                    (@Name, @Description, @Price, @PictureUrl, @ProductTypeId, @ProductBrandId)", request);
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
                return false;
            }
        }

        // Load File to Base64 Format
    /*    private async Task<string> LoadFromDB(string filedata)
        {
            Regex regex = new Regex(@"^[\w/\:.-]+;base64,");
            var image = regex.Replace(filedata, string.Empty);
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(image);
            var dec = Decode(image);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        // Save Base64 to File Name
        private async Task<string> Decode(string filedata)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(filedata);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }*/

        public async Task<bool> DeleteProduct(int productId)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    await con.ExecuteAsync(@"DELETE FROM Products WHERE Id = @Id", new { Id = productId });
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }
        public async Task<bool> UpdateProduct(Product request)
        {
            int Id = request.Id;
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    await _SqlConnection.ExecuteAsync(@"UPDATE Products SET Name = @Name, Price = @Price, Description = @Description, PictureUrl = @PictureUrl, ProductTypeId = @ProductTypeId, ProductBrandId = @ProductBrandId WHERE Id = @Id", request);
                    return true;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return false;
        }
        public async Task<GetProductResponce> GetProductByIdAsync(int Id)
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var product = await _SqlConnection.QuerySingleAsync<GetProductResponce>(@"SELECT Id, Name, Price, Description, PictureUrl, ProductTypeId, ProductBrandId  FROM Products WHERE Id = @Id", new { Id= Id});
                    return product;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        public async Task<List<Products>> GetProductsAsync()
        {
            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var products = await _SqlConnection.QueryAsync<Products>(@"SELECT * FROM Products");
                    return (List<Products>)products;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;          
        }

        public async Task<GetNoteResponse> GetProducts(GetProducts request)
        {
            GetNoteResponse response = new GetNoteResponse();
            response.IsSuccess = true;
            response.Message = "Fetch Data Successfully.";

          /*  try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                int Offset = (request.PageNumber - 1) * request.NumberOfRecordPerPage;
                int NumberOfRecordPerPage = request.NumberOfRecordPerPage;
                var searchName = request.SearchName+ '%';
                var brandId = request.BrandId;
                var typeId = request.TypeId;
                string SqlQuery = string.Empty;


                *//*   SqlQuery = @" SELECT ProductId, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                     (SELECT COUNT(*) FROM Products) AS TotalRecord
                                     From Products 
                                     Order By ProductId " + request.SortBy.ToUpperInvariant()+@"
                                     LIMIT @Offset, @NumberOfRecordPerPage";*//*

                if (request.SearchName.Length > 0) {
                    //SqlQuery = "SELECT * FROM Products WHERE Name LIKE @searchName";
                    SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE Name LIKE @searchName ) AS TotalRecord
                                  From Products WHERE Name LIKE @searchName
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";

                    *//* SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                   (SELECT COUNT(*) FROM Products WHERE Name LIKE 'i%') AS TotalRecord
                                   From Products WHERE Name LIKE 'i%'*//*
                }

                else if (request.BrandId > 0) {
                    SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductBrandId = @brandId) as TotalRecord from Products WHERE ProductBrandId = @brandId
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";

                    *//* SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                   (SELECT COUNT(*) FROM Products WHERE ProductBrandId = 10) as TotalRecord from Products WHERE ProductBrandId = 10
                                   Order By Id asc
                                   OFFSET 0 ROWS
                                   FETCH NEXT 6 ROWS ONLY;*//*
                }

                else if (request.TypeId > 0)
                {
                    SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductTypeId = @typeId) as TotalRecord from Products WHERE ProductTypeId = @typeId
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";

                    *//* SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                   (SELECT COUNT(*) FROM Products WHERE ProductBrandId = 10) as TotalRecord from Products WHERE ProductBrandId = 10
                                   Order By Id asc
                                   OFFSET 0 ROWS
                                   FETCH NEXT 6 ROWS ONLY;*//*
                }
                else
                {
                    SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products) AS TotalRecord
                                  From Products
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                }



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@brandId", request.BrandId);
                    sqlCommand.Parameters.AddWithValue("@typeId", request.TypeId);
                    sqlCommand.Parameters.AddWithValue("@searchName", searchName);
                    sqlCommand.Parameters.AddWithValue("@Offset", Offset);
                    sqlCommand.Parameters.AddWithValue("@NumberOfRecordPerPage", request.NumberOfRecordPerPage);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            int Count = 0;
                            response.data = new List<ProductResponce>();
                            while (await dataReader.ReadAsync())
                            {
                                response.data.Add(
                                    new ProductResponce()
                                    {
                                       *//* NoteId = dataReader["Id"] != DBNull.Value ? (Int32)dataReader["Id"] : -1,
                                        Note = dataReader["Note"] != DBNull.Value ? (string)dataReader["Note"] : null,
                                        ScheduleDate = dataReader["ScheduleDate"] != DBNull.Value ? Convert.ToDateTime(dataReader["ScheduleDate"]).ToString("dd/MM/yyyy") : null,
                                        ScheduleTime = dataReader["ScheduleTime"] != DBNull.Value ? Convert.ToDateTime(dataReader["ScheduleTime"]).ToString("hh:mm tt") : null,
                                        Monday= dataReader["Monday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Monday"]) : false,
                                        Tuesday= dataReader["Tuesday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Tuesday"]) : false,
                                        Wednesday= dataReader["Wednesday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Wednesday"]) : false,
                                        Thursday= dataReader["Thursday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Thursday"]) : false,
                                        Friday= dataReader["Friday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Friday"]) : false,
                                        Saturday= dataReader["Saturday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Saturday"]) : false,
                                        Sunday= dataReader["Sunday"] != DBNull.Value ? Convert.ToBoolean(dataReader["Sunday"]) : false,*//*

                                Id =dataReader["Id"] != DBNull.Value ? (Int32)dataReader["Id"] : -1,
                                Name = dataReader["Name"] != DBNull.Value ? (string)dataReader["Name"] : null,
                                        Description = dataReader["Description"] != DBNull.Value ? (string)dataReader["Description"] : null,
                                        PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? (string)dataReader["PictureUrl"] : null,
                                        Price = Convert.ToInt32(dataReader["Price"]),
                                ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]),
                                ProductType =  Convert.ToInt32(dataReader["ProductTypeId"])
                                    });

                                if (Count == 0)
                                {
                                    Count++;
                                    response.TotalRecords = dataReader["TotalRecord"] != DBNull.Value ? Convert.ToInt32(dataReader["TotalRecord"]) : -1;
                                    //response.TotalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(response.TotalRecords / request.NumberOfRecordPerPage)));
                                    response.CurrentPage = request.PageNumber;
                                    response.PageSize = request.NumberOfRecordPerPage;
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = "Exception Occurs : " + ex.Message;
            }

            return response;*/

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    int Offset = (request.PageNumber - 1) * request.NumberOfRecordPerPage;
                    int NumberOfRecordPerPage = request.NumberOfRecordPerPage;
                    var searchName = request.SearchName+ '%';
                    var brandId = request.BrandId;
                    var typeId = request.TypeId;
                    string SqlQuery = string.Empty;

                if (request.SearchName.Length > 0)
                    {
                        SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE Name LIKE @searchName ) AS TotalRecord
                                  From Products WHERE Name LIKE @searchName
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                }

                    else if (request.BrandId > 0)
                    {
                        SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductBrandId = @brandId) as TotalRecord from Products WHERE ProductBrandId = @brandId
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                }

                    else if (request.TypeId > 0)
                    {
                        SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductTypeId = @typeId) as TotalRecord from Products WHERE ProductTypeId = @typeId
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }
                    else if (request.BrandId == 0 && request.TypeId == 0 && string.IsNullOrEmpty(request.SearchName) && !string.IsNullOrEmpty(request.SortBy)) {
                        SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products) AS TotalRecord
                                  From Products order by CAST(Price AS Float)" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }
                    else{
                        SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products) AS TotalRecord
                                  From Products
                                  Order By Id" + " " + request.SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }
                    GetNoteResponse productsList = new GetNoteResponse();
                    productsList.data = (List<ProductResponce>)await con.QueryAsync<ProductResponce>(SqlQuery, new { brandId = brandId, typeId = typeId, searchName = searchName, Offset  = Offset , NumberOfRecordPerPage = request.NumberOfRecordPerPage});

                        productsList.TotalRecords = productsList.data[0].TotalRecord != 0 ? productsList.data[0].TotalRecord : -1;
                        productsList.CurrentPage = request.PageNumber;
                        productsList.PageSize = request.NumberOfRecordPerPage;
                        productsList.IsSuccess = true;
                        productsList.Message = "Fetch Data Successfully.";
                    return productsList;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }

        public async Task<GetNoteResponse> SearchProducts(GetSearchNoteRequest request)
        {
            /*  GetNoteResponse response = new GetNoteResponse();
              response.IsSuccess = true;
              response.Message = "Fetch Data Successfully.";*/
            GetNoteResponse productsList = new GetNoteResponse();

            try
            {
                /*                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                                {
                                    await _SqlConnection.OpenAsync();
                                }
                                //int Offset = (request.PageNumber - 1) * request.NumberOfRecordPerPage;
                                //int NumberOfRecordPerPage = request.NumberOfRecordPerPage;
                                var searchName = request.SearchName+ '%';
                                string SqlQuery = string.Empty;
                                SqlQuery = "SELECT * FROM Products WHERE Name LIKE @searchName";
                                //SqlQuery = "SELECT * FROM Products WHERE Name LIKE" + " " +  request.SearchName.ToUpperInvariant() + " " + request.LastName.ToUpperInvariant();

                                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                                {
                                    sqlCommand.CommandType = System.Data.CommandType.Text;
                                    sqlCommand.CommandTimeout = 180;
                                    //sqlCommand.Parameters.AddWithValue("@Offset", Offset);
                                    sqlCommand.Parameters.AddWithValue("@searchName", searchName);
                                    //sqlCommand.Parameters.AddWithValue("@NumberOfRecordPerPage", request.NumberOfRecordPerPage);
                                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                                    {
                                        if (dataReader.HasRows)
                                        {
                                            //int Count = 0;
                                            response.data = new List<ProductResponce>();
                                            while (await dataReader.ReadAsync())
                                            {
                                                response.data.Add(
                                                    new ProductResponce()
                                                    {
                                                        Id =dataReader["Id"] != DBNull.Value ? (Int32)dataReader["Id"] : -1,
                                                        Name = dataReader["Name"] != DBNull.Value ? (string)dataReader["Name"] : null,
                                                        Description = dataReader["Description"] != DBNull.Value ? (string)dataReader["Description"] : null,
                                                        PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? (string)dataReader["PictureUrl"] : null,
                                                        Price = Convert.ToInt32(dataReader["Price"]),
                                                        ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]),
                                                        ProductType =  Convert.ToInt32(dataReader["ProductTypeId"])
                                                    });

                                               *//* if (Count == 0)
                                                {
                                                    Count++;
                                                    response.TotalRecords = dataReader["TotalRecord"] != DBNull.Value ? Convert.ToInt32(dataReader["TotalRecord"]) : -1;
                                                    response.TotalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(response.TotalRecords / request.NumberOfRecordPerPage)));
                                                    response.CurrentPage = request.PageNumber;
                                                }*//*
                                            }
                                        }
                                    }
                                }*/

                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    string SqlQuery = "SELECT * FROM Products WHERE Name LIKE @searchName";
                    productsList.data = (List<ProductResponce>)await con.QueryAsync<ProductResponce>(SqlQuery, new { searchName = request.SearchName});

                    productsList.TotalRecords = productsList.data[0].TotalRecord != 0 ? productsList.data[0].TotalRecord : -1;
                    productsList.CurrentPage = request.PageNumber;
                    productsList.PageSize = request.NumberOfRecordPerPage;
                    productsList.IsSuccess = true;
                    productsList.Message = "Fetch Data Successfully.";
                    return productsList;
                }
            }
            catch (Exception ex)
            {
                productsList.IsSuccess = false;
                productsList.Message = "Exception Occurs : " + ex.Message;
            }

            return productsList;
        }

        public async Task<List<ProductBrandResponce>> GetBrands()
        {
            /*var response = new List<ProductBrandResponce>();
            //response.Message = "Get Products SuccessFul";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM ProductBrands";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            while (await dataReader.ReadAsync())
                            {
                                ProductBrandResponce data = new ProductBrandResponce();
                                data.Id = Convert.ToInt32(dataReader["Id"]);
                                data.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                                data.ProductTypeId = Convert.ToInt32(dataReader["ProductTypeId"]);
                                response.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;*/


            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var products = await con.QueryAsync<ProductBrandResponce>(@"SELECT * FROM ProductBrands");
                    return (List<ProductBrandResponce>)products;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }


        public async Task<List<ProductTypeResponce>> GetTypes()
        {
            /* var response = new List<ProductTypeResponce>();
             //response.Message = "Get Products SuccessFul";
             try
             {
                 if (_SqlConnection.State != System.Data.ConnectionState.Open)
                 {
                     await _SqlConnection.OpenAsync();
                 }

                 string SqlQuery = @"SELECT * FROM ProductTypes";

                 using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                 {
                     sqlCommand.CommandType = System.Data.CommandType.Text;
                     sqlCommand.CommandTimeout = 180;
                     using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                     {
                         if (dataReader.HasRows)
                         {
                             while (await dataReader.ReadAsync())
                             {
                                 ProductTypeResponce data = new ProductTypeResponce();
                                 data.Id = Convert.ToInt32(dataReader["Id"]);
                                 data.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                                 response.Add(data);
                             }
                         }
                     }
                 }
             }
             catch (Exception ex)
             {
                 Console.WriteLine(ex.Message);
             }
             finally
             {
                 await _SqlConnection.CloseAsync();
                 await _SqlConnection.DisposeAsync();
             }

             return response;*/


            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var products = await con.QueryAsync<ProductTypeResponce>(@"SELECT * FROM ProductTypes");
                    return (List<ProductTypeResponce>)products;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }




        public async Task<DownloadImage> DownloadProductImage(int id)
        {
            /*ProductResponce response = new ProductResponce();

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT Id, Name, Price, Description, PictureUrl, ProductTypeId, ProductBrandId  FROM Products WHERE Id = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Id = Convert.ToInt32(dataReader["Id"]);
                            response.Name = dataReader["Name"] != DBNull.Value ? Convert.ToString(dataReader["Name"]) : string.Empty;
                            response.Description = dataReader["Description"] != DBNull.Value ? Convert.ToString(dataReader["Description"]) : string.Empty;
                            response.PictureUrl = dataReader["PictureUrl"] != DBNull.Value ? Convert.ToString(dataReader["PictureUrl"]) : string.Empty;
                            response.Price = Convert.ToInt32(dataReader["Price"]);
                            response.ProductBrand = Convert.ToInt32(dataReader["ProductBrandId"]);
                            response.ProductType =  Convert.ToInt32(dataReader["ProductTypeId"]);
                            return response; 
                        }
                    }

                }

            }

            catch (Exception ex)
            {
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return null;*/

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    var products = await con.QuerySingleAsync<DownloadImage>(@"SELECT Id, Name, PictureUrl FROM Products WHERE Id = @id", new { Id = id});
                    return products;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;

        }

        public async Task<GetNoteResponse> GetProductsWithQueryParams(int PageNumber, int NumberOfRecordPerPage, string SortBy, string SearchName, int BrandId, int TypeId)
        {
            GetNoteResponse response = new GetNoteResponse();
            response.IsSuccess = true;
            response.Message = "Fetch Data Successfully.";

            try
            {
                using (var con = new SqlConnection(_SqlConnection.ConnectionString))
                {
                    await _SqlConnection.OpenAsync();
                    int Offset = (PageNumber - 1) * NumberOfRecordPerPage;
                    var searchName = SearchName+ '%';
                    var brandId = BrandId;
                    var typeId = TypeId;
                    string SqlQuery = string.Empty;

                    if (!string.IsNullOrEmpty(SearchName))
                    {
                        SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE Name LIKE @searchName ) AS TotalRecord
                                  From Products WHERE Name LIKE @searchName
                                  Order By Id" + " " + SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }

                    else if (BrandId > 0)
                    {
                        SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductBrandId = @brandId) as TotalRecord from Products WHERE ProductBrandId = @brandId
                                  Order By Id" + " " + SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }

                    else if (TypeId > 0)
                    {
                        SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products WHERE ProductTypeId = @typeId) as TotalRecord from Products WHERE ProductTypeId = @typeId
                                  Order By Id" + " " + SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }
                    else if (BrandId == 0 && TypeId == 0 && string.IsNullOrEmpty(SearchName) && !string.IsNullOrEmpty(SortBy))
                    {
                        SqlQuery = @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products) AS TotalRecord
                                  From Products order by CAST(Price AS Float)" + " " + SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }
                    else
                    {
                        SqlQuery =  @" SELECT Id, Name, Description, Price, PictureUrl, ProductTypeId, ProductBrandId,
                                  (SELECT COUNT(*) FROM Products) AS TotalRecord
                                  From Products
                                  Order By Id" + " " + SortBy.ToUpperInvariant()+@"
                                  OFFSET @Offset ROWS
                                  FETCH NEXT @NumberOfRecordPerPage ROWS ONLY";
                    }
                    GetNoteResponse productsList = new GetNoteResponse();
                    productsList.data = (List<ProductResponce>)await con.QueryAsync<ProductResponce>(SqlQuery, new { brandId = brandId, typeId = typeId, searchName = searchName, Offset = Offset, NumberOfRecordPerPage = NumberOfRecordPerPage });

                    productsList.TotalRecords = productsList.data[0].TotalRecord != 0 ? productsList.data[0].TotalRecord : -1;
                    productsList.CurrentPage = PageNumber;
                    productsList.PageSize = NumberOfRecordPerPage;
                    productsList.IsSuccess = true;
                    productsList.Message = "Fetch Data Successfully.";
                    return productsList;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }


        /* public async Task<IReadOnlyList<ProductResponce>> GetProductTypesAsync()
         {

         }



         public Task<IReadOnlyList<ProductBrand>> GetProductBrandsAsync()
         {
             throw new NotImplementedException();
         }
 */

    }
}
