﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Core.Entities
{
    public class ProductBrand : BaseEntity
    {
        public string Name { get; set; }
        public int ProductTypeId { get; set; }
    }

    public class ProductBrandResponce {
        public int Id { get; set; }
        public string Name { get; set; }
        public int ProductTypeId { get; set; }

        //public string Message { get; set; }
    }

    public class ProductTypeResponce{
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
