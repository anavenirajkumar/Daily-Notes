﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Core.Entities
{
    public class Product : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string PictureUrl { get; set; }
        public string FileName { get; set; }
        public ProductType ProductType { get; set; }
        public int ProductTypeId { get; set; }
        public ProductBrand ProductBrand { get; set; }
        public int ProductBrandId { get; set; }
    }


    public class GetProductResponce
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string PictureUrl { get; set; }
        public int ProductTypeId { get; set; }
        public int ProductBrandId { get; set; }
    }

    public class ProductResponce {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string PictureUrl { get; set; }
        public int ProductType { get; set; }
        public int ProductBrand { get; set; }
        public int TotalRecord { get; set; }
    }


    public class ProResponce
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public string PictureUrl { get; set; }
        public int ProductType { get; set; }
        public int ProductBrand { get; set; }
    }

    public class Products
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string PictureUrl { get; set; }
        public double Price { get; set; }
        public int ProductTypeId { get; set; }
        public int ProductBrandId { get; set; }
    }

    public class GetNoteRequest
    {
        [Required]
        public int PageNumber { get; set; }

        [Required]
        public int NumberOfRecordPerPage { get; set; }

        [Required]
        public string SortBy { get; set; } // ASC, DESC
    }



    public class GetNoteResponse
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public int CurrentPage { get; set; }
        public decimal TotalRecords { get; set; }
        //public int TotalPages { get; set; }
       // public int Count { get; set; }
        public int PageSize { get; set; }
        public List<ProductResponce> data { get; set; }
    }


    public class GetSearchNoteRequest
    {
        
        public int PageNumber { get; set; }

        public int NumberOfRecordPerPage { get; set; }

        public string SortBy { get; set; } // ASC, DESC
        [Required]
        public string SearchName { get; set; }
        public string LastName { get; set; }
    }


    public class GetProducts{
        public int PageNumber { get; set; }
        // public int NumberOfRecordPerPage { get; set; }
        public string SortBy { get; set; } // ASC, DESC
        public string SearchName { get; set; }
        public string LastName { get; set; }
        public int BrandId { get; set; }
        public int TypeId { get; set; }

        private const int MaxPageSize = 50;

        private int _pageSize = 6;
        public int NumberOfRecordPerPage
        {
            get => _pageSize;
            set => _pageSize = (value > MaxPageSize) ? MaxPageSize : value;
        }
    }


    public class DownloadImage
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string PictureUrl { get; set; }
    }

}
