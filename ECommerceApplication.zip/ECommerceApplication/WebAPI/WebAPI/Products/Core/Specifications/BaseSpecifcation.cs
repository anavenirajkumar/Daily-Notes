﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace WebAPI.Core.Specifications
{
    public class BaseSpecifcation<T> : ISpecification<T>
    {
        public BaseSpecifcation()
        {
        }

        public BaseSpecifcation(Expression<Func<T, bool>> criteria)
        {
            Criteria = criteria;
        }

        public Expression<Func<T, bool>> Criteria { get; }

        public List<Expression<Func<T, object>>> Includes { get; } = new List<Expression<Func<T, object>>>();

        public Expression<Func<T, object>> OrderBy { get; private set; } // for Products  Assending List wise -> like a,b,c

        public Expression<Func<T, object>> OrderByDescending { get; private set; } // for Products  Dessending List wise -> like c,b,a

        public int Take { get; private set; } // for Pagination

        public int Skip { get; private set; } // for Pagination

        public bool IsPagingEnabled { get; private set; } // for Pagination

        protected void AddInclude(Expression<Func<T, object>> includeExpression)
        {
            Includes.Add(includeExpression);
        }

        protected void AddOrderBy(Expression<Func<T, object>> orderByExpression) // for Products  Assending List wise -> like a,b,c
        {
            OrderBy = orderByExpression;
        }

        protected void AddOrderByDescending(Expression<Func<T, object>> orderByDescExpression) // for Products  Dessending List wise -> like c,b,a
        {
            OrderByDescending = orderByDescExpression;
        }

        protected void ApplyPaging(int skip, int take) // for Pagination
        {
            Skip = skip;
            Take = take;
            IsPagingEnabled = true;
        }
    }
}
