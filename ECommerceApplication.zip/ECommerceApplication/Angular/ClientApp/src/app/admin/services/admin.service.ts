import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
 
  private  baseUrl = environment.apiUrl;
  constructor(private http : HttpClient) { }

  public addCategory(category:any){
    return this.http.post(this.baseUrl + 'Products/AddCategory', category);
  }
  
  public getCategories(){
    return this.http.get(this.baseUrl + 'Products/GetCategories');
   }

  public getCategory(categoryId:any){
    return this.http.get(this.baseUrl + 'Products/Category/' + categoryId)
  }

  public deleteCategory(categoryId:number){
    return this.http.delete(this.baseUrl + 'Products/DeleteCategory/' + categoryId);
  }

  public updateCategory(category:any){
    return this.http.put(this.baseUrl + 'Products/UpdateCategory', category);
  }

  addBrand(brand:any){
    return this.http.post(this.baseUrl + 'Products/AddBrand', brand);
  }
  getBrand(getId:any){
    return this.http.get(this.baseUrl + 'Products/brand/' + getId)
  }

  updateBrand(brand:any){
   return this.http.put(this.baseUrl + 'Products/UpdateBrand', brand);
  }

  deleteBrand(id:any){
    return this.http.delete(this.baseUrl + 'Products/DeleteBrand/' + id);
  }
  
   addProduct(product:any){
    return this.http.post(this.baseUrl + 'Products/AddProduct', product);
  }

  updateProduct(product:any){
    return this.http.put(this.baseUrl + 'Products/UpdateProduct', product);
   }

  // getProduct(getId:any){
  //   return this.http.get<IProduct>(this.baseUrl + 'Products/GetProduct/' + getId)
  // }
   deleteProduct(id:any){
    return this.http.delete(this.baseUrl + 'Products/DeleteProduct/' + id);
  }
}
