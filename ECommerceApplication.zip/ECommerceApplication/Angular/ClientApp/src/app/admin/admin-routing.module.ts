import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { AdminGuard } from '../guards/admin.guard';
import { CategoryComponent } from './components/category/category.component';
import { EditCategoryComponent } from './components/edit-category/edit-category.component';
import { AddBrandComponent } from './components/add-brand/add-brand.component';
import { UpdateBrandComponent } from './components/update-brand/update-brand.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { UpdateProductComponent } from './components/update-product/update-product.component';
import { UploadXmlFileComponent } from './components/upload-xml-file/upload-xml-file.component';
import { IdComponent } from './components/upload-xml-file/id/id.component';
import { UploadMultipleImagesComponent } from './components/upload-multiple-images/upload-multiple-images.component';
import { EditMultipleImagesComponent } from './components/edit-multiple-images/edit-multiple-images.component';
import { Roles } from '../roles/roles';
import { AuthGuard } from '../guards/auth.guard';

const routes: Routes = [
  // Example 1 with AdminGuard
  // { path: '', component: AdminComponent, canActivate : [AdminGuard] },
  // { path: 'category', component : CategoryComponent, canActivate:[AdminGuard]},
  // { path : 'category/:id', component : EditCategoryComponent, canActivate : [AdminGuard]},
  // { path : 'brand', component : AddBrandComponent, canActivate : [AdminGuard]},
  // { path : 'brand/:id', component : UpdateBrandComponent, canActivate : [AdminGuard]},
  // { path : 'product', component : AddProductComponent, canActivate : [AdminGuard]},
  // { path : 'product/:id', component : UpdateProductComponent, canActivate : [AdminGuard]},
  // {path : 'uploadxmlfile', component : UploadXmlFileComponent, canActivate : [AdminGuard]},
  // {path : 'xmlfiles/:id', component : IdComponent, canActivate : [AdminGuard]},
  // {path : 'upload-multiple-images', component : UploadMultipleImagesComponent},
  // {path : 'edit-multiple-images/:id', component : EditMultipleImagesComponent}


    // Example 2 with Auth Guard 
    { path : '', component : AdminComponent,canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]} },
    { path: 'category', component : CategoryComponent, canActivate:[AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    { path : 'category/:id', component : EditCategoryComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    { path : 'brand', component : AddBrandComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    { path : 'brand/:id', component : UpdateBrandComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    { path : 'product', component : AddProductComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    { path : 'product/:id', component : UpdateProductComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    {path : 'uploadxmlfile', component : UploadXmlFileComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    {path : 'xmlfiles/:id', component : IdComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    {path : 'upload-multiple-images', component : UploadMultipleImagesComponent, canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}},
    {path : 'edit-multiple-images/:id', component : EditMultipleImagesComponent,canActivate : [AuthGuard], data : {roles:[Roles.Admin, Roles.Owner]}}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
