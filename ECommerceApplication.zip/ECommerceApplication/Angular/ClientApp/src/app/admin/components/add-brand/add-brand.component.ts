import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ShopService } from 'src/app/shop/services/shop.service';
import { DialogPopupComponent } from '../dialog-popup/dialog-popup.component';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-add-brand',
  templateUrl: './add-brand.component.html',
  styleUrls: ['./add-brand.component.css']
})
export class AddBrandComponent implements OnInit {
   public types:any = [];
   public brands:any = [];
   public brand = {
    id : 0,
    name : '',
    productTypeId : 0

   }

  constructor(private adminService:AdminService,private shopService:ShopService,private dialogModel: MatDialog) { }

  ngOnInit(): void {
     this.getBrands();
     this.getTypes();

  }

  public addBrand(){
     console.log(this.brand);
     if(this.brand.name.length > 3){
      this.shopService.addBrand(this.brand).subscribe((res)=> {
        console.log(res);
        this.brand.name = '';
        this.getBrands();
      });
     } else{
      alert('Please Enter Minimum Characters');
     }
    }

  public getBrands(){
     this.shopService.getBrands().subscribe((res:any) => {this.brands = res;})
  }

  public deleteBrand(id:any){
    // this.shopService.deleteBrand(id).subscribe((res) =>{
    //   console.log(res);
    //   this.getBrands();
    // })

  const dialogRef = this.dialogModel.open(DialogPopupComponent,{ data: { messageHead: "Delete Brand", messageBody: "Are you want sure Delete ?" }});
  dialogRef.afterClosed().subscribe(result => {
   if (!!result) {
         this.adminService.deleteBrand(id).subscribe((res) => {
          this.getBrands();
     })}
    });
  }

  public getTypes(){
    this.shopService.getTypes().subscribe((res)=>{
      this.types = res;
    })
  }

  public changeCategory(event:any){
    console.log(event.target.value);
    let typeId = event.target.value;
    this.brand.productTypeId = typeId;
 }
}
