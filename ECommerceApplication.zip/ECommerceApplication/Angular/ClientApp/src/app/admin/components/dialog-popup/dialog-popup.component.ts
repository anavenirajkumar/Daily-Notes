import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface DialogData {
  messageHead: string;
  messageBody: string;
 }
@Component({
  selector: 'app-dialog-popup',
  templateUrl: './dialog-popup.component.html',
  styleUrls: ['./dialog-popup.component.css']
})
export class DialogPopupComponent implements OnInit {

  public messageHead:string = '';
  public messageBody:string = '';
  constructor(public dialogRef: MatDialogRef<DialogPopupComponent>,@Inject(MAT_DIALOG_DATA) public data: DialogData) {}

  ngOnInit(): void {
  }

  public confirmDelete() {
    this.dialogRef.close(true);
  }

  public showMessage(messageHead:string, messageBody:string){
     this.messageHead = messageHead;
     this.messageBody = messageBody;
  }

}
