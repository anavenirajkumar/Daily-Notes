import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ShopService } from 'src/app/shop/services/shop.service';

@Component({
  selector: 'app-update-brand',
  templateUrl: './update-brand.component.html',
  styleUrls: ['./update-brand.component.css']
})
export class UpdateBrandComponent implements OnInit {

  public types:any = [];
  public brand:any = {
    id : 0,
    name : '',
    productTypeId : 0
   }
  public brandId:any;
  constructor(private router:ActivatedRoute, 
             private shopService:ShopService,
             private route: Router) { }

  ngOnInit(): void {
    this.getTypes();
    this.router.paramMap.subscribe((id)=> {
      this.brandId = id.get('id');
      this.getBrandById(this.brandId)
    })
  }

  public getTypes(){
    this.shopService.getTypes().subscribe((res)=>{
      this.types = res;
    })
  }
  public getBrandById(brandId:any){
    this.shopService.getBrand(brandId).subscribe((res:any) => {
      this.brand.id = res.id;
      this.brand.name = res.name;
      this.brand.productTypeId = res.productTypeId;
      console.log(res);
    })
  }
  public updateBrand(){
     this.shopService.updateBrand(this.brand).subscribe((res) => {
      console.log(res);
      this.route.navigateByUrl('/admin/brand');
     })
  }

  public changeCategory(event:any){
     console.log(event.target.value);
     let typeId = event.target.value;
     this.brand.productTypeId = typeId;
  }
}
