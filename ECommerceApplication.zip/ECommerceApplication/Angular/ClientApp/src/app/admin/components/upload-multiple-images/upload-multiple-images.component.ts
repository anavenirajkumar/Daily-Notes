import { Component, OnInit } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { UserService } from 'src/app/user/services/user.service';
import { AdminService } from '../../services/admin.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogPopupComponent } from '../dialog-popup/dialog-popup.component';

@Component({
  selector: 'app-upload-multiple-images',
  templateUrl: './upload-multiple-images.component.html',
  styleUrls: ['./upload-multiple-images.component.css']
})
export class UploadMultipleImagesComponent implements OnInit {

  public user:any = {
    name : '',
    email : '',
    mobileNumber : null,
    gender : "",
    married : false,
    dateOfJoining : '',
    city : '',
    country : '',
    userImages : [],
    selectedFroots : []
  }
  public selectedImages:any = [];
  public marriedStatus = [{id:1, name:'Married',checked: false}, {id:2, name : 'UnMarried', checked: false}];
  selectedIndex: number | any;
  public fruits:any = [
    { id: 1, name: 'Apple', checked: false },
    { id: 2, name: 'Banana', checked: false },
    { id: 3, name: 'Carrot', checked: false },
    { id: 4, name: 'Tomoto', checked: false },
    { id: 5, name: 'Orange', checked: false },
    { id: 6, name: 'Ice-Cream', checked: false },
    { id: 7, name: 'Mango', checked: false }
  ];
  public form: FormGroup | any;

  public users:any = [];
  public errorMessages:string[] = [];
  constructor(private userService:UserService, private adminService:AdminService,private dialogModel: MatDialog) { }

  ngOnInit(): void {
    this.form = new FormGroup({
      fruits: new FormArray([]),
    });
    this.getUsers();
  }

  selectedMarried(index:any, event:any) {
    this.selectedIndex = event.target.checked ? index : null;
    console.log(this.selectedIndex);
    if(this.selectedIndex === 0){
       this.user.married = true;
    } else if(this.selectedIndex === 1){
      this.user.married = false;
    } else{
      this.user.married = null;
    }
    console.log(this.user);
  }

    public profilePhotos(event:any){
       if(event.target.files.length > 0){
           for(let i = 0; i < event.target.files.length; i++){
               //this.user.userImages.push( {id : i, File : event.target.files[i]})
               const imageName = event.target.files[i].name;
               const updatedFile = new File([event.target.files[i]], imageName, { type: event.target.files[i].type });
               var reader = new FileReader();
                   reader.onload = (event:any) => {
                   console.log(event.target.result);
                   this.selectedImages.push({ id : i, image : event.target.result }); 
                   this.user.userImages.push({ imageId : i, imageFile: updatedFile, imageName : imageName, type : updatedFile.type}); 
              }
                  reader.readAsDataURL(event.target.files[i]);
           }
       }
       console.log(this.user.userImages);

    }

    public SelectedProfileImage(image:any){
        let imageId = image.id;
        let imageIndex = this.selectedImages.findIndex((ele:any) => ele.id === imageId);
        let userimageIndex = this.user.userImages.findIndex((ele:any) => ele.id === imageId);
        this.selectedImages.splice(imageIndex,1);
        this.user.userImages.splice(userimageIndex,1);
        console.log(this.user.userImages);
    }

    public submitUserDetails(){
      console.log(this.user);
      console.log(this.errorMessages);
      this.errorMessages = [];
      const valid = this.verifyForm();
      if(valid){
        let formData = this.createForm();
        this.userService.addNewUser(formData).subscribe((res) => {
        console.log(res);
        this.user = {};
        this.user.selectedFroots = [];
        this.user.userImages = [];
        this.user.married = false;
        this.getUsers();
      }, err => {
        console.log(err);
      })
      }
    }

    selectedFroot(obj:any,event:any){
      this.user.selectedFroots = this.fruits;
      if(event.target.checked && obj.checked === true){
         this.user.selectedFroots.forEach((ele:any) => {
            if(ele.name === obj.name){
               ele.checked = true;
            }
         })
      }
      else{
        obj.checked = false;
      }
       console.log(this.user.selectedFroots);
   }

   public createForm() :FormData{
    const formData = new FormData();
    //formData.append('id', this.user.id);
    formData.append('name', this.user.name);
    formData.append('email',this.user.email);
    formData.append('mobileNumber', this.user.mobileNumber);
    formData.append('gender',this.user.gender);
    formData.append('married',this.user.married);
    formData.append('dateOfJoining',this.user.dateOfJoining);
    formData.append('city',this.user.city);
    formData.append('country',this.user.country);
    if (this.user.userImages != null) {
      this.user.userImages.forEach((x:any, i:any) => {
          formData.append(`userImages[${i}][imageId]`, i);
          formData.append(`userImages[${i}][imageName]`, x.imageName);
          formData.append(`images`, x.imageFile);
          formData.append(`userImages[${i}][imageType]`, x.type);
      });
  }

  if (this.user.selectedFroots != null) {
    this.user.selectedFroots.forEach((x:any, i:any) => {
        formData.append(`selectedFroots[${i}][id]`, x.id);
        formData.append(`selectedFroots[${i}][name]`, x.name);
        formData.append(`selectedFroots[${i}][checked]`, x.checked);
        formData.append(`selectedFroots[${i}][userId]`, i);
    });
}
  return formData;
  }

  public getUsers(){
    this.userService.GetNewUsers().subscribe((res) => {
      this.users = res;
    }, err => {
      console.log(err);
    });
  }


  public deleteUser(userId:any){
    //  this.userService.deleteNewUserById(userId).subscribe((res) => {
    //   console.log(res);
    //   this.getUsers();
    //  }, err => {
    //  })

    const dialogRef = this.dialogModel.open(DialogPopupComponent,{ data: { messageHead: "Delete User", messageBody: "Are you want sure Delete ?" }});
    dialogRef.afterClosed().subscribe(result => {
     if (!!result) {
           this.userService.deleteNewUserById(userId).subscribe((res) => {
            this.getUsers();
       })}
      });
  }

  public verifyForm(): boolean {
    let formsValid = true;
    if (this.user.name == "" && this.user.name < 3) {
        formsValid = false;
        this.errorMessages.push("Please Enter Name");
    }
    if(this.user.email == "" && this.user.email.length < 9){
      formsValid = false;
      this.errorMessages.push("Email");
    }
    if(this.user.mobileNumber === null){
      formsValid = false;
      this.errorMessages.push("Please Enter Mobile Number");
    }
     if (this.user.gender == "") {
        formsValid = false;
        this.errorMessages.push("Please Select Gender");
    }
    if(this.user.married == null){
      formsValid = false;
      this.errorMessages.push("Please Select Married");
    }
    if(this.user.dateOfJoining == ""){
      formsValid = false;
      this.errorMessages.push("Please Select DOJ");
    }
    if(this.user.city == ""){
      formsValid = false;
      this.errorMessages.push("Please Enter City");
    }
    if(this.user.country == ""){
      formsValid = false;
      this.errorMessages.push("Please Enter Country");
    }
    if(this.user.userImages.length === 0){
      formsValid = false;
      this.errorMessages.push("Please Upload Images");
    }
    if(this.user.selectedFroots.length === 0){
      formsValid = false;
      this.errorMessages.push("Please Select Froots");
    }
   return formsValid;
  }
}
