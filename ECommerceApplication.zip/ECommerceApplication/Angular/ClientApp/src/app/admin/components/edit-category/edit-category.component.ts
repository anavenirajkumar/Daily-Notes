import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../../services/admin.service';

@Component({
  selector: 'app-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.css']
})
export class EditCategoryComponent implements OnInit {

  public category:any = {
    id : 0,
    name : ''
   }
  public categoryId:any;
  public errorMessage:string= '';
  constructor(private router:ActivatedRoute, 
             private shopService:AdminService,
             private route: Router) { }

  ngOnInit(): void {
    this.router.paramMap.subscribe((id)=> {
      this.categoryId = id.get('id');
      this.getCategoryById(this.categoryId)
    })
  }

  public getCategoryById(categoryId:any){
    this.shopService.getCategory(categoryId).subscribe((res) => {
      this.category = res;
      console.log(res);
    })
  }
  public updateCategory(){
     if(this.category.name){
      this.shopService.updateCategory(this.category).subscribe((res) => {
        this.route.navigateByUrl('/admin/category');
       })
     } else{
        this.errorMessage = 'Please Enter Category Name';
     }
  }
}
