import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { ShopService } from 'src/app/shop/services/shop.service';

@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrls: ['./update-product.component.css']
})
export class UpdateProductComponent implements OnInit {
  public brands:any = [];
  public types:any = [];
  public productId:any;
  public product:any;
  constructor( private shopService:ShopService,
               private captureId : ActivatedRoute,
               private router : Router
             ) { }

  ngOnInit(): void {
    this.captureId.paramMap.subscribe((res)=> {
      this.productId = res.get('id');
      if(this.productId){
         this.shopService.getProduct(this.productId).subscribe((res:any)=>{
          this.product = res;
         })
      }
    })
    this.getTypes();
    this.getBrands();
  }
  public getTypes(){
    this.shopService.getTypes().subscribe((res)=> {
      this.types = res;
    })
  }
  public getBrands(){
    this.shopService.getBrands().subscribe((res)=> {
      this.brands = res;
    })
  }

  public updateProduct(){
    let price:number = +this.product.price;
    // let brandId:number = +this.product.productBrandId;
    // let typeId:number = +this.product.price;

    this.product.price = price;
    console.log(this.product);
    if(this.product.name != "" && this.product.description != "" && this.product.price != 0 && this.product.pictureUrl != "" && this.product.productTypeId != 0 && this.product.productBrandId !=0){
       this.shopService.updateProduct(this.product).subscribe((res)=> {
        console.log(res);
        this.router.navigateByUrl("/admin/product");
       })
    }
   
  }
  public uploadImage(event:any){
    if (event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              reader.onload = (event:any) => {
                console.log(event.target.result);
                this.product.pictureUrl = event.target.result;
              }
              reader.readAsDataURL(event.target.files[i]);
      }
    }
  }
  public removeImage(){
    this.product.pictureUrl = '';
  }

  public changeCategory(event:any){
    console.log(event.target.value);
    this.product.productTypeId = event.target.value;
  }

  public changeBrand(event:any){
    console.log(event.target.value);
    this.product.productBrandId = event.target.value;
  }
}
