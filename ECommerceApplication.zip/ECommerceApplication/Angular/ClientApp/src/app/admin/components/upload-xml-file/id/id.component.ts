import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/user/services/user.service';

@Component({
  selector: 'app-id',
  templateUrl: './id.component.html',
  styleUrls: ['./id.component.css']
})
export class IdComponent implements OnInit {

  public recordId:any;
  public user:any = {
    userID : 0,
    userName :  '',
    emailID : '',
    mobileNumber : '',
    age : 0,
    salary : 0,
    gender : ''
}
  constructor(private snapshot:ActivatedRoute,
    private adminService:UserService,
    private router:Router) { }

  ngOnInit(): void {
    this.snapshot.paramMap.subscribe((id)=> {
      this.recordId = id.get('id');
      console.log(typeof(this.recordId));
    });
    let productId:number = +this.recordId;
    this.adminService.getId(productId).subscribe((data)=> {
      this.user = data;
      console.log(this.user);
    })
  }

  public updateRecord(){
    console.log(this.user);
    let ID:number = +this.recordId;
    let age:number = +this.user.age;
    let salary:number = +this.user.salary;

    let userRecord = {
      userID : ID,
      userName :  this.user.userName,
      emailId : this.user.emailID,
      mobileNumber : this.user.mobileNumber,
      age : age,
      salary : salary,
      gender : this.user.gender
    }
    console.log(userRecord);

    if(this.user.userID != 0 && this.user.userName !='' && this.user.emailId != '' && this.user.gender != ''&& this.user.mobileNumber != '' && this.user.age != 0 && this.user.salary != 0){
        this.adminService.updateRecord(userRecord).subscribe((data)=>{
          console.log(data);
           this.router.navigate(['/admin']);
        })
    }
  }

}
