export enum Roles {
   Admin = 'Admin',
   User = 'User',
   Owner = 'Owner'
}