import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { map, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ShopParams } from '../models/shopParams';
import { IPagination } from '../models/pagination';
import { IBrand } from '../models/brand';
import { IType } from '../models/productType';
import { IProduct } from '../models/product';


@Injectable({
  providedIn: 'root'
})
export class ShopService {

  baseUrl = environment.apiUrl;

 // productCache = new Map();

  constructor(private http : HttpClient) { }

  // getProducts(brandId?: number, typeId?:number, sort?:string){ example 1

  onlyProducts(){
    return this.http.get(this.baseUrl + 'Products');
  }
  getProducts(shopParams : ShopParams){  // api/Products/GetProductsWithPage

    //let params = new HttpParams();

    // if(shopParams.brandId !== 0){ // brandId
    //   params = params.append('brandId', shopParams.brandId.toString()); // https://localhost:44358/api/products?brandId=1
    // }

    // if(shopParams.typeId !== 0){
    //   params = params.append('typeId', shopParams.typeId.toString());
    // }

    // if(shopParams.sort){
    //   params = params.append('sort', shopParams.sort);
    // }

    // if(shopParams.search){
    //   params = params.append('search', shopParams.search);
    // }
    // params = params.append('sortBy', 'asc');
    // params = params.append('pageIndex', shopParams.pageNumber);
    // params = params.append('pageIndex', shopParams.numberOfRecordPerPage);

    // let obj = {
    //   sortBy : shopParams.sortBy,
    //   pageNumber : shopParams.pageNumber,
    //   numberOfRecordPerPage : shopParams.numberOfRecordPerPage
    // }

    // return this.http.post<IPagination>(this.baseUrl + 'Products/GetProductsWithPage', {observe: 'response', params})  // response
    // .pipe(
    //   map(response => {
    //     return response;
    //   })
    // );

    // params = params.append('sortBy', shopParams.sortBy);
    // params = params.append('pageIndex', shopParams.pageNumber);
    // params = params.append('pageIndex', shopParams.numberOfRecordPerPage);


let obj;
    if(shopParams.search){
      obj = {
        searchName : shopParams.search,
        sortBy : 'asc',
        pageNumber : shopParams.pageNumber,
        numberOfRecordPerPage : shopParams.numberOfRecordPerPage
      }
      console.log(obj);
    }
    else if(shopParams.brandId > 0){
      obj = {
        brandId : shopParams.brandId,
        searchName : "",
        sortBy : 'asc',
        pageNumber : shopParams.pageNumber,
        numberOfRecordPerPage : shopParams.numberOfRecordPerPage
      }
    }
    else if(shopParams.typeId > 0){
      obj = {
        typeId : shopParams.typeId,
        searchName : "",
        sortBy : 'asc',
        pageNumber : shopParams.pageNumber,
        numberOfRecordPerPage : shopParams.numberOfRecordPerPage
      }
    } 
    else if(shopParams.brandId == 0 && shopParams.typeId == 0 && !shopParams.search && shopParams.sort){
      obj = {
        searchName : "",
        sortBy : shopParams.sort === "asc" ? "asc" : "desc",
        pageNumber : shopParams.pageNumber,
        numberOfRecordPerPage : shopParams.numberOfRecordPerPage
      }
    }
   else{
    obj = {
      searchName : "",
      sortBy : 'asc',
      pageNumber : shopParams.pageNumber,
      numberOfRecordPerPage : shopParams.numberOfRecordPerPage
    }
    console.log(obj);
   }
    return this.http.post<IPagination>(this.baseUrl + 'Products/GetProductsWithPage', obj).pipe(
        map(response => {
          return response;
        })
      );
  }

  public getProductWithQueryParams(obj:any){
    var url = `${this.baseUrl}Products/GetProductsWithPage`;
    var params = '';
    if (obj.search) {
        params += `SearchName=${obj.search}`;
    }
    if(obj.sort){
      obj.sortBy = obj.sort;
      params += (params != '' ? '&' : '') + `PageNumber=${obj.pageNumber}&NumberOfRecordPerPage=${obj.numberOfRecordPerPage}&SortBy=${obj.sortBy}`;
    }
    if (obj.brandId > 0) {
        params += (params != '' ? '&' : '') + `BrandId=${obj.brandId}`;
    }
    if (obj.typeId > 0) {
        params += (params != '' ? '&' : '') + `TypeId=${obj.typeId}`;
    }
    if (params) {
        url += '?' + params;
    }
    return this.http.get(url);
  }

  getBrands(){
   return this.http.get<IBrand>(this.baseUrl + 'Products/GetBrands');
  }

  getTypes(){
   return this.http.get<IType>(this.baseUrl + 'Products/GetCategories');
  }

  // example 1
  // getProduct(id: number | any) {
  //   let product: IProduct | any;
  //   this.productCache.forEach((products: IProduct[] | any) => {
  //     console.log(product);
  //     product = products.find((p:any) => p.id === id);
  //   })

  //   if (product) {
  //     return of(product);
  //   }

  //   return this.http.get<IProduct>(this.baseUrl + 'products/' + id);
  // }


  addBrand(brand:any){
    return this.http.post(this.baseUrl + 'Products/AddBrand', brand);
  }
  getBrand(getId:any){
    return this.http.get(this.baseUrl + 'Products/brand/' + getId)
  }

  updateBrand(brand:any){
   return this.http.put(this.baseUrl + 'Products/UpdateBrand', brand);
  }

  deleteBrand(id:any){
    return this.http.delete(this.baseUrl + 'Products/DeleteBrand/' + id);
  }

  getType(getId:any){
    return this.http.get(this.baseUrl + 'Products/type/' + getId)
  }

  getProduct(getId:any){
    return this.http.get<IProduct>(this.baseUrl + 'Products/GetProduct/' + getId)
  }

  addType(type:any){
    return this.http.post(this.baseUrl + 'Products/AddType', type);
  }
  deleteType(id:any){
    return this.http.delete(this.baseUrl + 'Products/DeleteType/' + id);
  }
  updateType(type:any){
    return this.http.put(this.baseUrl + 'Products/UpdateType', type);
   }
  
   addProduct(product:any){
    return this.http.post(this.baseUrl + 'Products/AddProduct', product);
  }

  updateProduct(product:any){
    return this.http.put(this.baseUrl + 'Products/UpdateProduct', product);
   }

   deleteProduct(id:any){
    return this.http.delete(this.baseUrl + 'Products/DeleteProduct/' + id);
  }
}
