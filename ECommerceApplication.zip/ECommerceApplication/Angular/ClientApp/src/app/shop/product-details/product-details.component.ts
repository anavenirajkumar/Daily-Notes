import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ShopService } from '../services/shop.service';
import { IProduct } from '../models/product';
import { UserService } from 'src/app/user/services/user.service';



@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  // example 1
  // product:any;
  // quantity = 1;

  // example 2
  public productId:any;
  public product:any;

  constructor(
    private shopService: ShopService, 
    private activatedRoute: ActivatedRoute,
    protected userService:UserService
   ) {}

   public quantity = 1;

  ngOnInit(): void {
     // example 1
    // this.shopService.getProduct(this.activatedRoute.snapshot.paramMap.get('id')).subscribe((product:any) => {
    //   this.product = product;
    // }, error => {
    //   console.log(error);
    // })

    this.activatedRoute.paramMap.subscribe((id)=> {
      this.productId = id.get('id');
      console.log(this.productId);
    });
    this.shopService.getProduct(this.productId).subscribe((data)=> {
      this.product = data;
    })

  }

  addToCart(product:any) {
      //this.userService.currentUser.cart.push(product);
      this.userService.placeOrder(this.userService.currentUser);
    }

  incrementQuantity() {
    this.quantity++;
  }

  decrementQuantity() {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }
}
