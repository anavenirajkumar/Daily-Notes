export class ShopParams { // why ShopParams? beacause query params reached limit, in service(sort?, brand?, type?, )
    brandId = 0;
    typeId = 0;
    sort = 'asc';
    pageSize = 6;
    search: string | any;
    pageNumber = 1;
    numberOfRecordPerPage = 6;
    sortBy : string | any; // or desc
}