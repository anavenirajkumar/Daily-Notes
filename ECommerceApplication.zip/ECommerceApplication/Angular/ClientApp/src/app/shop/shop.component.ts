import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { IBrand } from './models/brand';
import { IType } from './models/productType';
import { ShopParams } from './models/shopParams';
import { ShopService } from './services/shop.service';
import { IProduct } from './models/product';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  public products:IProduct[] | any = [];
  public totalCount: number | any;
  public brands : IBrand[] | any;
  public types : IType[] | any;

  // selected brands or types
  public brandIdSelected: number = 0;
  public typeIdSelected:number = 0;

  // use this class for All Filters
  public shopParams = new ShopParams();

  // sorting functionality
  public sortOptions = [
    {name : 'Alphabetical', value : 'asc'},
    {name : 'Price : Low to High', value : 'asc'},
    {name : 'Price : High to Low', value : 'desc'}
  ];

   // for Access Input Values
  @ViewChild('search', {static:true}) searchTerm: ElementRef | any;

  constructor(private shopService : ShopService) { }

  ngOnInit(): void {
    this.getProducts();
    this.getBrands();
    this.getTypes();
    // using query params
    //this.getProductsWithQueryParams();
  }

  public getProducts(){
    this.shopService.getProducts(this.shopParams).subscribe((response:any) => {  // mention "any"
      this.products = response.data; // list products in data array
      this.shopParams.pageNumber = response.currentPage; // "1"
      this.totalCount = response.totalRecords;
      console.log(this.shopParams);
      console.log(response);
    }, error => {
      console.log(error);
    })
  }

  getBrands(){
    this.shopService.getBrands().subscribe((response:any) => {
      this.brands = [{id : 0, name : 'All'}, ...response] // im created one Object for Showing "All" Text and Adding remaining objects
    }, error => {
      console.log(error);
    });
  }

  getTypes(){
   this.shopService.getTypes().subscribe((response:any) => {
    this.types = response;
   }, error => {
    console.log(error);
   })
  }

  onBrandIdSelected(brandId:any){
    console.log(brandId);
     this.shopParams.brandId = brandId;
     this.shopParams.pageNumber = 1; // if brands selected index page is 1
     this.shopParams.typeId = 0;
     this.getProducts();
  }

  onTypeIdSelected(typeId:any){
    console.log(typeId);
    this.shopParams.typeId = typeId;
    this.shopParams.brandId = 0;
    this.shopParams.pageNumber = 1;   // if types selected index page is 1
    this.getProducts();
  }

  onSortSelected(event:any){
    console.log(event.target.value);
    let sort = event.target.value;
    this.shopParams.sort = sort;
    this.getProducts();
  }

  // page Changed
  onPageChanged(event:any){
    console.log(event);
    // this.shopParams.pageNumber = event.page;
    this.shopParams.pageNumber = event;
    this.getProducts();
  }

  onSearch(){
    console.log(this.searchTerm.nativeElement.value);
    this.shopParams.search = this.searchTerm.nativeElement.value;
    this.shopParams.pageNumber = 1;   // if searching index page is 1
    this.getProducts();
  }

  onReset(){
    this.searchTerm.nativeElement.value = '';
    this.shopParams = new ShopParams();
    this.getProducts();
  }

  public getProductsWithQueryParams(){
    this.shopService.getProductWithQueryParams(this.shopParams).subscribe((response:any) => {  // mention "any"
      this.products = response.data; // list products in data array
      this.shopParams.pageNumber = response.currentPage; // "1"
      this.totalCount = response.totalRecords;
      console.log(this.shopParams);
      console.log(response);
    }, error => {
      console.log(error);
    })
  }
}

