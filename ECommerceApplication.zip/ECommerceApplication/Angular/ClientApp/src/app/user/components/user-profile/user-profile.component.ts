import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  public userInfo  = this.userService.currentUser;
  public enableAddress : boolean = false;

  constructor(private router : Router, private userService : UserService) { }

  ngOnInit() {
 
  }


  submitUpdateAddress(){
       this.userService.updateUserAddress(this.userInfo).subscribe((response: any) => {
         this.enableAddress = false;
      })
    }

    public logout(){
      localStorage.removeItem('token');
      localStorage.removeItem('userDetails');
    }
    
  }


  

  
