import { Component, OnInit } from '@angular/core';
import { IRegister } from '../../models/IRegister';
import { UserService } from '../../services/user.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public hide:boolean = true;
  public register:IRegister = {
    username : '',
    email : '',
    password : '',
    confirmpassword : '',
    role : ''
  }
  public errorMessage:string[] = [];

  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }

  public registerUser(){
    this.errorMessage.length = 0;
    if(this.validate()){
        this.userService.register(this.register).subscribe((res) => {
          console.log(res);
        })
    }
}

private validate():boolean{
  let validEmail = this.register.email.endsWith("@gmail.com");
  if(this.register.username == ''){
    this.errorMessage.push('Please Enter Username');
   }
   if(this.register.email == ''){
      this.errorMessage.push('Please Enter Email Address');
   }
   else if(!validEmail){
      this.errorMessage.push('Please Enter Proper Email Address');
   }
   if(this.register.password == ''){
      this.errorMessage.push('Please Enter Password');
   } 
   else if(this.register.password.length < 8){
      this.errorMessage.push('Please Enter Password Minimum 8 Characters');
   }

   if(this.register.confirmpassword == ''){
    this.errorMessage.push('Please Enter ConfirmPassword');
   } else if(this.register.confirmpassword != this.register.password){
    this.errorMessage.push(`Confirm Password doesn't matched`);
   }
  return this.errorMessage.length === 0;
 }
}
