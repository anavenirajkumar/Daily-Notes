export interface IRegister{
    username : string;
    email : string;
    password: string;
    confirmpassword : string;
    role : string;
  }