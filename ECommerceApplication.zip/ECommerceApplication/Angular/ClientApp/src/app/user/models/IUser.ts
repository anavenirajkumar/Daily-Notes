export interface IUser{
    email :string;
    password:string;
}
export interface ILoginUser {
    userID: string,
    userName: string,
    email : string,
    role: string,
    roles:[],
    isSuccess : boolean,
    password : string,
    token : string,
    message : string,
    village : string,
    mandal : string,
    district : string,
    lastLogin : Date,
    cart : [],
    mobileNumber:string
}