import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry} from "rxjs/operators";
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { IRegister } from '../models/IRegister';
import { ILoginUser, IUser } from '../models/IUser';
import { Roles } from 'src/app/roles/roles';

@Injectable({
  providedIn: 'root'
})
export class UserService {

   private readonly ApiUrl = environment.apiUrl; 
   public currentUser:ILoginUser = {
     userID: '',
     userName: '',
     email: '',
     role: '',
     isSuccess: true,
     password: '',
     token: '',
     message: '',
     village: '',
     mandal: '',
     district: '',
     mobileNumber:'',
     lastLogin: new Date,
     cart: [],
     roles:[]
   }
  constructor(private httpClient : HttpClient, private router : Router) { }

  public register(registerDetails:IRegister): Observable<IRegister>{
    return this.httpClient.post<IRegister>(this.ApiUrl + 'User/RegisterUser', registerDetails)
  }

 public login(user:any) : Observable<IUser> { 
     return this.httpClient.post(this.ApiUrl + 'User/LoginUser', user).pipe(
      map((response: any) => {
        const user = response;
        this.currentUser.token = user.token;
        this.currentUser.userID = user.userID;
        this.currentUser.userName = user.userName;
        this.currentUser.email = user.email;
        this.currentUser.password = user.password;
        this.currentUser.role = user.role;
        this.currentUser.district = user.district;
        this.currentUser.mandal = user.mandal;
        this.currentUser.message = user.message;
        this.currentUser.village = user.village;
        this.currentUser.isSuccess = user.isSuccess;
        this.currentUser.lastLogin = user.lastLogin;

        if(this.currentUser.userID !== null){
          localStorage.setItem('token', response.token);
          localStorage.setItem('userDetails',JSON.stringify(response));
        }
        return this.currentUser;
      }
      ),catchError(this.errorHandler)
     )
     
  }
  
  public getRefreshUser(){
      let user =  JSON.parse(localStorage.getItem('userDetails') || '{}');
      const promise = new Promise((resolve, reject) => {
      this.httpClient.get(this.ApiUrl + `User/GetRefreshUser/${user.email}/${user.userID}`).subscribe(
          (res) => {
              resolve(res);
          },
          (rej) => {
              this.errorHandler(rej);
              reject(rej);
      });
  });
  return promise;

    // return this.httpClient.get<ILoginUser>(this.ApiUrl + `User/GetRefreshUser/${user.email}/${user.userID}`).pipe(
    //   map((response: any) => {
    //     const user = response;
    //     this.currentUser.token = user.token;
    //     this.currentUser.userID = user.userID;
    //     this.currentUser.userName = user.userName;
    //     this.currentUser.email = user.email;
    //     this.currentUser.password = user.password;
    //     this.currentUser.role = user.role;
    //     this.currentUser.district = user.district;
    //     this.currentUser.mandal = user.mandal;
    //     this.currentUser.message = user.message;
    //     this.currentUser.village = user.village;
    //     this.currentUser.isSuccess = user.isSuccess;
    //     this.currentUser.lastLogin = user.lastLogin;
    //     return this.currentUser;
    //   }
    //   )
    //  )
  }
  
  public getLoggedInUser( userId:any){ 
    return this.httpClient.get(this.ApiUrl + `User/GetLoggedUser/${userId}`) 
  }

  public updateUserAddress(address:any){
     return this.httpClient.post(this.ApiUrl + 'User/Address', address);
  }

  public AddUsers(users:any){
     return this.httpClient.post(this.ApiUrl + 'User/Admin/Add', users);
  }

  public getAllUsers(){
    return this.httpClient.get(this.ApiUrl + 'User/Admin/Get');
  }

  public getAllCountries(){
    return this.httpClient.get(this.ApiUrl + 'Country/Countries')
  }

  public getStates( id:any){ ///GetStates?CountryID=1
    return this.httpClient.get(this.ApiUrl + `Country/States/${id}?CountryID=`+ id) 
  }

  public getCities( id:any){ ///GetCities?StateID=1
    return this.httpClient.get(this.ApiUrl + `Country/Cities?StateID=`+ id) 
  }

  public getMandal( id:any){ ///GetMandal?CityID=1
    return this.httpClient.get(this.ApiUrl + `Country/Mandals?CityID=`+ id) 
  }

  public getVillages( id:any){ ///GetVillages?VillageID=1
    return this.httpClient.get(this.ApiUrl + `Country/Villages?VillageID=`+ id) 
  }
  

  public addCountry(country:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddCountry', country);
  }

  public addState(state:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddState', state);
  }

 public addCity(city:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddCity', city);
  }

  public addMandal(mandal:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddMandal', mandal);
  }

  public addVillage(village:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddVillage', village);
  }

  public AdminUser() : string{
     return this.currentUser.role; 
  }

   public isLoggedIn(){
     if(localStorage.getItem('token')){
       return true;
     } else {
       return false;
     }
  }

  public getToken(){
     if(localStorage.getItem('token')){
       return localStorage.getItem('token');
     }
     else {
       return "";
     }
  }

  public userInfomation() {
     return JSON.parse(localStorage.getItem('userDetails') || '{}');
  }
  

  public errorHandler(error: HttpErrorResponse) { // if Any Error
      //localStorage.clear(); // Remove Total Local Storage
       localStorage.removeItem('token');
       localStorage.removeItem('userDetails');
       this.router.navigate(['/'])
    return throwError(error.message || "server error.");
}


  // public handleError(error:HttpErrorResponse){
  //   let errorMessage:string = '';
  //   if(error.error instanceof ErrorEvent){
  //     // client Error
  //     errorMessage = `Error : ${error.error.message}`
  //     console.log("Removed Local Storage");
  //     localStorage.clear();
  //   }
  //   else{
  //     // server error
  //     errorMessage = `Status : ${error.status} \n Message: ${error.message}`;
  //   }
  //   return throwError(errorMessage);
  // }
 
  // public createCategory(category:ICategory):Observable<ICategory>{
  //   return this.httpClient.post<ICategory>(this.ApiUrl + 'Category/AddCategory', category);
  // }

  // public createSubCategory(subcategory:ISubCategory):Observable<ISubCategory>{
  //   return this.httpClient.post<ISubCategory>(this.ApiUrl + 'Category/AddSubCategory', subcategory);
  // }

  // public createProduct(product:IProduct){
  //   return this.httpClient.post<IProduct>(this.ApiUrl + 'Category/AddProduct', product);
  // }

  public getCategories(){
    return this.httpClient.get(this.ApiUrl + 'Category/GetCategories');
  }

  public getSubCategories(){
    return this.httpClient.get(this.ApiUrl + 'Category/GetSubCategories');
  }

  public getProducts(){
    return this.httpClient.get(this.ApiUrl + 'Category/GetProducts');
  }

  public changeCategory(categoryId:any){ 
    return this.httpClient.get(this.ApiUrl + 'Country/GetSubCategories?categoryid=' + categoryId);
  }

  public getProduct(productId:any){
    return this.httpClient.get(this.ApiUrl + `Category/GetProduct/${productId}?productId=` + productId);
}

public updateProduct(product:any){
  return this.httpClient.put(this.ApiUrl + 'Category/UpdateProduct', product);
}

public deleteProduct(productId:any){
  return this.httpClient.delete(this.ApiUrl + 'Category/DeleteProduct?productId=' + productId)
}

public deleteCategory(categoryId:any){
  return this.httpClient.delete(this.ApiUrl + 'Category/DeleteCategory?categoryId=' + categoryId)
}

public deleteSubCategory(subcategoryId:any){
  return this.httpClient.delete(this.ApiUrl + 'Category/DeleteSubCategory?subcategoryId=' + subcategoryId)
}

public upload(file:any){
  return this.httpClient.post(this.ApiUrl + 'UploadFile/UploadExcelFile', file);
}

public getData(){
  return this.httpClient.get(this.ApiUrl + 'UploadFile/ReadRecords');
}

public deleteRecord(userId:any){
  return this.httpClient.delete(this.ApiUrl + 'UploadFile/DeleteRecord?recordId=' + userId );
}

public getById(userId:any){
  return this.httpClient.delete(this.ApiUrl + 'UploadFile/GetByIdRecord?id=' + userId );
}

public getId(userId:any){
  return this.httpClient.get(this.ApiUrl + 'UploadFile/GetByIdRecord/' + userId );
}

public updateRecord(user:any){
  return this.httpClient.put(this.ApiUrl + 'UploadFile/UpdateRecord', user);
}

public uploadUser(user:any){
  return this.httpClient.post(this.ApiUrl + 'User/Admin/AddUser', user);
}

public getUsers(){
  return this.httpClient.get(this.ApiUrl + 'User/Admin/GetUsers');
}

public getUserId(id:number){
  return this.httpClient.get(this.ApiUrl + 'User/Admin/GetUser?id=' + id); 
}

public deleteUser(id:any){
  return this.httpClient.delete(this.ApiUrl + 'User/Admin/DeleteUser?id='+ id); //DeleteUser?id=1
} 


public deleteSpecificImage(id:any){
  return this.httpClient.delete(this.ApiUrl + 'User/Admin/DeleteImage?id='+ id); // DeleteImage?id=33
} 

public addNewUser(user:any){
  return this.httpClient.post(this.ApiUrl + 'User/Admin/AddNewUser', user);
}

public updateNewUser(user:any){
  return this.httpClient.post(this.ApiUrl + 'User/Admin/AddNewUser', user);
}
// Admin/GetNewUsers
public GetNewUsers(){
  return this.httpClient.get(this.ApiUrl + 'User/Admin/GetNewUsers');
}
// Admin/GetNewUserById/11
public GetNewUserById(UserId:any){
  return this.httpClient.get(this.ApiUrl + `User/Admin/GetNewUserById/${UserId}`);
}

public deleteNewUserById(UserId:any){
  return this.httpClient.delete(this.ApiUrl + `User/Admin/DeleteNewUser/${UserId}`)
}

public deleteUserImage(id:any){
  return this.httpClient.delete(this.ApiUrl + 'User/Admin/DeleteUserImage?id='+ id);
} 

public UpdateUserImages(images:any){
  return this.httpClient.post(this.ApiUrl + 'User/Admin/UserImages', images);
} 

public placeOrder(user:any){
  return this.httpClient.post(this.ApiUrl + 'User/Product/PlaceOrder', user);
}

public hasAnyRole = (role: any): boolean => {
  const authRoles:any = this.currentUser.roles;
  const routeRoles:any = role.roles;
  console.log(routeRoles);
  return (authRoles || false) && routeRoles.some((r:any) => authRoles.indexOf(r) > -1);
}

}
