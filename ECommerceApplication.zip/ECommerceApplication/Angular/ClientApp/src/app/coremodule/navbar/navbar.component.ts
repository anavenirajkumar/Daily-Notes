import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/user/services/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private userService : UserService, private router:Router) { }

  ngOnInit(): void {
    if(localStorage.getItem('token') === ""){
      location.reload();
    }
  }

  public isLoggedIn(){
    return this.userService.isLoggedIn();
  }

  public userInformation(){
    return this.userService.userInfomation();
  }

  public admin(){
    return this.userService.AdminUser();
  }

  public logout(){
    localStorage.removeItem('token');
    localStorage.removeItem('userDetails');
    this.userService.currentUser.district = "";
    this.userService.currentUser.email= "";
    this.userService.currentUser.isSuccess = false;
    this.userService.currentUser.lastLogin = new Date;
    this.userService.currentUser.mandal = "";
    this.userService.currentUser.message = "";
    this.userService.currentUser.password = "";
    this.userService.currentUser.role = "";
    this.userService.currentUser.token = "";
    this.userService.currentUser.userID = "";
    this.userService.currentUser.userName = "";
    this.userService.currentUser.village = "";
    this.router.navigateByUrl('/user/login');
  }

}
