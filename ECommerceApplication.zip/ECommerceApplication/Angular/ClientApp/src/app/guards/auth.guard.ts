import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Data, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, map } from 'rxjs';
import { UserService } from '../user/services/user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private userService: UserService,private router :Router){}

  // Example 1
  // canActivate(
  //   route: ActivatedRouteSnapshot,
  //   state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
  //     return new Observable<boolean>(obs => {
  //       this.userService.getRefreshUser().then(
  //         (result:any) => {
  //           this.userService.currentUser = result;
  //           if (result.role === "User" || "Admin") {
  //               obs.next(true);
  //           }
  //           else {
  //               obs.next(false);
  //           }
  //       }
  //     ).catch((err) => {
  //       this.router.navigate(['/user/login']);
  //     })
  // })
  // }  

  // Example 2
 
canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      return new Observable<boolean>(obs => {
        this.userService.getRefreshUser().then(
          (result:any) => {
            this.userService.currentUser = result;
            let authorized = false;
            const roles:any = route.data;
            authorized = typeof roles === 'object' ? this.userService.hasAnyRole(roles) : false;
           if (authorized) {
                obs.next(true);
              } else{
                obs.next(false);
            }
        }
      )
  })
  } 
} 



