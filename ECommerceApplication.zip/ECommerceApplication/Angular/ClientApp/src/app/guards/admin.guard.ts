import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../user/services/user.service';

@Injectable({
  providedIn: 'root'
})
export class AdminGuard implements CanActivate {
  constructor(private userService : UserService,
        private router : Router){}
  // canActivate(
  //   route: ActivatedRouteSnapshot,
  //   state: RouterStateSnapshot): boolean {
  //    let Admin = this.userService.AdminUser();
  //    if(Admin === 'Admin'){
  //      return true;
  //    } else {
  //      this.router.navigate(['/']);
  //      return false;
      
  //    }
  // }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return new Observable<boolean>(obs => {
      this.userService.getRefreshUser().then(
        (result:any) => {
          if (result.role === "Admin") {
              //this.router.navigateByUrl('/admin');
              obs.next(true);
          }
          else {
              obs.next(false);
          }
      }
    )
})
}
}
