﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Models
{
    public class Employee 
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Designation { get; set; }
        public int CompanyId { get; set; } // Foreign Key
        public virtual Company Company { get; set; } // use for get Employees with Companies
    }
}
