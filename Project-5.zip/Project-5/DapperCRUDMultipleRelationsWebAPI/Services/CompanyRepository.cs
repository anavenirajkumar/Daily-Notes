﻿using Dapper;
using DapperCRUDWebApi2.Interfaces;
using DapperCRUDWebApi2.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Services
{
    public class CompanyRepository : ICompanyRepository
    {
        private IDbConnection db;

        public CompanyRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }

        public Company AddCompany(Company company)
        {
            var sql = "INSERT INTO Companies (CompanyName) VALUES(@CompanyName);"
                        + "SELECT CAST(SCOPE_IDENTITY() as int); ";  //This line of code returns the last inserted identity ID of the table.
            var id = db.Query<int>(sql, company).Single();
            company.CompanyId = id;
            return company;

        }

        public Company GetById(int id)
        {
            var sql = "SELECT * FROM Companies WHERE CompanyId = @CompanyId";
            return db.Query<Company>(sql, new { @CompanyId = id }).Single();
        }

        public List<Company> GetAllCompanies()
        {
            var sql = "SELECT * FROM Companies";
            return db.Query<Company>(sql).ToList();
        }

        public int DeleteCompany(int id)
        {
            var sql = "DELETE FROM Companies WHERE CompanyId = @Id";
            db.Execute(sql, new { id });
            return id;
        }

        public Company UpdateCompany(Company company)
        {
            var sql = "UPDATE Companies SET CompanyName = @CompanyName WHERE CompanyId = @CompanyId";
            db.Execute(sql, company);
            return company;
        }
    }
}
