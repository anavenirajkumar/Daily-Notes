﻿using Dapper;
using DapperCRUDWebApi2.Interfaces;
using DapperCRUDWebApi2.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Services
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private IDbConnection db;

        public EmployeeRepository(IConfiguration configuration)
        {
            this.db = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
        }

        public Employee AddEmployee(Employee employee)
        {
            var sql = "INSERT INTO Employees (Name, Designation, Email, Phone, CompanyId) VALUES(@Name, @Designation, @Email, @Phone, @CompanyId);"
                        +"SELECT CAST(SCOPE_IDENTITY() as int); "; // This line of code returns the last inserted identity ID of the table.
            var id = db.Query<int>(sql, employee).Single();
            employee.EmployeeId = id;
            return employee;
        }
        public Employee GetById(int id)
        {
            var sql = "SELECT * FROM Employees WHERE EmployeeId = @Id";
            return db.Query<Employee>(sql, new { @Id = id }).Single();
        }

        public List<Employee> GetAllEmployees()
        {
            var sql = "SELECT * FROM Employees";
            return db.Query<Employee>(sql).ToList();
        }

        public int DeleteEmployee(int id)
        {
            var sql = "DELETE FROM Employees WHERE EmployeeId = @Id";
            db.Execute(sql, new { id });
            return id;
        }

        public Employee UpdateEmployee(Employee employee)
        {
            var sql = "UPDATE Employees SET Name = @Name, Designation = @Designation, Email = @Email, Phone = @Phone, CompanyId = @CompanyId WHERE EmployeeId = @EmployeeId";
            db.Execute(sql, employee);
            return employee;
        }
    }
}
