﻿using DapperCRUDWebApi2.Interfaces;
using DapperCRUDWebApi2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : Controller
    {
        private readonly IEmployeeRepository _empRepo;
        private readonly IBonusRepository _bonRepo;
        private readonly ICompanyRepository _compRepo;

        public EmployeesController( IEmployeeRepository empRepo, IBonusRepository bonRepo, ICompanyRepository compRepo)
        {
            _bonRepo = bonRepo;
            _empRepo = empRepo;
            _compRepo = compRepo;
        }
        
        // Get All Employees
        [HttpGet("getAll")]
        public List<Employee> GetAll()
        {
            return _empRepo.GetAllEmployees();
        }

        // Get All Employees with Companies
        [HttpGet("GetAllEmployeesWithCompanies")]
        public List<Employee> GetAllEmployeesCompanies(int companyId)
        {
            List<Employee> employees = _bonRepo.GetAllEmployeesWithCompanies(companyId);
            return employees;
        }


        // Get All Companies with Employees
        [HttpGet]
        [Route("GetAllCompanyWithEmployees")]
        public List<Company> GetAllCompaniesEmployees()
        {
            return _bonRepo.GetAllCompaniesWithEmployees();
        }

        // Create Employee
        [HttpPost]
        [Route("AddEmployee")]
        public Employee AddEmployee( Employee emp)
        {
            if (ModelState.IsValid)
            {
                _empRepo.AddEmployee(emp);
                return emp;
            }
            return emp;
        }

        // GET Employee With Company
        [HttpGet]
        [Route("GetEmployee/{id}")]
        public Employee GetEmp(int? id)
        {
            if (id == null)
            {
                return null;
            }

            Employee Employe = _empRepo.GetById(id.GetValueOrDefault());
            if (Employe == null)
            {
                return null;
            }
            Company companyList = _compRepo.GetById((int)Employe.CompanyId);
            ViewBag.CompanyList = companyList;
            Employe.Company = companyList;
            return Employe;
        }

        // Update Employee
        [HttpPut]
        [Route("UpdateEmployee")]
        public Employee EditEmployee(Employee emp)
        {
            if (emp == null)
            {
                return null;
            }

            if (ModelState.IsValid)
            {
                _empRepo.UpdateEmployee(emp);
                return emp;
            }
            return emp;
        }

        // Delete Employee
        [HttpDelete]
        [Route("DeleteEmployee/{id}")]
        public int DeleteEmployee(int? id)
        {
            if (id == null)
            {
                return 0;
            }

            _empRepo.DeleteEmployee(id.GetValueOrDefault());
            return 1;
        }
    }
}
