﻿using DapperCRUDWebApi2.Interfaces;
using DapperCRUDWebApi2.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CompaniesController : Controller
    {
        private readonly ICompanyRepository _compRepo;
        public CompaniesController(ICompanyRepository compRepo)
        {
            _compRepo = compRepo;
        }

        // Get All Companies
        [HttpGet]
        [Route("GetAll")]
        public List<Company> GetAll()
        {
            return _compRepo.GetAllCompanies();
        }

        // Create Company
        [HttpPost]
        [Route("CreateCompany")] 
        public Company Create([Bind("CompanyId,CompanyName")] Company company) // ModelState is valid
        {
            if (ModelState.IsValid)
            {
                _compRepo.AddCompany(company);
                return company;
            }
            return company;
        }


        // GET ID By Company
        [HttpGet("GetById/{id}")]
         public Company GetById(int? id){
            if (id == null)
            {
                return null;
            }
            var company = _compRepo.GetById(id.GetValueOrDefault());
            if (company == null)
            {
                return null;
            }
            return company;
         }

        // Update Employee
        [HttpPut("editCompany")]
        public Company Edit([Bind("CompanyId,CompanyName")] Company company){
            if (ModelState.IsValid)
            {
                _compRepo.UpdateCompany(company);
                return company;
            }
            return company;
        }

        // Delete By Id
        [HttpDelete("{id}")]
        public int Delete(int? id)
        {
            if (id == null)
            {
                return 0;
            }

            _compRepo.DeleteCompany(id.GetValueOrDefault());
            return 1;
        }

    }
}
