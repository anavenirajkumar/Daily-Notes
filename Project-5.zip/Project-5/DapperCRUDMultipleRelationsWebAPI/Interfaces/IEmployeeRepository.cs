﻿using DapperCRUDWebApi2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Interfaces
{
    public interface IEmployeeRepository
    {
        Employee GetById(int id);
        Employee AddEmployee(Employee employee);
        Employee UpdateEmployee(Employee employee);
        int DeleteEmployee(int id);
        List<Employee> GetAllEmployees();

        //Task<Employee> AddAsync(Employee employee);


    }
}
