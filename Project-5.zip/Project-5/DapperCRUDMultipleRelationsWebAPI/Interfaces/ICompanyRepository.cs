﻿using DapperCRUDWebApi2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Interfaces
{
    public interface ICompanyRepository
    {
        Company AddCompany(Company company);
        Company UpdateCompany(Company company);
        Company GetById(int id);
        int DeleteCompany(int id);
        List<Company> GetAllCompanies();


    }
}
