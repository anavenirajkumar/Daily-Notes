﻿using DapperCRUDWebApi2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DapperCRUDWebApi2.Interfaces
{
    public interface IBonusRepository
    {
        List<Employee> GetAllEmployeesWithCompanies(int id);
        List<Company> GetAllCompaniesWithEmployees();
    }
}
