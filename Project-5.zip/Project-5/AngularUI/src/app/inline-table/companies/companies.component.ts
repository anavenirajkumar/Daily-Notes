import { Component, OnInit } from '@angular/core';
import { ICompany } from 'src/app/models/ICompany';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.css']
})
export class CompaniesComponent implements OnInit {

  public companies:ICompany[] = [];
  public company = {
    companyId : 0,
    companyName : ''
  }

  public companyIndex:any;

  constructor(private compService:ServiceApiService) { }

  ngOnInit() {
    this.getCompanies();
  }

  getCompanies(){
    this.compService.getCompanies().subscribe((data)=> {
      this.companies = data;
      console.log(this.companies);
    })
  }

  addCompany(){
    // console.log(this.company);
    if(this.company.companyName !== ''){
        console.log(this.company);
        this.compService.addCompany(this.company).subscribe((data) => {
          console.log(data);
          this.getCompanies();
          this.company.companyName = '';
        })
    }
  }

  editCompany(company:any){
     console.log(company);
     this.companyIndex = company.companyId;
  }

  deleteCompany(company:any){
    console.log(company);
     this.compService.deleteCompany(company.companyId).subscribe((data)=>{
       console.log(data);
       this.getCompanies();
     })
  }

  updateCompany(company:any){
    console.log(company);
    this.compService.updateCompany(company).subscribe((data) => {
      console.log(data);
      this.getCompanies();
      this.companyIndex = null;
    })
  }
  cancelCompany(){
    this.companyIndex = null;
  }


}
