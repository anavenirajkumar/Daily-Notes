import { Component, OnInit } from '@angular/core';
import { ICompany } from 'src/app/models/ICompany';
import { IEmployee } from 'src/app/models/IEmployee';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  public employees:IEmployee[] = [];

  public employee:IEmployee = {
    employeeId : 0,
    name : '',
    email : '',
    phone : '',
    designation : '',
    companyId : 0,
    company : {
      companyId : 0,
      companyName: ''
    }
  }

  public companies:ICompany[] = [];

  public employeeIndex:any;

  constructor(private empService:ServiceApiService) { }

  ngOnInit() {
    this.getAllEmployeesCompanies();
    this.getAllCompanies();

  }
  getAllEmployeesCompanies(){
    this.empService.getAllEmployeesWithCompanies().subscribe((data)=> {
      this.employees = data;
      console.log(this.employees);
    })
  }

  getAllCompanies(){
    this.empService.getCompanies().subscribe((data)=> {
      this.companies = data;
      console.log(this.companies);
    })
  }

  addEmployee(){
    if(this.employee.companyId != 0){ // 0 != 0; 0 anedi 0 kakapothe lopaliki vellu -> i check company and after change to 'Select Company' 
          //  console.log(this.employee.companyId); return;
          this.empService.addEmployee(this.employee).subscribe((data)=> {
            console.log(data);
                this.employee.name = '',
                this.employee.email = '',
                this.employee.phone = '',
                this.employee.designation = '',
                this.employee.companyId = 0
            this.getAllEmployeesCompanies();
          })
    } 
  }

  editEmployee(employee:any){
    this.employeeIndex = employee.employeeId;
  }
  deleteEmployee(employee:any){
    this.empService.deleteEmployee(employee.employeeId).subscribe((data)=>{
      console.log(data);
      this.getAllEmployeesCompanies();
    })
  }
  updateEmployee(employee:any){
    if(employee.companyId != 0){
      console.log(employee);
      this.empService.updateEmployee(employee).subscribe((data)=> {
        console.log(data);
        this.getAllEmployeesCompanies();
        this.employeeIndex = null;
      })
    }
    this.getAllEmployeesCompanies();
  }

  cancelEmployee(){
    this.employeeIndex = null;
  }
}
