import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompaniesComponent } from './inline-table/companies/companies.component';
import { EmployeesComponent } from './inline-table/employees/employees.component';
import { GetCIdComponent } from './paramMap-edit/param-map-companies/get-c-id/get-c-id.component';
import { GetEIdComponent } from './paramMap-edit/param-map-employees/get-e-id/get-e-id.component';
import { ParamMapCompaniesComponent } from './paramMap-edit/param-map-companies/param-map-companies.component';
import { ParamMapEmployeesComponent } from './paramMap-edit/param-map-employees/param-map-employees.component';
import { CompaniesPopupComponent } from './popup-edit/companies-popup/companies-popup.component';
import { EmployeesPopupComponent } from './popup-edit/employees-popup/employees-popup.component';


const routes: Routes = [
  {path  :'companies-inline', component: CompaniesComponent},
  {path : 'employees-inline', component : EmployeesComponent},
  {path : 'companies-popup', component : CompaniesPopupComponent},
  {path : 'employees-popup', component : EmployeesPopupComponent},
  {path : 'companies-paramMap', component : ParamMapCompaniesComponent},
  {path : 'companies-paramMap/:id', component : GetCIdComponent},
  {path : 'employees-paramMap', component : ParamMapEmployeesComponent},
  {path : 'employees-paramMap/:id', component : GetEIdComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
