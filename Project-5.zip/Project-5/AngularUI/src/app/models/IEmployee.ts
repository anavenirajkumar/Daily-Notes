import { ICompany } from "./ICompany";

export class IEmployee {
    employeeId :number = 0;
    name :  string = '';
    email : string = '';
    phone : string = '';
    designation : string = '';
    companyId : number = 0;
    company:ICompany = {
         companyId : 0,
         companyName: ''
    }
}
