export class ICompany{
    companyId: number = 0;
    companyName : string = '';
}