import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ICompany } from 'src/app/models/ICompany';
import { IEmployee } from 'src/app/models/IEmployee';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-employees-popup',
  templateUrl: './employees-popup.component.html',
  styleUrls: ['./employees-popup.component.css']
})
export class EmployeesPopupComponent implements OnInit {

  public employees:IEmployee[] = [];
  public companies:ICompany[] = [];
  public employeeform:any;
  public employee:IEmployee = {
    employeeId : 0,
    name : '',
    email : '',
    phone : '',
    designation : '',
    companyId : 0,
    company : {
      companyId : 0,
      companyName: ''
    }
  }
  public title:any;
  public showAddEmployee:boolean = false;
  public showUpdateEmployee:boolean = false;
 public showItem:boolean = false;
  constructor(private empService:ServiceApiService) { }

  ngOnInit() {
    this.getAllEmployeesCompanies();
    this.getCompanies();
    this.employeeform = new FormGroup({
       employeeName : new FormControl('',[Validators.required]),
       employeeEmail : new FormControl('',[Validators.required]),
       employeePhone : new FormControl('', [Validators.required]),
       employeeDesignation : new FormControl('',[Validators.required]),
       employeecompanyId : new FormControl('', [Validators.required])
    })
  }

  public getAllEmployeesCompanies(){
    this.empService.getAllEmployeesWithCompanies().subscribe((data)=>{
      this.employees = data;
      console.log(this.employees);
    })
  }
  public getCompanies(){
    this.empService.getCompanies().subscribe((data)=>{
      this.companies = data;
      console.log(this.companies);
    })
  }

  openPopup(){
    this.title = "Add Employee";
    this.showItem = false;
    this.showAddEmployee = true;
    this.showUpdateEmployee = false;
    this.employeeform.reset();
    this.getCompanies();
  }

  createEmployee(){
    this.employeeform.markAllAsTouched();
    if(this.employeeform.value.employeecompanyId != 0 && this.employeeform.valid){
      this.employee.companyId = this.employeeform.value.employeecompanyId;
      this.employee.name = this.employeeform.value.employeeName;
      this.employee.email = this.employeeform.value.employeeEmail;
      this.employee.phone = this.employeeform.value.employeePhone;
      this.employee.designation = this.employeeform.value.employeeDesignation;
      console.log(this.employee);      this.empService.addEmployee(this.employee).subscribe((data)=>{
        console.log(data);
        this.getAllEmployeesCompanies();
        this.employeeform.reset();
        let ref = document.getElementById('cancel');
        ref?.click();
      })
    }
  }
  
  editEmployee(employee:any){
    console.log(employee);
    this.showItem = true;
     this.title = "Edit Employee";
     this.showAddEmployee = false;
     this.showUpdateEmployee = true;
     this.employee.employeeId = employee.employeeId;
     this.employeeform.controls['employeeName'].setValue(employee.name);
      this.employeeform.controls['employeeEmail'].setValue(employee.email);
      this.employeeform.controls['employeePhone'].setValue(employee.phone);
      this.employeeform.controls['employeecompanyId'].setValue(employee.companyId);
      this.employeeform.controls['employeeDesignation'].setValue(employee.designation);
      this.employee.company.companyId = this.employee.companyId;
      //this.employee.company.companyName = employee.company.companyName;
  }


  updateEmployee(){
      this.employeeform.markAllAsTouched();
      if(this.employeeform.value.employeecompanyId != 0 && this.employeeform.valid){
          //this.employeeform.markAllAsTouched();
          this.employee.employeeId = this.employee.employeeId;
          this.employee.companyId = this.employeeform.value.employeecompanyId;
          this.employee.name = this.employeeform.value.employeeName;
          this.employee.email = this.employeeform.value.employeeEmail;
          this.employee.phone = this.employeeform.value.employeePhone;
          this.employee.designation = this.employeeform.value.employeeDesignation;
          this.employee.company.companyId = this.employee.companyId;
          //this.employee.company.companyName = this.employee.company.companyName;

          console.log(this.employee);
          this.empService.updateEmployee(this.employee).subscribe((data) => {
            console.log(data);
            this.getAllEmployeesCompanies();
            let ref = document.getElementById('cancel');
            ref?.click();
            this.employeeform.reset();
          })
    }
  }
  deleteEmployee(employee:any){
     this.empService.deleteEmployee(employee.employeeId).subscribe((data)=> {
       console.log(data);
       this.getAllEmployeesCompanies();
     })
  }

  public employeeName(){
    return this.employeeform.get('employeeName');
  }
  public employeeEmail(){
    return this.employeeform.get('employeeEmail');
  }
  public employeePhone(){
    return this.employeeform.get('employeePhone');
  }
  public employeeDesignation(){
    return this.employeeform.get('employeeDesignation');
  }
  public employeecompanyId(){
    return this.employeeform.get('employeecompanyId');

  }
}
