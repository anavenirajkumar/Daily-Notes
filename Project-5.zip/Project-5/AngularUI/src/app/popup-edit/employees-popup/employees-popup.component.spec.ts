import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeesPopupComponent } from './employees-popup.component';

describe('EmployeesPopupComponent', () => {
  let component: EmployeesPopupComponent;
  let fixture: ComponentFixture<EmployeesPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeesPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeesPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
