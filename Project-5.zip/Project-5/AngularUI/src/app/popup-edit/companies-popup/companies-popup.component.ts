import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ICompany } from 'src/app/models/ICompany';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-companies-popup',
  templateUrl: './companies-popup.component.html',
  styleUrls: ['./companies-popup.component.css']
})
export class CompaniesPopupComponent implements OnInit {

  public companies:ICompany[] = [];
  public companyform : any;
  public title:any;

  public company:ICompany = {
    companyId : 0,
    companyName : ''
  }
  public showAddCompany:boolean = false;
  public showUpdateCompany:boolean = false;

  constructor(private companyService:ServiceApiService) { }

  ngOnInit(){
     this.getCompanies();
     this.companyform  = new FormGroup({
         companyName :  new FormControl('',[Validators.required])
     })
  }
  getCompanies(){
    this.companyService.getCompanies().subscribe((data)=>{
      this.companies = data;
      console.log(this.companies);
    })
  }
  openPopup(){
          this.title = 'Add Company';
          this.companyform.reset();
          this.showAddCompany = true;
          this.showUpdateCompany = false;
          //this.company.companyId = this.company.companyId;
  }

  createCompany(){
    this.companyform.markAllAsTouched();
    console.log(this.companyform.valid);
    if(this.companyform.valid){
    this.showAddCompany = true;
      this.company.companyId = this.company.companyId;
      this.company.companyName = this.companyform.value.companyName;
      console.log(this.company);
      console.log(this.companyform.valid);
      
          this.companyService.addCompany(this.company).subscribe((data) => {
            //alert('Company Creation Sucessfully Submited');
            let ref = document.getElementById('cancel');
            ref?.click();
            this.companyform.reset();
            this.getCompanies();
        },err=>{
         alert('Something Went Wrong')
        });
      }
    }

  editCompany(company:any){
    //console.log(company);
    this.showUpdateCompany = true;
    this.showAddCompany = false;
    this.title = 'Edit Company';
    this.company.companyId = company.companyId;
    this.companyform.controls['companyName'].setValue(company.companyName);
  }

  deleteCompany(company:any){
    console.log(company);
      this.companyService.deleteCompany(company.companyId).subscribe((data)=> {
        console.log(data);
        this.getCompanies();
      })
  }

  updateCompany(){
    this.companyform.markAllAsTouched();
    if(this.companyform.valid){
      console.log(this.company);
        this.company.companyId = this.company.companyId;
        this.company.companyName = this.companyform.value.companyName;
        this.companyService.updateCompany(this.company).subscribe((data)=>{
        console.log(data);
        let ref = document.getElementById('cancel');
        ref?.click();
        this.companyform.reset();
        this.getCompanies();
     })
    }
  }

  public companyName(){
   return this.companyform.get('companyName');
  }
}
