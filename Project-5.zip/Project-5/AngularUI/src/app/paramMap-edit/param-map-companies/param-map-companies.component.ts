import { Component, OnInit } from '@angular/core';
import { ICompany } from 'src/app/models/ICompany';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-param-map-companies',
  templateUrl: './param-map-companies.component.html',
  styleUrls: ['./param-map-companies.component.css']
})
export class ParamMapCompaniesComponent implements OnInit {

  public companies:ICompany[] = [];
  public company:ICompany = {
    companyId : 0,
    companyName : ''
 }
  constructor(private companyService:ServiceApiService) { }

  ngOnInit() {
    this.getCompanies();
  }

  getCompanies(){
    this.companyService.getCompanies().subscribe((data)=>{
      this.companies = data;
      console.log(this.companies);
    })
  }
  addCompany(){
     if(this.company.companyName !==''){
      this.companyService.addCompany(this.company).subscribe((data)=>{
        console.log(data);
        this.getCompanies();
        this.company.companyName ='';
      })
     }
  }
  deleteCompany(companyId:any){
     this.companyService.deleteCompany(companyId).subscribe((data)=>{
       console.log(data);
       this.getCompanies();
     })
  }


}
