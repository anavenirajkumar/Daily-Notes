import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParamMapCompaniesComponent } from './param-map-companies.component';

describe('ParamMapCompaniesComponent', () => {
  let component: ParamMapCompaniesComponent;
  let fixture: ComponentFixture<ParamMapCompaniesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParamMapCompaniesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParamMapCompaniesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
