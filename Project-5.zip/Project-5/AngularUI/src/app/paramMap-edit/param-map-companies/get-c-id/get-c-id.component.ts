import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ICompany } from 'src/app/models/ICompany';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-get-c-id',
  templateUrl: './get-c-id.component.html',
  styleUrls: ['./get-c-id.component.css']
})
export class GetCIdComponent implements OnInit {
  
   public companyId:any;
   public company:ICompany = {
      companyId : 0,
      companyName : ''
   }
   constructor(private snapshot:ActivatedRoute,
               private companyService:ServiceApiService,
               private router:Router) { }

  ngOnInit(){
      this.snapshot.paramMap.subscribe((id)=>{
        this.companyId = id.get('id');
        console.log(this.companyId);
      });
     this.companyService.getCompany(this.companyId).subscribe((data)=> {
       this.company = data;
       console.log(this.company);
     })
  }

  editCompany(){
    //console.log(this.company);
    if(this.company.companyId != 0 ){
       //console.log(this.company); return;
      this.companyService.updateCompany(this.company).subscribe((data)=>{
        console.log(data);
        this.router.navigate(['/companies-paramMap']);
      })
    }
  }


}
