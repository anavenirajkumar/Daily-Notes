import { Component, OnInit } from '@angular/core';
import { ICompany } from 'src/app/models/ICompany';
import { IEmployee } from 'src/app/models/IEmployee';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-param-map-employees',
  templateUrl: './param-map-employees.component.html',
  styleUrls: ['./param-map-employees.component.css']
})
export class ParamMapEmployeesComponent implements OnInit {

  public employees:IEmployee[] = [];
  public employee:IEmployee = {
      employeeId : 0,
      name : '',
      email : '',
      phone : '',
      designation : '',
      companyId : 0,
      company : {
        companyId : 0,
        companyName: ''
      }
  }
  public companies:ICompany[] = [];
  
  constructor(private empService:ServiceApiService) { }

  ngOnInit() {
    this.getAllEmployeesCompanies();
    this.getCompanies();
  }
  getAllEmployeesCompanies(){
    this.empService.getAllEmployeesWithCompanies().subscribe((data)=>{
      this.employees = data;
      console.log(this.employees);
    })
  }
  getCompanies(){
    this.empService.getCompanies().subscribe((data)=> {
      this.companies = data;
      console.log(this.companies);
    })
  }
  addEmployee(){
    if(this.employee.companyId != 0 && this.employee.name !='' && this.employee.email !='' && this.employee.phone !='' && this.employee.designation !=''){
       console.log(this.employee);
       this.empService.addEmployee(this.employee).subscribe((data)=>{
         console.log(data);
         this.employee.name = '',
         this.employee.email = '',
         this.employee.phone = '',
         this.employee.designation = '',
         this.employee.companyId = 0
         this.getAllEmployeesCompanies();
       })
    }
  }
  deleteEmployee(employeeId:any){
     this.empService.deleteEmployee(employeeId).subscribe((data)=> {
        console.log(data);
        this.getAllEmployeesCompanies();
     })
  }
}
