import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetEIdComponent } from './get-e-id.component';

describe('GetEIdComponent', () => {
  let component: GetEIdComponent;
  let fixture: ComponentFixture<GetEIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetEIdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetEIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
