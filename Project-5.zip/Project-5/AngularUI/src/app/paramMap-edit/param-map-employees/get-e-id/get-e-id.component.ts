import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ICompany } from 'src/app/models/ICompany';
import { IEmployee } from 'src/app/models/IEmployee';
import { ServiceApiService } from 'src/app/services/service-api.service';

@Component({
  selector: 'app-get-e-id',
  templateUrl: './get-e-id.component.html',
  styleUrls: ['./get-e-id.component.css']
})
export class GetEIdComponent implements OnInit {

  public employeeId:any;
  public employee:IEmployee = {
      employeeId :  0,
      name : '',
      email : '',
      phone : '',
      designation : '',
      companyId : 0,
      company : {
        companyId : 0,
        companyName: ''
      }
  }
  public companies:ICompany[] = [];
  
  constructor(private snapshot:ActivatedRoute,
             private empService:ServiceApiService,
             private router:Router
             ) { }

  ngOnInit() {
    this.snapshot.paramMap.subscribe((id)=> {
      this.employeeId = id.get('id');
      console.log(this.employeeId);
    });
    this.empService.getEmployee(this.employeeId).subscribe((data)=> {
      this.employee = data;
      console.log(this.employee);
    })
    this.empService.getCompanies().subscribe((data)=> {
      this.companies = data;
      console.log(this.companies);
    })
  }

  updateEmployee(){
    // console.log(this.employee);
    if(this.employee.name !='' && this.employee.email != '' && this.employee.phone !='' && this.employee.designation != ''){
        console.log(this.employee);
        this.empService.updateEmployee(this.employee).subscribe((data)=>{
          console.log(data);
           this.router.navigate(['/employees-paramMap']);
        })
    }
  }

}
