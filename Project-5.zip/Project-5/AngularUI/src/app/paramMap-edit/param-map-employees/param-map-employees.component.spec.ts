import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParamMapEmployeesComponent } from './param-map-employees.component';

describe('ParamMapEmployeesComponent', () => {
  let component: ParamMapEmployeesComponent;
  let fixture: ComponentFixture<ParamMapEmployeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParamMapEmployeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParamMapEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
