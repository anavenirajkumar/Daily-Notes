import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CompaniesComponent } from './inline-table/companies/companies.component';
import { ServiceApiService } from './services/service-api.service';
import {HttpClientModule} from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeesComponent } from './inline-table/employees/employees.component';
import { CompaniesPopupComponent } from './popup-edit/companies-popup/companies-popup.component';
import { EmployeesPopupComponent } from './popup-edit/employees-popup/employees-popup.component';
import { ParamMapCompaniesComponent } from './paramMap-edit/param-map-companies/param-map-companies.component';
import { ParamMapEmployeesComponent } from './paramMap-edit/param-map-employees/param-map-employees.component';
import { GetCIdComponent } from './paramMap-edit/param-map-companies/get-c-id/get-c-id.component';
import { GetEIdComponent } from './paramMap-edit/param-map-employees/get-e-id/get-e-id.component';

@NgModule({
  declarations: [
    AppComponent,
    CompaniesComponent,
    EmployeesComponent,
    CompaniesPopupComponent,
    EmployeesPopupComponent,
    ParamMapCompaniesComponent,
    ParamMapEmployeesComponent,
    GetCIdComponent,
    GetEIdComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ServiceApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
