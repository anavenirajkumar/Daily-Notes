import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ICompany } from '../models/ICompany';
import { IEmployee } from '../models/IEmployee';

@Injectable({
  providedIn: 'root'
})
export class ServiceApiService {

  readonly ApiUrl = 'http://localhost:44995/api'
  constructor(private httpClient:HttpClient) { }

  addCompany(company:ICompany):Observable<ICompany>{
     return this.httpClient.post<ICompany>(this.ApiUrl + '/Companies/CreateCompany', company);
  }

  getCompanies():Observable<ICompany[]>{
    return this.httpClient.get<ICompany[]>(this.ApiUrl + '/Companies/GetAll')
  }

  updateCompany( company:ICompany):Observable<ICompany>{
     return this.httpClient.put<ICompany>(this.ApiUrl + '/Companies/editCompany', company)
  }

  getCompany(comapanyId:any):Observable<ICompany>{ // Get Company by ParamMap
    return this.httpClient.get<ICompany>(this.ApiUrl + '/Companies/GetById/'+ comapanyId);
  }

  deleteCompany(companyId:ICompany):Observable<ICompany>{
    return this.httpClient.delete<ICompany>(this.ApiUrl + '/Companies/' + companyId);
  }

  getAllCompaniesWithEmployees():Observable<any[]>{ // GET All Companies With Employees
    return this.httpClient.get<any[]>(this.ApiUrl + '/Employees/GetAllCompaniesWithEmployees');
  }


  /////////////////// Employee Api's //////////////////////////
 getEmployees():Observable<IEmployee[]>{ // GET Only Employees
   return this.httpClient.get<IEmployee[]>(this.ApiUrl + '/Employees/getAll');
 }

 getAllEmployeesWithCompanies():Observable<IEmployee[]>{  // GET All Employees With Companies
  return this.httpClient.get<IEmployee[]>(this.ApiUrl + '/Employees/GetAllEmployeesWithCompanies');
}

 addEmployee(employee:IEmployee):Observable<IEmployee>{
   return this.httpClient.post<IEmployee>(this.ApiUrl + '/Employees/AddEmployee', employee);
 }

 getEmployee(getId:any):Observable<IEmployee>{
   return this.httpClient.get<IEmployee>(this.ApiUrl + '/Employees/GetEmployee/' + getId)
 }

 deleteEmployee(id:any):Observable<any>{
    return this.httpClient.delete<any>(this.ApiUrl + '/Employees/DeleteEmployee/' + id);
 }

 updateEmployee(employee:IEmployee):Observable<IEmployee>{
   return this.httpClient.put<IEmployee>(this.ApiUrl + '/Employees/UpdateEmployee/', employee)
 }
 


}
