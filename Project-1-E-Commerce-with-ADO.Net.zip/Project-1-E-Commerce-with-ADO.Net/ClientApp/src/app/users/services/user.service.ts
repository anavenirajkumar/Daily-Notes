import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { ILogin, IUser } from '../interfaces/ILogin';
import { IRegister } from '../interfaces/IRegister';
import {catchError, map, retry} from "rxjs/operators";
//import { JwtHelperService } from '@auth0/angular-jwt';
import { Router } from '@angular/router';
import { ICategory, IProduct, ISubCategory } from '../interfaces/ICategory';
import { environment } from 'src/environments/environment';



@Injectable({
  providedIn: 'root'
})
export class UserService {

   readonly ApiUrl = environment.apiUrl;  //https://localhost:44314/swagger/index.html


   public currentUser:IUser = { // responce data is coming from Object so Im Create Object and Storing the Data => IUser();
      userID: '',
      userName: '',
      email : '',
      role: '',
      isSuccess : '',
      password : '',
      token : '',
      message : '',
      village : '',
      mandal : '',
      district : ''
  }
  //helper = new JwtHelperService(); // JwtHelperService or Object

  constructor(private httpClient : HttpClient,
      private router : Router) { }

  public register(registerDetails:IRegister): Observable<IRegister>{
    return this.httpClient.post<IRegister>(this.ApiUrl + 'User/RegisterUser', registerDetails)
  }

 public login(user:any) : Observable<IUser> { // responce data is coming from Object so Im Create Object => IUser();
     return this.httpClient.post(this.ApiUrl + 'User/LoginUser', user).pipe(

      map((response: any) => {
        //const decodedToken = this.helper.decodeToken(response.token);
        const decoded = response;

        //this.currentUser.token = decodedToken.token;
        this.currentUser.token = decoded.token;
        this.currentUser.userID = decoded.userID;
        this.currentUser.userName = decoded.userName;
        this.currentUser.email = decoded.email;
        this.currentUser.password = decoded.password;
        this.currentUser.role = decoded.role;
        this.currentUser.district = decoded.district;
        this.currentUser.mandal = decoded.mandal;
        this.currentUser.message = decoded.message;
        this.currentUser.village = decoded.village;
        this.currentUser.isSuccess = decoded.isSuccess;

        if(this.currentUser.userID !== null){
          localStorage.setItem('token', response.token);
          localStorage.setItem('userDetails',JSON.stringify(response));
        }

        return this.currentUser;
      }
        // ,catchError(this.errorHandler)
      ),catchError(this.errorHandler)
      //catchError(this.errorHandler)
     )
     
  }

  public updateUserAddress(address:any){
     return this.httpClient.post(this.ApiUrl + 'User/Address', address);
  }

  public AddUsers(users:any){
     return this.httpClient.post(this.ApiUrl + 'User/Admin/Add', users);
  }

  public getAllUsers(){
    return this.httpClient.get(this.ApiUrl + 'User/Admin/Get');
  }

  public getAllCountries(){
    return this.httpClient.get(this.ApiUrl + 'Country/Countries')
  }

  public getStates( id:any){ // Note: Backend Api Works this Flow in Network Tab =  Request URL: http://localhost:44464/api/Country/GetStates?CountryID=1
    return this.httpClient.get(this.ApiUrl + `Country/States/${id}?CountryID=`+ id) // Same Like As Tease Request
  }

  public getCities( id:any){ // Note: Backend Api Works this Flow in Network Tab =  Request URL: http://localhost:44464/api/Country/GetCities?StateID=1
    return this.httpClient.get(this.ApiUrl + `Country/Cities?StateID=`+ id) // Same Like As Tease Request
  }

  public getMandal( id:any){ // Note: Backend Api Works this Flow in Network Tab =  Request URL: http://localhost:44464/api/Country/GetMandal?CityID=1
    return this.httpClient.get(this.ApiUrl + `Country/Mandals?CityID=`+ id) // Same Like As Tease Request
  }

  public getVillages( id:any){ // Note: Backend Api Works this Flow in Network Tab =  Request URL: http://localhost:44464/api/Country/GetVillages?VillageID=1
    return this.httpClient.get(this.ApiUrl + `Country/Villages?VillageID=`+ id) // Same Like As Tease Request
  }
  

  public addCountry(country:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddCountry', country);
  }

  public addState(state:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddState', state);
  }

 public addCity(city:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddCity', city);
  }

  public addMandal(mandal:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddMandal', mandal);
  }

  public addVillage(village:any){
    return this.httpClient.post(this.ApiUrl + 'Country/AddVillage', village);
  }

  public AdminUser() : IUser{
     return this.currentUser;
  }

  // login(model: any): Observable<IUser> {
  //   return this.httpClient.post(this.ApiUrl + 'identity/login', model).pipe(
  //     map((response: any) => {
  //       const decodedToken = this.helper.decodeToken(response.token);

  //       this.currentUser.username = decodedToken.given_name;
  //       this.currentUser.email = decodedToken.email;
  //       this.currentUser.jobtitle = decodedToken.JobTitle;
  //       this.currentUser.role = decodedToken.role;

  //       localStorage.setItem('token', response.token);

  //       return this.currentUser;
  //     })
  //   );
  // }

   public isLoggedIn(){
     if(localStorage.getItem('token')){
       return true;
     } else {
       return false;
     }
  }

  public getToken(){
     if(localStorage.getItem('token')){
       return localStorage.getItem('token');
     }
     else {
       return "";
     }
  }

  public userInfomation() {
     return JSON.parse(localStorage.getItem('userDetails') || '{}');
  }
  

  errorHandler(error: HttpErrorResponse) { // if Any Error
      //localStorage.clear(); // Remove Total Local Storage
       localStorage.removeItem('token');
       localStorage.removeItem('userDetails');
       this.router.navigate(['/'])
    return throwError(error.message || "server error.");
}


  // public handleError(error:HttpErrorResponse){
  //   let errorMessage:string = '';
  //   if(error.error instanceof ErrorEvent){
  //     // client Error
  //     errorMessage = `Error : ${error.error.message}`
  //     console.log("Removed Local Storage");
  //     localStorage.clear();
  //   }
  //   else{
  //     // server error
  //     errorMessage = `Status : ${error.status} \n Message: ${error.message}`;
  //   }
  //   return throwError(errorMessage);
  // }
 
  public createCategory(category:ICategory):Observable<ICategory>{
    return this.httpClient.post<ICategory>(this.ApiUrl + 'Category/AddCategory', category);
  }

  public createSubCategory(subcategory:ISubCategory):Observable<ISubCategory>{
    return this.httpClient.post<ISubCategory>(this.ApiUrl + 'Category/AddSubCategory', subcategory);
  }

  public createProduct(product:IProduct){
    return this.httpClient.post<IProduct>(this.ApiUrl + 'Category/AddProduct', product);
  }

  public getCategories(){
    return this.httpClient.get(this.ApiUrl + 'Category/GetCategories');
  }

  public getSubCategories(){
    return this.httpClient.get(this.ApiUrl + 'Category/GetSubCategories');
  }

  public getProducts(){
    return this.httpClient.get(this.ApiUrl + 'Category/GetProducts');
  }

  public changeCategory(categoryId:any){ 
    return this.httpClient.get(this.ApiUrl + 'Country/GetSubCategories?categoryid=' + categoryId);
  }

  public getProduct(productId:any){
    return this.httpClient.get(this.ApiUrl + `Category/GetProduct/${productId}?productId=` + productId);
}

public updateProduct(product:any){
  return this.httpClient.put(this.ApiUrl + 'Category/UpdateProduct', product);
}

public deleteProduct(productId:any){
  return this.httpClient.delete(this.ApiUrl + 'Category/DeleteProduct?productId=' + productId)
}

public deleteCategory(categoryId:any){
  return this.httpClient.delete(this.ApiUrl + 'Category/DeleteCategory?categoryId=' + categoryId)
}

public deleteSubCategory(subcategoryId:any){
  return this.httpClient.delete(this.ApiUrl + 'Category/DeleteSubCategory?subcategoryId=' + subcategoryId)
}

public upload(file:any){
  return this.httpClient.post(this.ApiUrl + 'UploadFile/UploadExcelFile', file);
}

public getData(){
  return this.httpClient.get(this.ApiUrl + 'UploadFile/ReadRecords');
}

public deleteRecord(userId:any){
  return this.httpClient.delete(this.ApiUrl + 'UploadFile/DeleteRecord?recordId=' + userId );
}

public getById(userId:any){
  return this.httpClient.delete(this.ApiUrl + 'UploadFile/GetByIdRecord?id=' + userId );
}

public getId(userId:any){
  return this.httpClient.get(this.ApiUrl + 'UploadFile/GetByIdRecord/' + userId );
}

public updateRecord(user:any){
  return this.httpClient.put(this.ApiUrl + 'UploadFile/UpdateRecord', user);
}

}
