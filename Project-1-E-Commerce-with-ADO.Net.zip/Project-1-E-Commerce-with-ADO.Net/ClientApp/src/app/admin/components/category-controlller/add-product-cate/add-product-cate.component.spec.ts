import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddProductCateComponent } from './add-product-cate.component';

describe('AddProductCateComponent', () => {
  let component: AddProductCateComponent;
  let fixture: ComponentFixture<AddProductCateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddProductCateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddProductCateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
