import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-product-cat-id',
  templateUrl: './product-cat-id.component.html',
  styleUrls: ['./product-cat-id.component.css']
})
export class ProductCatIdComponent implements OnInit {

  public productId:any;
  public product:any = {
      productId :  0,
      productName : '',
      productPrice : 0,
      categoryId : 0,
      subCategoryId : 0
  }
  public categories:any = {
    categories : []
  };
  public subCategories:any = {
    subCategories : []
  }
  
  constructor(private snapshot:ActivatedRoute,
             private adminService:UserService,
             private router:Router
             ) { }

  ngOnInit() {
    this.snapshot.paramMap.subscribe((id)=> {
      this.productId = id.get('id');
      console.log(typeof(this.productId));
    });
    let productId:number = +this.productId;
    this.adminService.getProduct(productId).subscribe((data)=> {
      this.product = data;
      console.log(this.product);
    })
    this.adminService.getCategories().subscribe((data)=> {
      this.categories = data;
      console.log(this.categories);
    })

    this.adminService.getSubCategories().subscribe((data)=> {
      this.subCategories = data;
      console.log(this.subCategories);
    })
  }

  updateProduct(){
    let productPrice:number = +this.product.productPrice;
    let productCategoryId:number = +this.product.categoryId;
    let productSubCategoryId:number = +this.product.subCategoryId;

    this.product.productPrice = productPrice;
    let product = {
      productId  : this.product.productId,
      productName : this.product.productName,
      productPrice : this.product.productPrice,
      categoryId : productCategoryId,
      subCategoryId : productSubCategoryId
    }
    console.log(product);

    if(this.product.productName !='' && this.product.productPrice != 0 && this.product.categoryId != 0 && this.product.subCategoryId != 0){
        this.adminService.updateProduct(product).subscribe((data)=>{
          console.log(data);
           this.router.navigate(['/admin/category/product']);
        })
    }
  } 

}
