import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.css']
})
export class AddUsersComponent implements OnInit {

  public loginForm : FormBuilder | any;

  public users:any;
  
  public addUsers = {
    userName : '',
    emailId : '',
    mobilenumber : 0,
    salary : 0,
    gender : ''
  }

  public AllUsers:any = {
    message : '',
    isSuccess : Boolean,
    getInformation : new Array()
  };

  public CountryData:any = { // any is Must
    message : '',
    countries : new Array()
  };

  public StatesData:any = { 
    message : '',
    states : new Array()
  }

  public CitiesData:any = { 
    message : '',
    cities : new Array()
  }

  public MandalData:any = { 
    message : '',
    mandals : new Array()
  }

  public VillageData:any = {
    message : '',
    villages : []
  }

  public addCountry = {
    CountryId : 0,
    CountryName : ''
 }

  public addState = {
     CountryId : 0,
     StateName : ''
  }

  public addCity = {
    StateId : 0,
    CityName : ''
 }

 public addMandal = {
  CityId : 0,
  MandalName : ''
}

public addVillage = {
  MandalId : 0,
  VillageName : ''
}

  public show:boolean = false;
  public addUsersSuccessMessage:any;

  constructor(private adminService: UserService,
              private router:Router,
              private formBuilder : FormBuilder) { }

  ngOnInit(): void {
    //location.reload();
    this.getAll();
    this.getAllCountries();
    // let admin = this.adminService.AdminUser();
    // if(localStorage.getItem('token') && admin.role === 'Admin'){
    //   //this.router.navigate(['/users/admin']);
    // }
    // else{
    //    localStorage.removeItem('token');
    //    this.router.navigate(['/']);
    //    location.reload();
    // }

    this.loginForm = this.formBuilder.group({
      userName : ['aaaaaaaaaa', [Validators.required]],
      emailId : ['aaaaaaaaa@gmail.com', [Validators.required, Validators.email]],
      mobilenumber :  ['1234', [Validators.required]],
      salary :  ['1234', [Validators.required]],
      gender :  ['male', [Validators.required]],
      // Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$')]
    })
  }

  addUser(){
    this.loginForm.markAllAsTouched();
    let mobile:number = +this.loginForm.value.mobilenumber;
    let sal:number = +this.loginForm.value.salary

    this.addUsers.emailId = this.loginForm.value.emailId;
    this.addUsers.userName = this.loginForm.value.userName;
    this.addUsers.mobilenumber = mobile;
    this.addUsers.salary = sal;
    this.addUsers.gender = this.loginForm.value.gender;
    console.log(this.addUsers);
    if(this.loginForm.valid){
      this.adminService.AddUsers(this.addUsers).subscribe((res) => {
          //console.log(res);
          let responce = Object();
          responce = res;
          //console.log(responce);
          //console.log(responce.message);
          this.addUsersSuccessMessage = responce.message;
          console.log(this.addUsersSuccessMessage);
          this
         this.show = true;
         this.getAll();
         setTimeout(() => {
            this.show = false;
         }, 5000);
         this.loginForm.reset();
      })
    }

  }


  public getAll(){
    this.adminService.getAllUsers().subscribe((res)=>{
      this.AllUsers = res;
      console.log(res);
      console.log(this.AllUsers.message);
      console.log(this.AllUsers.isSuccess);
      console.log(this.AllUsers.getInformation);
    })
  }

  public getAllCountries(){
    this.adminService.getAllCountries().subscribe((res => {
      console.log(res)
      this.CountryData = res;
      console.log(this.CountryData.countries)
      //this.Countries = res;
    }))
  }

 public selecteCountry(event:any){
    //console.log(event.target.value);
    let id:number = +event.target.value;
    console.log(typeof(id))
    console.log(id);
    this.adminService.getStates(id).subscribe((res)=>{
      console.log(res);
      this.StatesData = res;
      console.log(this.StatesData.states)
    })
  }

  changeState(event:any){
    let stateId = event.target.value;
    //  console.log(event.target.value)
    this.adminService.getCities(stateId).subscribe((res)=> {
      console.log(res);
      this.CitiesData = res;
    })
  }

  changeCity(event:any){
    let CityId = event.target.value;
    //  console.log(event.target.value)
    this.adminService.getMandal(CityId).subscribe((res)=> {
      console.log(res);
      this.MandalData = res;
    })
  }

  changeMandal(event:any){
    let MandalId = event.target.value;
    //  console.log(event.target.value)
    this.adminService.getVillages(MandalId).subscribe((res)=> {
      console.log(res);
      this.VillageData = res;
    })
  }

  addNewCountry(){
    this.adminService.addCountry(this.addCountry).subscribe((res:any)=> {
      console.log(res);
      this.addCountry.CountryName = '';
      this.getAllCountries();
    })
  }
  addNewState(){
    //console.log(this.addState);
    //let stateId:number = +this.addState.CountryId;
     this.adminService.addState(this.addState).subscribe((res)=> {
       console.log(res);
     })
  }

  addNewCity(){
    this.adminService.addCity(this.addCity).subscribe((res)=> {
      console.log(res);
    })
  }

  addNewMandal(){
    this.adminService.addMandal(this.addMandal).subscribe((res)=> {
      console.log(res);
    })
  }

  addNewVillage(){
    this.adminService.addVillage(this.addVillage).subscribe((res)=> {
      console.log(res);
    })
  }

}
