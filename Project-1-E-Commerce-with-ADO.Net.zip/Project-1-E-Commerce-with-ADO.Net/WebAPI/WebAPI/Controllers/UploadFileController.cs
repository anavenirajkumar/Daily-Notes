﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadFileController : ControllerBase
    {

        public readonly IUploadFile _uploadFileDL;
        public UploadFileController(IUploadFile uploadFile)
        {
            _uploadFileDL = uploadFile;
        }

        [HttpPost("UploadExcelFile")]
        [AllowAnonymous]
        
        public async Task<IActionResult> UploadExcelFile([FromForm] UploadXMLFileRequest request)
        {

            UploadXMLFileResponse response = new UploadXMLFileResponse();
            string path = "UploadFileFolder/"+request.File.FileName;
            try
            {

                using (FileStream stream = new FileStream(path, FileMode.CreateNew))
                {
                    await request.File.CopyToAsync(stream);
                }

                response = await _uploadFileDL.UploadXMLFile(request, path);

                string[] files = Directory.GetFiles("UploadFileFolder/"); // Get Files and Deleting Existing Files
                foreach (string file in files)
                {
                    System.IO.File.Delete(file);
                    Console.WriteLine($"{file} is deleted.");
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;

            }

            return Ok(response);
        }

        [HttpPost("UploadCSVFile")]
        [AllowAnonymous]
        
        public async Task<IActionResult> UploadCSVFile([FromForm] UploadCSVFileRequest request)
        {
            UploadCSVFileResponse response = new UploadCSVFileResponse();
            string path = "UploadFileFolder/" + request.File.FileName;
            try
            {

                using (FileStream stream = new FileStream(path, FileMode.CreateNew))
                {
                    await request.File.CopyToAsync(stream);
                }

                response = await _uploadFileDL.UploadCSVFile(request, path);

                string[] files = Directory.GetFiles("UploadFileFolder/");
                foreach (string file in files)
                {
                    System.IO.File.Delete(file);
                    Console.WriteLine($"{file} is deleted.");
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;

            }

            return Ok(response);
        }

        [HttpPost("ReadRecord")]
        [AllowAnonymous]
        
        public async Task<IActionResult> ReadRecord(ReadRecordRequest request)
        {
            ReadRecordResponse response = new ReadRecordResponse();

            try
            {
                response = await _uploadFileDL.ReadRecord(request);
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpGet("ReadRecords")]
        [AllowAnonymous]
        public async Task<IActionResult> ReadRecords()
        {
            ReadRecordResponse response = new ReadRecordResponse();

            try
            {
                response = await _uploadFileDL.ReadRecords();
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }
        /*  [HttpDelete]
          [AllowAnonymous]
          public async Task<IActionResult> DeleteRecord(DeleteRecordRequest request)
          {
              DeleteRecordResponse response = new DeleteRecordResponse();

              try
              {
                  response = await _uploadFileDL.DeleteRecord(request);
              }
              catch (Exception ex)
              {
                  response.IsSuccess = false;
                  response.Message = ex.Message;
              }

              return Ok(response);
          }*/


        [HttpGet("GetByIdRecord/{id}")]
        [AllowAnonymous]
        public async Task<ReadRecord> GetByIdRecord(int id) // Get Id by Category;
        {
            ReadRecord response = new ReadRecord();
            try
            {
                response = await _uploadFileDL.GetIdByRecord(id);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                throw;
            }

            return response;
        }


        [HttpDelete("DeleteRecord")]
        [AllowAnonymous]
        public async Task<IActionResult> DeleteRecord(int recordId) // Delete Record by ID
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            try
            {
                response = await _uploadFileDL.DeletebyId(recordId);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPut("UpdateRecord")]
        [AllowAnonymous]
        public async Task<IActionResult> UpdateRecord(ReadRecord record) // Update Category;
        {
            ReadRecord response = new ReadRecord();
            try
            {
                response = await _uploadFileDL.UpdateRecord(record);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                throw;
            }

            return Ok(response);
        }

    }
}
