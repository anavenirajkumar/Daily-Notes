﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface IUploadFile
    {
        public Task<UploadXMLFileResponse> UploadXMLFile(UploadXMLFileRequest request, string Path);

        public Task<UploadCSVFileResponse> UploadCSVFile(UploadCSVFileRequest request, string Path);

        public Task<ReadRecordResponse> ReadRecord(ReadRecordRequest request);

        public Task<ReadRecordResponse> ReadRecords();

        public Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request);

        public Task<DeleteRecordResponse> DeleteAllRecords();

        public Task<DeleteRecordResponse> DeletebyId(int recordId);

        public Task<ReadRecord> GetIdByRecord(int id);

        public Task<ReadRecord> UpdateRecord(ReadRecord record);



    }
}
