﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface IUser
    {
        public Task<RegisterUserResponse> RegisterUser(RegisterUserRequest request);
        public Task<UserLoginResponse> UserLogin(UserLoginRequest request);
        public Task<AddInformationResponse> AddInformation(AddInformationRequest request);
        public Task<GetInformationResponse> GetInformation();
        public Task<UserAddressResponce> UserDetails(UserLoginResponse user);

    }
}
