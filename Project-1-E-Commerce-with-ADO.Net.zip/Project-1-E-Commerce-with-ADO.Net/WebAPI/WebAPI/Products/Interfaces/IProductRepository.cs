﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Core.Entities;

namespace WebAPI.Interfaces
{
    public interface IProductRepository
    {
        // brands
        Task<ProductBrand> AddBrand(ProductBrand request);
        Task<ProductBrandResponce> GetBrand(int id);
        Task<ProductBrandResponce> UpdateBrand(ProductBrand request);
        Task<ProductBrandResponce> DeleteBrand(int brandId);
        Task<List<ProductBrandResponce>> GetBrands();

        // types
        Task<ProductTypeResponce> AddType(ProductType request);
        Task<ProductTypeResponce> GetType(int id);
        Task<ProductTypeResponce> UpdateType(ProductType request);
        Task<ProductTypeResponce> DeleteType(int brandId);
        Task<List<ProductTypeResponce>> GetTypes();

        // Products
        Task<ProductResponce> AddProduct(Product request);
        Task<ProductResponce> UpdateProduct(Product request);
        Task<ProductResponce> DeleteProduct(int productId);


        Task<ProductResponce> GetProductByIdAsync(int id);
        Task<List<Products>> GetProductsAsync();
        //Task<IReadOnlyList<ProductResponce>> GetProductBrandsAsync();
        //Task<IReadOnlyList<ProductType>> GetProductTypesAsync();

        public Task<GetNoteResponse> GetProducts(GetProducts request);

        public Task<GetNoteResponse> SearchProducts(GetSearchNoteRequest request);

    }
}
