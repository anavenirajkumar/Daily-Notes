﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Core.Entities
{
    public class ProductType : BaseEntity
    {
        public string Name { get; set; }
    }

   /* public class ProductTypeResponce
    {

        public string Message { get; set; }
        public int Id { get; set; }
        public string Name { get; set; }

    }*/
}
