﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class RegisterUserRequest
    {
        [Required(ErrorMessage = "UserName Is Mandetory")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "Password Is Mandetory")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password Is Mandetory")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Email Is Mandetory")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Role Is Mandetory")]
        public string Role { get; set; } // Default Role is "User"

    }


    public static class Global
    {
        public static List<RegisterUserRequest> Users { get; set; } = new List<RegisterUserRequest>();

    }


    public class UserLoginRequest
    {
        [Required(ErrorMessage = "Email Is Mandetory")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password Is Mandetory")]
        public string Password { get; set; }
    }

    public class AddInformationRequest
    {
        //UserName, EmailID, MobileNumber, Salary, Gender
        [Required(ErrorMessage = "UserName Is Mandetory")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "EmailID Is Mandetory")]
        public string EmailID { get; set; }

        [Required(ErrorMessage = "MobileNumber Is Mandetory")]
        public int MobileNumber { get; set; }

        [Required(ErrorMessage = "Salary Is Mandetory")]
        public int Salary { get; set; }

        [Required(ErrorMessage = "Gender Is Mandetory")]
        public string Gender { get; set; }

    }
}
