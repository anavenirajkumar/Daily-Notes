﻿using ExcelDataReader;
using LumenWorks.Framework.IO.Csv;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Services
{
    public class UploadService : IUploadFile
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection __SqlConnection;
        public UploadService(IConfiguration configuration)
        {
            _configuration = configuration;
            __SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);
        }

        string connectionString = "Server=SBSLPT-34; Initial Catalog=MiniProject; user id=sa; password=sql@123;";

        public async Task<DeleteRecordResponse> DeleteRecord(DeleteRecordRequest request)
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {
                if (__SqlConnection.State != ConnectionState.Open)
                {
                    await __SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM Users WHERE UserID=@UserID";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection)) // (DeleteRecord, __SqlConnection)) -> DeleteRecord Query is Going to "SqlQueries.cs" class and After Going to "SqlQueries.xml" file. => Lenghty process and Extra Classes
                {
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserID", request.UserID);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        response.IsSuccess = false;
                        response.Message = "Delete Query Not Executed";
                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await __SqlConnection.CloseAsync();
                await __SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<ReadRecordResponse> ReadRecord(ReadRecordRequest request) // Get Data based on UI Pagination 
        {
            ReadRecordResponse response = new ReadRecordResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            int Count = 0;
            try
            {

                if (__SqlConnection.State != ConnectionState.Open)
                {
                    await __SqlConnection.OpenAsync();
                }

                // SqlQuery With Pagination

                /*string SqlQuery = @"SELECT DISTINCT UserId,  UserName,  EmailID,  MobileNumber,  Gender,  Age, Salary,  IsActive,
                                   (SELECT COUNT(*) FROM Users) AS TotalRecord FROM Users LIMIT @Offset, @RecordPerPage";*/

                string SqlQuery = @" SELECT * FROM Users order by UserId offset @Offset rows fetch next @RecordPerPage rows only";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection))// (ReadRecord, __SqlConnection)) 

                {
                    int Offset = (request.PageNumber - 1) * request.RecordPerPage;
                    sqlCommand.CommandType = CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Offset", Offset);
                    sqlCommand.Parameters.AddWithValue("@RecordPerPage", request.RecordPerPage);
                    using (SqlDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.readRecord = new List<ReadRecord>();
                            while (await dataReader.ReadAsync())
                            {
                                ReadRecord getdata = new ReadRecord();
                                getdata.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                                getdata.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                getdata.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                                getdata.Age = dataReader["Age"] != DBNull.Value ? Convert.ToInt32(dataReader["Age"]) : 0;
                                getdata.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToInt32(dataReader["Salary"]) : 0;
                                getdata.UserId = dataReader["UserId"] != DBNull.Value ? Convert.ToInt32(dataReader["UserId"]) : 0;
                                getdata.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                /*  if (Count == 0)
                                  {
                                      Count++;
                                      response.TotalRecords = dataReader["TotalRecord"] != DBNull.Value ? Convert.ToInt32(dataReader["TotalRecord"]) : 0;
                                      response.TotalPages = Convert.ToInt32(Math.Ceiling(Convert.ToDecimal(response.TotalRecords / request.RecordPerPage)));
                                      response.CurrentPage = request.PageNumber;
                                  }*/
                                response.readRecord.Add(getdata);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }


        public async Task<ReadRecordResponse> ReadRecords() // Get All Records
        {

            ReadRecordResponse response = new ReadRecordResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {
                if (__SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await __SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT *
                                    FROM Users";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;

                    using (SqlDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.readRecord = new List<ReadRecord>(); // User Based Redis Cache ->  new GetInformation();

                            while (await dataReader.ReadAsync()) // User Based Redis Cache -> use "if" Condition
                            {
                                ReadRecord getdata = new ReadRecord();
                                getdata.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                                getdata.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                getdata.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                                getdata.Age = dataReader["Age"] != DBNull.Value ? Convert.ToInt32(dataReader["Age"]) : 0;
                                getdata.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToInt32(dataReader["Salary"]) : 0;
                                getdata.UserId = dataReader["UserId"] != DBNull.Value ? Convert.ToInt32(dataReader["UserId"]) : 0;
                                getdata.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                response.readRecord.Add(getdata);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }


        public async Task<UploadCSVFileResponse> UploadCSVFile(UploadCSVFileRequest request, string Path)
        {
            UploadCSVFileResponse response = new UploadCSVFileResponse();
            List<ExcelBulkUploadParameter> Parameters = new List<ExcelBulkUploadParameter>();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {

                if (request.File.FileName.ToLower().Contains(".csv"))
                {

                    DataTable value = new DataTable();
                    //Install Package and Import : LumenWorksCsvReader 
                    using (var csvReader = new CsvReader(new StreamReader(File.OpenRead(Path)), true))
                    {
                        value.Load(csvReader);
                    };

                    for (int i = 0; i<value.Rows.Count; i++)
                    {
                        ExcelBulkUploadParameter readData = new ExcelBulkUploadParameter();
                        readData.UserName = value.Rows[i][0] != null ? Convert.ToString(value.Rows[i][0]) : "-1";
                        readData.EmailID = value.Rows[i][1] != null ? Convert.ToString(value.Rows[i][1]) : "-1";
                        readData.MobileNumber = value.Rows[i][2] != null ? Convert.ToString(value.Rows[i][2]) : "-1";
                        readData.Age = value.Rows[i][3] != null ? Convert.ToInt32(value.Rows[i][3]) : -1;
                        readData.Salary = value.Rows[i][4] != null ? Convert.ToInt32(value.Rows[i][4]) : -1;
                        readData.Gender = value.Rows[i][5] != null ? Convert.ToString(value.Rows[i][5]) : "-1";
                        Parameters.Add(readData);
                    }

                    if (Parameters.Count > 0)
                    {
                        if (ConnectionState.Open != __SqlConnection.State)
                        {
                            await __SqlConnection.OpenAsync();
                        }

                        string SqlQuery = @"INSERT INTO Users (UserName, EmailID, MobileNumber, Age, Salary, Gender) VALUES
                                           (@UserName, @EmailID, @MobileNumber, @Age, @Salary, @Gender)";

                        foreach (ExcelBulkUploadParameter rows in Parameters)
                        {
                            using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection)) // Replace -> SqlQueries.InsertBulkUploadData = SqlQuery
                            {
                                //UserName, EmailID, MobileNumber, Age, Salary, Gender
                                sqlCommand.CommandType = CommandType.Text;
                                sqlCommand.CommandTimeout = 180;
                                sqlCommand.Parameters.AddWithValue("@UserName", rows.UserName);
                                sqlCommand.Parameters.AddWithValue("@EmailID", rows.EmailID);
                                sqlCommand.Parameters.AddWithValue("@MobileNumber", rows.MobileNumber);
                                sqlCommand.Parameters.AddWithValue("@Age", rows.Age);
                                sqlCommand.Parameters.AddWithValue("@Salary", rows.Salary);
                                sqlCommand.Parameters.AddWithValue("@Gender", rows.Gender);
                                int Status = await sqlCommand.ExecuteNonQueryAsync();
                                if (Status <= 0)
                                {
                                    response.IsSuccess = false;
                                    response.Message = "Query Not Executed";
                                    return response;
                                }
                            }
                        }
                    }

                }
                else
                {
                    response.IsSuccess = false;
                    response.Message = "InValid File";
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await __SqlConnection.CloseAsync();
                await __SqlConnection.DisposeAsync();
            }
            return response;
        }

        public async Task<UploadXMLFileResponse> UploadXMLFile(UploadXMLFileRequest request, string path)
        {
            await DeleteAllRecords(); // Before Inserting Delete All Exist Records
            UploadXMLFileResponse response = new UploadXMLFileResponse();
            List<ExcelBulkUploadParameter> Parameters = new List<ExcelBulkUploadParameter>();
            DataSet dataSet;
            response.IsSuccess = true;
            response.Message = "Successful";

            try
            {

                if (request.File.FileName.ToLower().Contains(".xlsx"))
                {
                    FileStream stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
                    IExcelDataReader reader = ExcelReaderFactory.CreateReader(stream);
                    dataSet = reader.AsDataSet(
                        new ExcelDataSetConfiguration()
                        {
                            UseColumnDataType = false,
                            ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                            {
                                UseHeaderRow = true // XML File Header
                            }

                        });

                    for (int i = 0; i<dataSet.Tables[0].Rows.Count; i++)
                    {
                        ExcelBulkUploadParameter rows = new ExcelBulkUploadParameter();
                        rows.UserName = dataSet.Tables[0].Rows[i].ItemArray[0] != null ? Convert.ToString(dataSet.Tables[0].Rows[i].ItemArray[0]) : "-1";
                        rows.EmailID = dataSet.Tables[0].Rows[i].ItemArray[1] != null ? Convert.ToString(dataSet.Tables[0].Rows[i].ItemArray[1]) : "-1";
                        rows.MobileNumber = dataSet.Tables[0].Rows[i].ItemArray[2] != null ? Convert.ToString(dataSet.Tables[0].Rows[i].ItemArray[2]) : "-1";
                        rows.Age = dataSet.Tables[0].Rows[i].ItemArray[3] != null ? Convert.ToInt32(dataSet.Tables[0].Rows[i].ItemArray[3]) : -1;
                        rows.Salary = dataSet.Tables[0].Rows[i].ItemArray[4] != null ? Convert.ToInt32(dataSet.Tables[0].Rows[i].ItemArray[4]) : -1;
                        rows.Gender = dataSet.Tables[0].Rows[i].ItemArray[5] != null ? Convert.ToString(dataSet.Tables[0].Rows[i].ItemArray[5]) : "-1";
                        Parameters.Add(rows);
                    }

                    stream.Close();

                    if (Parameters.Count > 0)
                    {
                        if (ConnectionState.Open != __SqlConnection.State)
                        {
                            await __SqlConnection.OpenAsync();
                        }
                        string SqlQuery = @"INSERT INTO Users (UserName, EmailID, MobileNumber, Age, Salary, Gender) VALUES
                                        (@UserName, @EmailID, @MobileNumber, @Age, @Salary, @Gender)";

                        foreach (ExcelBulkUploadParameter rows in Parameters)
                        {
                            using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection)) // (InsertBulkUploadData, __SqlConnection)) 
                            {
                                //UserName, EmailID, MobileNumber, Age, Salary, Gender
                                /*  sqlCommand.CommandType = CommandType.Text;
                                  sqlCommand.CommandTimeout = 180;*/
                                sqlCommand.CommandType = System.Data.CommandType.Text;
                                sqlCommand.CommandTimeout = 180;
                                sqlCommand.Parameters.AddWithValue("@UserName", rows.UserName);
                                sqlCommand.Parameters.AddWithValue("@EmailID", rows.EmailID);
                                sqlCommand.Parameters.AddWithValue("@MobileNumber", rows.MobileNumber);
                                sqlCommand.Parameters.AddWithValue("@Age", rows.Age);
                                sqlCommand.Parameters.AddWithValue("@Salary", rows.Salary);
                                sqlCommand.Parameters.AddWithValue("@Gender", rows.Gender);
                                int Status = await sqlCommand.ExecuteNonQueryAsync();
                                if (Status <=0)
                                {
                                    response.IsSuccess = false;
                                    response.Message = "Query Not Executed";
                                    return response;
                                }
                            }
                        }
                    }

                }
                else
                {
                    response.IsSuccess = false;
                    response.Message = "Invalid File";
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await __SqlConnection.CloseAsync();
                await __SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<DeleteRecordResponse> DeleteAllRecords()
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            response.IsSuccess = true;
            response.Message = "Successful";
            try
            {

                string SqlQuery = @"DELETE FROM Users";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand(SqlQuery, con);
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    cmd.CommandTimeout = 180;
                    int Status = await cmd.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        response.IsSuccess = false;
                        response.Message = "Delete Query Not Executed";
                        return response;
                    }
                    con.Close();
                }
            }

            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return response;
        }

        public async Task<DeleteRecordResponse> DeletebyId(int recordId)
        {
            DeleteRecordResponse response = new DeleteRecordResponse();
            response.Message = "Record Deleted";

            try
            {
               
                if (ConnectionState.Open != __SqlConnection.State)
                {
                    await __SqlConnection.OpenAsync();
                }

                string SqlQuery = @"DELETE FROM Users WHERE UserId = " + recordId;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Message = "Record Delete Successful";
                            return response;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await __SqlConnection.CloseAsync();
                await __SqlConnection.DisposeAsync();
            }

            return response;
        }

      

        public async Task<ReadRecord> GetIdByRecord(int id)
        {
            ReadRecordResponse response = new ReadRecordResponse();
            response.Message = "Get User";
            ReadRecord res = new ReadRecord();
            try
            {
                if (__SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await __SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT UserId, UserName, EmailID, MobileNumber, Gender, Age, Salary FROM Users WHERE UserId = " + id;

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = "Get User Successful";
                            res.UserId = Convert.ToInt32(dataReader["UserId"]);
                            res.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                            res.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                            res.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                            res.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                            res.Age =  Convert.ToInt32(dataReader["Age"]);
                            res.Salary =  Convert.ToInt32(dataReader["Salary"]);
                            return res;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                response.Message = ex.Message;
            }
            finally
            {
                await __SqlConnection.CloseAsync();
                await __SqlConnection.DisposeAsync();
            }

            return res;
        }

        public async Task<ReadRecord> UpdateRecord(ReadRecord record)
        {
            var recordId = Convert.ToInt32(record.UserId);
            string recordName = record.UserName;

            ReadRecord response = new ReadRecord();
            try
            {

                if (__SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await __SqlConnection.OpenAsync();
                }

                if (recordId == null)
                {
                    return null;
                }

                string SqlQuery = @"UPDATE Users SET UserName = @UserName, EmailID = @EmailID, MobileNumber= @MobileNumber, Gender = @Gender, Age = @Age, Salary = @Salary WHERE UserId = " + recordId;



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, __SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserId", recordId);
                    sqlCommand.Parameters.AddWithValue("@UserName", recordName);
                    sqlCommand.Parameters.AddWithValue("@EmailID", record.EmailID);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", record.MobileNumber);
                    sqlCommand.Parameters.AddWithValue("@Gender", record.Gender);
                    sqlCommand.Parameters.AddWithValue("@Age", record.Age);
                    sqlCommand.Parameters.AddWithValue("@Salary", record.Salary);

                    response.UserId = Convert.ToInt32(recordId);
                    response.UserName = recordName;
                    response.EmailID = record.EmailID;
                    response.MobileNumber = record.MobileNumber;
                    response.Gender = record.Gender;
                    response.Age = record.Age;
                    response.Salary = record.Salary;

                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                throw;         
             }
            finally
            {
                await __SqlConnection.CloseAsync();
                await __SqlConnection.DisposeAsync();
            }

            return response;
        }
    }
}
