﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Services
{
    public class UserService : IUser
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        public UserService(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);
        }

        public async Task<RegisterUserResponse> RegisterUser(RegisterUserRequest request)
        {


            RegisterUserResponse response = new RegisterUserResponse();
            response.IsSuccess = true;
            response.Message = "SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (request.Password != request.ConfirmPassword)
                {
                    response.IsSuccess = false;
                    response.Message = "Password Not Match";
                    return response;
                }

                // Check Register Email is Already Exist Query
                string Sql = @"SELECT Email  
                                    FROM registerUser
                                    WHERE Email=@Email";

                string alreadyEmail; //

                UserLoginResponse responseUser = new UserLoginResponse();

                using (SqlCommand sqlCommand = new SqlCommand(Sql, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            responseUser.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                            alreadyEmail = responseUser.Email; //
                            response.IsSuccess = false;
                            response.Message = "User Is Already Registered";

                        }
                        else
                        {
                            alreadyEmail = null;
                        }
                    }

                }


                if (alreadyEmail == null) // if null Create New Register User
                {
                    request.Password = BCrypt.Net.BCrypt.HashPassword(request.Password);

                    string SqlQuery = @"INSERT INTO  registerUser 
                                    (UserName, PassWord, Role, Email) Values 
                                    (@UserName, @PassWord, @Role, @Email);";

                    using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                    {
                        sqlCommand.CommandType = System.Data.CommandType.Text;
                        sqlCommand.CommandTimeout = 180;
                        sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                        sqlCommand.Parameters.AddWithValue("@PassWord", request.Password);
                        sqlCommand.Parameters.AddWithValue("@Role", request.Role);
                        sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                        int Status = await sqlCommand.ExecuteNonQueryAsync();
                        if (Status <= 0)
                        {
                            response.IsSuccess = false;
                            response.Message = "Register Query Not Executed";
                            return response;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<UserLoginResponse> UserLogin(UserLoginRequest request)
        {
            UserLoginResponse response = new UserLoginResponse();
            response.IsSuccess = true;
            response.Message = "Login SuccessFul";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT UserId, UserName, Role, Village, Mandal, District, Email, Password
                                    FROM registerUser
                                    WHERE Email=@Email";

                // bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, SqlQuery);
                /* if (isValidPassword) { 

                 }*/

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@Email", request.Email);
                    sqlCommand.Parameters.AddWithValue("@PassWord", request.Password);
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            await dataReader.ReadAsync();
                            response.Message = "Login Successful";
                            /*                            response.data = new UserLoginInformation();
                            */
                            response.UserID = dataReader["UserId"] != DBNull.Value ? Convert.ToString(dataReader["UserId"]) : string.Empty;
                            response.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                            response.Role = dataReader["Role"] != DBNull.Value ? Convert.ToString(dataReader["Role"]) : string.Empty;
                            response.Email = dataReader["Email"] != DBNull.Value ? Convert.ToString(dataReader["Email"]) : string.Empty;
                            response.Password = dataReader["Password"] != DBNull.Value ? Convert.ToString(dataReader["Password"]) : string.Empty;
                            response.Village = dataReader["Village"] != DBNull.Value ? Convert.ToString(dataReader["Village"]) : string.Empty;
                            response.Mandal = dataReader["Mandal"] != DBNull.Value ? Convert.ToString(dataReader["Mandal"]) : string.Empty;
                            response.District = dataReader["District"] != DBNull.Value ? Convert.ToString(dataReader["District"]) : string.Empty;
                            bool isValidPassword = BCrypt.Net.BCrypt.Verify(request.Password, response.Password);
                            if (isValidPassword)
                            {
                                response.Token = GenerateJwt(response.UserID, response.UserName, response.Role);
                                return response;
                            }
                            else
                            {
                                response = null;
                            }
                        }
                        else
                        {
                            response.IsSuccess = false;
                            response.Message = "Login Unsuccessful";
                            return response;
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<AddInformationResponse> AddInformation(AddInformationRequest request)
        {
            AddInformationResponse response = new AddInformationResponse();
            ///response.IsSuccess = true;
            response.Message = "User Created SuccessFul";

            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"INSERT INTO userInformation
                                    (UserName, EmailID, MobileNumber, Salary, Gender) Values
                                    (@UserName, @EmailID, @MobileNumber, @Salary, @Gender)";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    //UserName, EmailID, MobileNumber, Salary, Gender
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserName", request.UserName);
                    sqlCommand.Parameters.AddWithValue("@EmailID", request.EmailID);
                    sqlCommand.Parameters.AddWithValue("@MobileNumber", request.MobileNumber);
                    sqlCommand.Parameters.AddWithValue("@Salary", request.Salary);
                    sqlCommand.Parameters.AddWithValue("@Gender", request.Gender);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.IsSuccess = false;
                        response.Message = "AddInformation Query Not Executed";
                        return response;
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<GetInformationResponse> GetInformation()
        {
            GetInformationResponse response = new GetInformationResponse();
            response.IsSuccess = true;
            response.Message = "SuccessFul";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM userInformation";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.getInformation = new List<GetInformation>();

                            while (await dataReader.ReadAsync())
                            {
                                GetInformation data = new GetInformation();

                                data.UserName = dataReader["UserName"] != DBNull.Value ? Convert.ToString(dataReader["UserName"]) : string.Empty;
                                data.EmailID = dataReader["EmailID"] != DBNull.Value ? Convert.ToString(dataReader["EmailID"]) : string.Empty;
                                data.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                data.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                                data.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                //data.IsActive = dataReader["IsActive"] != DBNull.Value ? Convert.ToBoolean(dataReader["IsActive"]) : false;

                                response.getInformation.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public string GenerateJwt(string UserID, string Email, string Role)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            //claim is used to add identity to JWT token
            var claims = new[] {
         new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
         new Claim(JwtRegisteredClaimNames.Sid, UserID),
         new Claim(JwtRegisteredClaimNames.Email, Email),
         new Claim(ClaimTypes.Role,Role),
         new Claim("Date", DateTime.Now.ToString()),
         };

            var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
              _configuration["Jwt:Audiance"],
              claims,    //null original value
              expires: DateTime.Now.AddMinutes(1), // 120

              //notBefore:
              signingCredentials: credentials);

            string Data = new JwtSecurityTokenHandler().WriteToken(token); //return access token 
            return Data;
        }

        /* public async Task<UserAddressResponce> UserDetails(UserLoginInformation user, UserAddress address)
         {

         }*/

        public async Task<UserAddressResponce> UserDetails(UserLoginResponse user)
        {
            var UserID = Int16.Parse(user.UserID);
            string UserName = user.UserName;

            UserAddressResponce response = new UserAddressResponce();
            //response.IsSuccess = true;
            response.Message = "Address Updated SuccessFul";
            try
            {

                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                if (UserID == null)
                {
                    return null;
                }

                /* string SqlQuery = @" SELECT UserId from registerUser WHERE UserId=UserId AND INSERT INTO registerUser
                                     (Village, Mandal, District) Values 
                                     (@Village, @Mandal, @District)";*/

                string SqlQuery = @"UPDATE registerUser SET Village = @Village, Mandal = @Mandal, District = @District WHERE UserId = @UserID";



                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@UserId", UserID);
                    sqlCommand.Parameters.AddWithValue("@Village", user.Village);
                    sqlCommand.Parameters.AddWithValue("@Mandal", user.Mandal);
                    sqlCommand.Parameters.AddWithValue("@District", user.District);
                    int Status = await sqlCommand.ExecuteNonQueryAsync();
                    if (Status <= 0)
                    {
                        //response.IsSuccess = false;
                        response.Message = "Address Not Successfully";
                        return null;
                    }
                }

            }
            catch (Exception ex)
            {
                //response. = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;

        }
    }
}
