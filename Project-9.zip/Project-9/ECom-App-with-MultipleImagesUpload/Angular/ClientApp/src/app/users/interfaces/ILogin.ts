export interface ILogin {
    email : string,
    password : string
}

export interface IUser {
    userID: string,
    userName: string,
    email : string,
    role: string,
    isSuccess : string,
    password : string,
    token : string,
    message : string,
    village : string,
    mandal : string,
    district : string,
    lastLogin : string
}