import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ILogin } from '../interfaces/ILogin';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public user:ILogin = {
    email : '',
    password : ''
  }
  public loginForm: FormGroup | any;

  constructor(private formBuilder : FormBuilder,
       private loginService : UserService,
       private router : Router
      ) { }

 async ngOnInit() {
  this.loginForm = this.formBuilder.group({
    email : ['anaveni.rajkumar1@gmail.com', [Validators.required, Validators.email]], //anaveni.rajkumar1@gmail.com
    password : ['Rajkumar1@', [Validators.required, Validators.minLength(5)]] // Rajkumar1@
    // Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{8,}$')]
  })
  let token = await this.loginService.getToken();
  if(token){
    this.router.navigateByUrl('/users/user-profile');
  } else{
     this.router.navigateByUrl('/users/login');
  }
  }

  loginUser(){
    this.loginForm.markAllAsTouched();
    if(this.loginForm.valid){
      console.log(this.loginForm)
      this.user.email = this.loginForm.value.email
      this.user.password = this.loginForm.value.password
      this.loginService.login(this.user).subscribe((responce)=>{  
        console.log(responce);
        console.log(responce.token);
        let Admin = this.loginService.AdminUser();
        console.log(Admin.role);
        if(Admin.role === 'Admin'){
          this.router.navigate(['/admin']);
        } else if(Admin.userID !== null ){
          this.router.navigate(['/users/user-profile']);
        }
        else{
          localStorage.removeItem('token');
          localStorage.removeItem('userDetails');
          this.router.navigate(['/users/login']);
        }
      }, err => {
        console.log(err);
        localStorage.removeItem('token');
        localStorage.removeItem('userDetails');
      })
    }
  }
}
