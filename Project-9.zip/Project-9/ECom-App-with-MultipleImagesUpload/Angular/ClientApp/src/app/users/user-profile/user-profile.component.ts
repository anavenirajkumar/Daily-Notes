import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  public userInfo  = this.userService.userInfomation();

  public addressForm:FormBuilder | any;
  public enableAddress : boolean = false;

  constructor(private router : Router,
             private formBuilder : FormBuilder,
             private userService : UserService) { }

  ngOnInit() {
    this.addressForm = this.formBuilder.group({
        village : ['', Validators.required],
        mandal : ['', Validators.required],
        district : ['', Validators.required]
    })  
  }


  submitUpdateAddress(){
       this.userService.updateUserAddress(this.userInfo).subscribe((response) => {
         console.log(response);
         this.enableAddress = false;
         localStorage.setItem('userDetails',JSON.stringify(this.userInfo));     
      })
    }

    public logout(){
      localStorage.removeItem('token');
      localStorage.removeItem('userDetails');
    }
    
  }


  

  
