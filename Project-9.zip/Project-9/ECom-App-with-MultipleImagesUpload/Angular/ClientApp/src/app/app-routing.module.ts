import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { AdminGuard } from './users/guards/admin.guard';

const routes: Routes = [
  {path : '', redirectTo :'', pathMatch : 'full'},
  { path: 'shop', loadChildren: () => import('./shop/shop.module').then(m => m.ShopModule) }, 
  { path: 'users', loadChildren: () => import('./users/users.module').then(m => m.UsersModule) },
  { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule), canActivate : [AdminGuard] }, 
  { path: '**', component: PagenotfoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
