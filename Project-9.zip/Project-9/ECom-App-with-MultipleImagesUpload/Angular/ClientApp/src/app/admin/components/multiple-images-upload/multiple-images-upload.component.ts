import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { ShopService } from 'src/app/shop/services/shop.service';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-multiple-images-upload',
  templateUrl: './multiple-images-upload.component.html',
  styleUrls: ['./multiple-images-upload.component.css']
})
export class MultipleImagesUploadComponent implements OnInit {

  public user:any = {
    id : 0,
    name : '',
    city : '',
    country : '',
    age : null,
    address : '',
    userImages:[]
  }
  public data:any = {
    userData : [],
    userImages : []
  }
  constructor(private userService:UserService) { }

  ngOnInit(): void {
    this.getUser();
  }

  public profilePhotos(event:any){
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
         const fileName = event.target.files[i].name.slice(0, event.target.files[i].name.lastIndexOf('.'));
         const timeStamp = moment().format('MMDDYYYY hh:mm:ss A');
         const fileExtension = event.target.files[i].name.substring(event.target.files[i].name.lastIndexOf('.'));
         const imageUrl = fileName.concat('_', timeStamp, fileExtension);
         const updatedFile = new File([event.target.files[i]], imageUrl, { type: event.target.files[i].type });
         var reader = new FileReader();
            reader.onload = (event:any) => {
            console.log(event.target.result);
            this.user.userImages.push({ id : 0, imageFile: updatedFile, imageurl: imageUrl, image : event.target.result, type : updatedFile.type }); 
         }
       reader.readAsDataURL(event.target.files[i]);
      }
  }

  //   for(let file of event.target.files){
  //     // if (file.name.toLowerCase().endsWith('.png') || file.name.toLowerCase().endsWith('.jpg')
  //     // || file.name.toLowerCase().endsWith('.jpeg') || file.name.toLowerCase().endsWith('.pdf')) {
  //     var reader = new FileReader();
  //     const fileName = file.name.slice(0, file.name.lastIndexOf('.'));
  //     const timeStamp = moment().format('MMDDYYYY hh:mm:ss A');
  //     const fileExtension = file.name.substring(file.name.lastIndexOf('.'));
  //     const imageUrl = fileName.concat('_', timeStamp, fileExtension);
  //     const updatedFile = new File([file], imageUrl, { type: file.type });
  //     reader.onload = (event:any) => {
  //       this.user.userImages.push({ id : 0, imageFile: updatedFile, imageurl: imageUrl, image : event.target.result }); 
  //      }
  //     //this.user.userImages.push({ id : 0, imageFile: updatedFile, imageurl: imageUrl, image : event.target.result });

  //   //}
  // }

  }

public removeProfilePhotos(){
  this.user.userImages = [];
  console.log(this.user.userImages);
}

public SelectedProfileImage(imageId:any){
let imageIndex = this.user.userImages.findIndex((e:any) => e.id === imageId);
this.user.userImages.splice(imageIndex,1);
console.log(this.user.userImages);

}

public submitUserDetails(){
  let age:number = +this.user.age;
  this.user.age = age;
  console.log(this.user); 
  let formData = this.createForm();
  this.userService.uploadUser(formData).subscribe((res) => {
   console.log(res);
   this.getUser();
   this.user = {};
   this.user.userImages = [];
  }, err => {
    console.log(err);
  });

}
public getUser(){
  this.userService.getUsers().subscribe((res:any) => {
   this.data.userData = res.users;
   this.data.userImages = res.userImages;
   console.log(res);
   console.log(res.users);
  });
}

public deleteUser(id:any){
  console.log(id); 
  this.userService.deleteUser(id).subscribe((res:any) => {
    console.log(res);
    this.getUser();
  }, err => {
    console.log(err);
  })
  }

  public createForm() :FormData{
    const formData = new FormData();
    formData.append('id', this.user.id);
    formData.append('name', this.user.name);
    formData.append('address',this.user.address);
    formData.append('age', this.user.age);
    formData.append('city',this.user.city);
    formData.append('country',this.user.country);
    if (this.user.userImages != null) {
      this.user.userImages.forEach((x:any, i:any) => {
          formData.append(`userImages[${i}][imageId]`, i);
          formData.append(`userImages[${i}][imagetype]`, x.type.toString());
          formData.append(`imageFiles`, x.imageFile);
          formData.append(`userImages[${i}][image]`, x.image);
          formData.append(`userImages[${i}][name]`, x.imageurl);
      });
  }
  return formData;
  }
}
