import { Component, OnInit } from '@angular/core';
import { ShopService } from 'src/app/shop/services/shop.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  public brands:any = [];
  public filteredBrands:any = []
  public types:any = [];
  public products:any = [];
  public product:any = {
    id: null,
    name : '',
    description : '',
    price : null,
    pictureUrl : '',
    productTypeId : 0,
    productBrandId : 0
  }
  constructor(private shopService:ShopService) { }

  ngOnInit(): void {
     this.getTypes();
     this.getBrands();
     this.getProducts();
  }

  public getTypes(){
    this.shopService.getTypes().subscribe((res)=> {
      this.types = res;
    })
  }
  public getBrands(){
    this.shopService.getBrands().subscribe((res)=> {
      this.brands = res;
    })
  }

  public addProduct(){
    this.product.id = 0;
    let price:number = +this.product.price;
    let typeId:number = +this.product.productTypeId;
    let brandId:number = +this.product.productBrandId;
    this.product.price = price;
    this.product.productTypeId = typeId;
    this.product.productBrandId = brandId;
    console.log(this.product);
    if(this.product.name != "" && this.product.description != "" && this.product.price != 0 && this.product.pictureUrl != "" && this.product.productTypeId != 0 && this.product.productBrandId !=0){
      this.shopService.addProduct(this.product).subscribe((res) => {
        console.log(res);
        this.product.name = '';
        this.product.price = null;
        this.product.description = '';
        this.product.pictureUrl = '';
        this.product.productBrandId = 0;
        this.product.productTypeId = 0;
        this.getProducts();
      })
    }
  }

  public uploadImage(event:any){
    if (event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
              var reader = new FileReader();
              reader.onload = (event:any) => {
                console.log(event.target.result);
                this.product.pictureUrl = event.target.result;
              }
              reader.readAsDataURL(event.target.files[i]);
      }
    }
  }

  public removeImage(){
    this.product.pictureUrl = "";
  }

  public getProducts(){
    this.shopService.onlyProducts().subscribe((res) => {
       this.products = res;
    })
  }

  public deleteProduct(id:any){
    this.shopService.deleteProduct(id).subscribe((res)=> {
      console.log(res);
      this.getProducts();
    })
  }

  public changeCategory(id:any){
    let categoryId:number = +id;
    this.filteredBrands = this.brands.filter((e:any)=> e.productTypeId === categoryId);
    console.log(this.filteredBrands);
  }
}
