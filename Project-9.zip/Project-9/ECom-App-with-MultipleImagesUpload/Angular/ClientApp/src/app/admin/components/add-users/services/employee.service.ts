import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IDesignation, IEmployee } from '../models/IEmployee';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private httpClient : HttpClient) { }

  employeeUrl:string = 'http://localhost:13839/api/Employee';
  designationUrl:string = 'http://localhost:13839/api/Designation';

  public listEmployee:IEmployee[] = []; // for getting data EmployeeList
  public listDesignation:IDesignation[] = []; // for getting data DesignationList

  public employeeData:IEmployee = new IEmployee(); // for post data / insert data
  public employee:any;

  public saveEmployee(){
    return this.httpClient.post(this.employeeUrl, this.employeeData);
  }

 

  public updateEmployee(){
    return this.httpClient.put(`${this.employeeUrl}/${this.employeeData.id}`, this.employeeData);
  }

  public getEmployees():Observable<IEmployee[]>{
    return this.httpClient.get<IEmployee[]>(this.employeeUrl);
  }

  public getDesignations():Observable<IDesignation[]>{
    return this.httpClient.get<IDesignation[]>(this.designationUrl);
  }

  public deleteEmployee(id:number){  // `` -> tilt
    return this.httpClient.delete(`${this.employeeUrl}/${id}`);
  }

  
  public saveEmp(){
    return this.httpClient.post(this.employeeUrl, this.employee);
  }
  public updateEmp(){
    return this.httpClient.put(`${this.employeeUrl}/${this.employee.id}`, this.employee);
  }

}
