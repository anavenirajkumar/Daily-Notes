export enum Role{
    GUEST = 'guest',
    USER  = 'user',
    ADMIN = 'admin'
}