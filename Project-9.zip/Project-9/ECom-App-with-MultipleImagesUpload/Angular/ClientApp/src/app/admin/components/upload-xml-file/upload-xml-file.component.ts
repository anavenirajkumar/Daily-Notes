import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-upload-xml-file',
  templateUrl: './upload-xml-file.component.html',
  styleUrls: ['./upload-xml-file.component.css']
})
export class UploadXmlFileComponent implements OnInit {

  public upload:any = {
    File: new FormData(),
    //UploadFile: false,
    //FileExtension: '',
    
    // RecordPerPage: 4,
    // PageNumber: 1,
    // currentPage: 1,
    // totalRecords: 0,
    // totalPages: 0,

  }

  public DataRecords : any;


  public myForm : any;
  public url:string = '';
  constructor(private uploadService : UserService) { }

  ngOnInit() {
    //this.callEveryHour();
    this.url = "https://localhost:44314/api/User/GetUsers/Download";
    this.getData();
    this.myForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.minLength(3)]),
      file: new FormControl('', [Validators.required]),
      fileSource: new FormControl('', [Validators.required])
    });
  }


  public getData(){
    this.uploadService.getData().subscribe((res) => {
       this.DataRecords = res;
       console.log(res);
    })
  }

  public deleteRecord(recordId:any){
    let recordID : number = +recordId;
    console.log(typeof(recordID));
      this.uploadService.deleteRecord(recordID).subscribe((res)=> {
        console.log(res);
        this.getData();
      })
  }
  // addProduct(){
  //   const formData = new FormData();
  //   formData.append('file', this.upload.File);
  //   this.uploadService.upload(formData).subscribe((res) => {
  //         console.log(res);
  //    })
  // }

/////////////////////////////////////////////////

  // public selectProductImage(files:any){
  //   if (files.target.files.length > 0) {
  //     const file = files.target.files[0];
  //     this.upload.File = file;
  //   }
  // }

  // public automaticallyRunOneMinute(){
  //      console.log("Every Minute Im Running");
  // }

  // public callEveryHour() {
  //   setInterval(this.automaticallyRunOneMinute, 1000 * 1 * 60); // 1 Minute * 60 Seconds = Every One Minute
  // }


///////////////////////////////////////////////////
get f(){
  return this.myForm.controls;
}
   
onFileChange(event:any) {
 console.log(event);
 console.log(event.target.value);

  if (event.target.files.length > 0) {
    const file = event.target.files[0]; 
    console.log(file);
    this.myForm.patchValue({
      fileSource: file
    });
  }
}
   
submit(){
  this.myForm.markAllAsTouched();
   if(this.myForm.valid){
    const formData = new FormData();
    formData.append('file', this.myForm.get('fileSource').value);
      console.log("Submitted Successfully");
      this.uploadService.upload(formData).subscribe((res) => {
        console.log(res);
        alert("XML File Submitted Successfully");
        this.getData();
   })
   }
  }

}
