import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ShopService } from 'src/app/shop/services/shop.service';

@Component({
  selector: 'app-update-type',
  templateUrl: './update-type.component.html',
  styleUrls: ['./update-type.component.css']
})
export class UpdateTypeComponent implements OnInit {

  public type:any = {
    id : 0,
    name : ''
   }
  public typeId:any;
  constructor(private router:ActivatedRoute, 
             private shopService:ShopService,
             private route: Router) { }

  ngOnInit(): void {
    this.router.paramMap.subscribe((id)=> {
      this.typeId = id.get('id');
      this.getBrandById(this.typeId)
    })
  }

  public getBrandById(typeId:any){
    this.shopService.getType(typeId).subscribe((res) => {
      this.type = res;
      console.log(res);
    })
  }
  public updateType(){
     this.shopService.updateType(this.type).subscribe((res) => {
      console.log(res);
      this.route.navigateByUrl('/admin/type');
     })
  }

}
