import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminGuard } from '../users/guards/admin.guard';
import { AdminComponent } from './admin.component';
import { Role } from './authroles/roles';
import { AddBrandComponent } from './components/add-brand/add-brand.component';
import { AddProductComponent } from './components/add-product/add-product.component';
import { AddTypeComponent } from './components/add-type/add-type.component';
import { AddUsersComponent } from './components/add-users/add-users.component';
import { AddCategoryComponent } from './components/category-controlller/add-category/add-category.component';
import { AddProductCateComponent } from './components/category-controlller/add-product-cate/add-product-cate.component';
import { ProductCatIdComponent } from './components/category-controlller/add-product-cate/product-cat-id/product-cat-id.component';
import { AddSubCategoryComponent } from './components/category-controlller/add-sub-category/add-sub-category.component';
import { EditMultipleImagesComponent } from './components/edit-multiple-images/edit-multiple-images.component';
import { MultipleImagesEditComponent } from './components/multiple-images-edit/multiple-images-edit.component';
import { MultipleImagesUploadComponent } from './components/multiple-images-upload/multiple-images-upload.component';
import { UpdateBrandComponent } from './components/update-brand/update-brand.component';
import { UpdateProductComponent } from './components/update-product/update-product.component';
import { UpdateTypeComponent } from './components/update-type/update-type.component';
import { UploadMultipleImagesComponent } from './components/upload-multiple-images/upload-multiple-images.component';
import { IdComponent } from './components/upload-xml-file/id/id.component';
import { UploadXmlFileComponent } from './components/upload-xml-file/upload-xml-file.component';

const routes: Routes = [
  { path: '', component: AdminComponent , canActivate : [AdminGuard], data : { roles: [Role.ADMIN], pageTitle : 'Admin Page'}}, // extra features
  { path : 'brand', component : AddBrandComponent, canActivate : [AdminGuard]},
  { path : 'brand/:id', component : UpdateBrandComponent, canActivate : [AdminGuard]},
  { path : 'type', component : AddTypeComponent, canActivate : [AdminGuard]},
  { path : 'type/:id', component : UpdateTypeComponent, canActivate : [AdminGuard]},
  { path : 'product', component : AddProductComponent, canActivate : [AdminGuard]},
  { path : 'product/:id', component : UpdateProductComponent, canActivate : [AdminGuard]},
  {path : 'uploadxmlfile', component : UploadXmlFileComponent, canActivate : [AdminGuard]},
  {path : 'xmlfiles/:id', component : IdComponent, canActivate : [AdminGuard]},
  {path : 'addUsers', component : AddUsersComponent, canActivate : [AdminGuard]},
  {path : 'category', component : AddCategoryComponent, canActivate : [AdminGuard]},
  {path : 'sub-category', component : AddSubCategoryComponent, canActivate : [AdminGuard]},
  {path : 'category/product', component : AddProductCateComponent, canActivate : [AdminGuard]},
  {path : 'category/product/:id', component : ProductCatIdComponent, canActivate : [AdminGuard]},
  //{path : 'addUsers', component : AddUsersComponent, canActivate : [AdminGuard]},
  {path : 'multiple-images-upload', component : MultipleImagesUploadComponent},
  {path : 'multiple-images-edit/:id', component : MultipleImagesEditComponent},
  {path : 'upload-multiple-images', component : UploadMultipleImagesComponent},
  {path : 'edit-multiple-images/:id', component : EditMultipleImagesComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
