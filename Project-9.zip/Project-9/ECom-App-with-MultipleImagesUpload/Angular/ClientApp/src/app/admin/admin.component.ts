import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../users/services/user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public pageTitle:any;
  constructor(private route:ActivatedRoute, private userService:UserService) { }

  ngOnInit(): void { 
    //let user = this.userService.AdminUser();
    this.route.data.subscribe(data => {
      switch (data['pageTitle']){
          case 'Admin Page':
              this.pageTitle = 'AdminPage';
              break;
      }
  });
  console.log("Dynamic Routing", this.pageTitle);
  }

}
