import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { UserService } from 'src/app/users/services/user.service';

@Component({
  selector: 'app-multiple-images-edit',
  templateUrl: './multiple-images-edit.component.html',
  styleUrls: ['./multiple-images-edit.component.css']
})
export class MultipleImagesEditComponent implements OnInit {

  public userId:any;
  public user:any = {
     id : 0,
     name : '',
     age : 0,
     address : '',
     city : '',
     country : '',
     userImages : []
  }
  constructor(private snapShot:ActivatedRoute, private userService:UserService, private router : Router) { }

  ngOnInit(): void {
    this.snapShot.paramMap.subscribe((id)=> {
      this.userId = id.get('id');
      this.getUser(this.userId);
    })
  }

  public getUser(id:any){
     this.userService.getUserId(id).subscribe((res:any) =>{
       this.user = res;
       console.log(this.user);
     })
  }
  
   public removeSelectedImage(obj:any){
    let imageId = obj.imageId;
    let imageIndex = this.user.userImages.findIndex((ele:any) => ele.imageId === imageId);
    this.user.userImages.splice(imageIndex,1);
    this.userService.deleteSpecificImage(imageId).subscribe((res)=> {
      console.log(res);
    }, err => {
      console.log(err);
    })
   }

  //  public profilePhotos(event:any){
  //   if (event.target.files && event.target.files[0]) {
  //     var filesAmount = event.target.files.length;
  //     for (let i = 0; i < filesAmount; i++) {
  //             var reader = new FileReader();
  //             let imageName = event.target.files[i].name;
  //               reader.onload = (event:any) => {
  //                 console.log(event.target.result);
  //                  this.user.userImages.push({ name : imageName, image : event.target.result}); 
  //               }
  //             reader.readAsDataURL(event.target.files[i]);
  //             //console.log(event.target.files[i].name);
  //     }
  // }
  // console.log(this.user.userImages);
  
  // }

  public profilePhotos(event:any){
    if (event.target.files && event.target.files[0]) {
      var filesAmount = event.target.files.length;
      for (let i = 0; i < filesAmount; i++) {
         const fileName = event.target.files[i].name
        // const fileName = event.target.files[i].name.slice(0, event.target.files[i].name.lastIndexOf('.'));
         const timeStamp = moment().format('MMDDYYYY hh:mm:ss A');
         const fileExtension = event.target.files[i].name.substring(event.target.files[i].name.lastIndexOf('.'));
        // const imageUrl = fileName.concat('_', timeStamp, fileExtension);
         const updatedFile = new File([event.target.files[i]], fileName, { type: event.target.files[i].type });
         var reader = new FileReader();
            reader.onload = (event:any) => {
            console.log(event.target.result);
            this.user.userImages.push({ id : 0, imageFile: updatedFile, imageurl: fileName, image : event.target.result, type : updatedFile.type }); 
         }
       reader.readAsDataURL(event.target.files[i]);
      }
  }
}

  public UpdateUser(){
    let age:number = +this.user.age;
    this.user.age = age;
    //console.log(this.user); return;
    let formData = this.createForm();
     this.userService.uploadUser(formData).subscribe((res) => {
      console.log(res);
     }, err => {
      console.log(err);
     });
     this.router.navigateByUrl('/admin/multiple-images-upload');
  }

  public createForm() :FormData{
    const formData = new FormData();
    formData.append('id', this.user.id);
    formData.append('name', this.user.name);
    formData.append('address',this.user.address);
    formData.append('age', this.user.age);
    formData.append('city',this.user.city);
    formData.append('country',this.user.country);
    if (this.user.userImages != null) {
      this.user.userImages.forEach((x:any, i:any) => {
          formData.append(`userImages[${i}][imageId]`, i);
          formData.append(`userImages[${i}][imagetype]`, x.type ? x.type.toString() : "");
          formData.append(`imageFiles`, x.imageFile);
          formData.append(`userImages[${i}][image]`, x.image);
          formData.append(`userImages[${i}][name]`, x.imageurl ? x.imageurl : x.name);
      });
  }
  return formData;
  }
}
