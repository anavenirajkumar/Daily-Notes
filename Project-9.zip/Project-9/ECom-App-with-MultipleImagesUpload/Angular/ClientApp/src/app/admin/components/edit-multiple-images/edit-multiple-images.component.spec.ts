import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditMultipleImagesComponent } from './edit-multiple-images.component';

describe('EditMultipleImagesComponent', () => {
  let component: EditMultipleImagesComponent;
  let fixture: ComponentFixture<EditMultipleImagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditMultipleImagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditMultipleImagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
