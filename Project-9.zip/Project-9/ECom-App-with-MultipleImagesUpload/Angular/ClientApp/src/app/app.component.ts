import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserIdleService } from 'angular-user-idle';
import { UserService } from './users/services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'ClientApp';

  constructor(private userIdle: UserIdleService, private userService:UserService, private router:Router){
    let user:any = JSON.parse(localStorage.getItem('userDetails') || '{}');
    let userID:number = +user.userID;
    if(userID){
      this.userService.getLoggedInUser(userID).subscribe((res:any) => {
        console.log("Checking the data after user is refreshed the browser", res);
        this.userService.currentUser.role = res.role;
        this.userService.currentUser.lastLogin = res.lastLogin;
        this.userService.currentUser.userName = res.userName;
        this.userService.currentUser.village = res.village;
        this.userService.currentUser.mandal = res.mandal;
        this.userService.currentUser.district = res.district;
        this.userService.currentUser.email = res.email;
        this.userService.currentUser.userID = res.userID;
      })
    }else{
      this.logout();
    }

  }

  ngOnInit() {
     //Start watching for user inactivity.
     this.userIdle.startWatching();
    
     // Start watching when user idle is starting.
     this.userIdle.onTimerStart().subscribe(count => 
       console.log(count)
     );
     
     // Start watch when time is up.
     this.userIdle.onTimeout().subscribe(() => {
       console.log('Time is up!');
       this.userIdle.stopTimer();
       this.userIdle.startWatching();
      // this.userIdle.resetTimer();
      this.logout()

      //  if(this.userService.currentUser.userID != ""){
      //   this.logout()
      //  };
      });
  }

  public logout(){
    localStorage.removeItem('token');
    localStorage.removeItem('userDetails');
    this.userService.currentUser.district = "";
    this.userService.currentUser.email= "";
    this.userService.currentUser.isSuccess = "";
    this.userService.currentUser.lastLogin = "";
    this.userService.currentUser.mandal = "";
    this.userService.currentUser.message = "";
    this.userService.currentUser.password = "";
    this.userService.currentUser.role = "";
    this.userService.currentUser.token = "";
    this.userService.currentUser.userID = "";
    this.userService.currentUser.userName = "";
    this.userService.currentUser.village = "";
    this.router.navigateByUrl('/users/login');

  }
  // npm i angular-user-idle
  // stop() {
  //   this.userIdle.stopTimer();
  // }

  // stopWatching() {
  //   this.userIdle.stopWatching();
  // }

  // startWatching() {
  //   this.userIdle.startWatching();
  // }

  // restart() {
  //   this.userIdle.resetTimer();
  // }
}
