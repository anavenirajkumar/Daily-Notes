﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class Country
    {
        [Key]
        public int CountryId { get; set; }
        public string CountryName { get; set; }
    }

    public class State
    {

        public int StateId { get; set; }
        public string StateName { get; set; }

        public int CountryId { get; set; }
        //public Country Country { get; set; }
    }

    public class City
    {
        public int CityId { get; set; }
        public string CityName { get; set; }

        public int StateId { get; set; }
    }
    public class Mandal
    {
        public int MandalId { get; set; }
        public string MandalName { get; set; }

        public int CityId { get; set; }
        //public City City { get; set; }
    }

    public class Village
    {
        public int VillageId { get; set; }
        public string VillageName { get; set; }
        public int MandalId { get; set; }

        //public Mandal Mandal { get; set; }
    }
}
