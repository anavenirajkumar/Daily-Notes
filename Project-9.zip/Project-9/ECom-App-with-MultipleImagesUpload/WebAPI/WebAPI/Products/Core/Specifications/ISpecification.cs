﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace WebAPI.Core.Specifications
{
    public interface ISpecification<T>
    {
        Expression<Func<T, bool>> Criteria { get; }
        List<Expression<Func<T, object>>> Includes { get; }
        Expression<Func<T, object>> OrderBy { get; } // for Products  Assending List wise -> like a,b,c
        Expression<Func<T, object>> OrderByDescending { get; } // for Products  Dessending List wise -> like c,b,a

        int Take { get; } // for Pagination
        int Skip { get; } // for Pagination
        bool IsPagingEnabled { get; } // for Pagination
    }
}
