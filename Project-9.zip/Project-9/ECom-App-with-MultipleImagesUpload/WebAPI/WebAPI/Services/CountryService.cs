﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Services
{
    public class CountryService : ICountry
    {
        public readonly IConfiguration _configuration;
        public readonly SqlConnection _SqlConnection;

        string connectionString = "Server=SBSLPT-34; Initial Catalog=MiniProject; user id=sa; password=sql@123;";


        public CountryService(IConfiguration configuration)
        {
            _configuration = configuration;
            _SqlConnection = new SqlConnection(_configuration["ConnectionStrings:SqlConnection"]);

        }
        // Create Country
        public async Task<CountryResponce> Country(Country country)
        {
            CountryResponce responce = new CountryResponce();
            responce.Message = "Country Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO Country (CountryName) Values (@CountryName);";
                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@CountryName", country.CountryName);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "Country Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }

        public async Task<StateResponce> State(State state)
        {
            int CountryId = state.CountryId;

            StateResponce responce = new StateResponce();
            responce.Message = "State Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                //string SqlQuery = @"UPDATE State SET StateName = @StateName, CountryId = @CountryId WHERE CountryId = @CountryId;";

                string SqlQuery = @"INSERT INTO State (StateName, CountryId) Values (@StateName, @CountryId);";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@StateName", state.StateName);
                    sqlCommand.Parameters.AddWithValue("@CountryId", CountryId);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "Country Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }
        public async Task<CityResponce> City(City city)
        {
            int StateId = city.StateId;

            CityResponce responce = new CityResponce();

            responce.Message = "City Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO City (CityName, StateId) Values (@CityName, @StateId);";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@StateId", StateId);
                    sqlCommand.Parameters.AddWithValue("@CityName", city.CityName);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "City Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }

        public async Task<MandalResponce> Mandal(Mandal mandal)
        {
            int CityId = mandal.CityId;

            MandalResponce responce = new MandalResponce();

            responce.Message = "Mandal Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO Mandal (MandalName, CityId) Values (@MandalName, @CityId);";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@CityId", CityId);
                    sqlCommand.Parameters.AddWithValue("@MandalName", mandal.MandalName);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "Mandal Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }

        public async Task<VillageResponce> Village(Village village)
        {
            int MandalId = village.MandalId;

            VillageResponce responce = new VillageResponce();

            responce.Message = "Village Created Successfully";
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }
                string SqlQuery = @"INSERT INTO Village (VillageName, MandalId) Values (@VillageName, @MandalId);";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {

                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    sqlCommand.Parameters.AddWithValue("@MandalId", MandalId);
                    sqlCommand.Parameters.AddWithValue("@VillageName", village.VillageName);
                    int status = await sqlCommand.ExecuteNonQueryAsync();
                    if (status <= 0)
                    {
                        responce.Message = "Village Creation Failed";
                        return responce;
                    }

                }

            }
            catch (Exception ex)
            {
                responce.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }
            return responce;
        }


        public async Task<CountryResponce> GetCountries()
        {
            CountryResponce response = new CountryResponce();
            //response. = true;
            response.Message = "Get Countries Data SuccessFully";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                string SqlQuery = @"SELECT * FROM Country";

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Countries = new List<GetCountries>();

                            while (await dataReader.ReadAsync())
                            {
                                GetCountries data = new GetCountries();

                                data.CountryId = Convert.ToInt32(dataReader["CountryId"]);
                                data.CountryName = dataReader["CountryName"].ToString();
                                /*  data.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                  data.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                                  data.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                  data.IsActive = dataReader["IsActive"] != DBNull.Value ? Convert.ToBoolean(dataReader["IsActive"]) : false;
  */
                                response.Countries.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }
        public async Task<StateResponce> CountryId(int CountryID)
        {
            int CountryId = CountryID;
            StateResponce response = new StateResponce();
            //response. = true;
            response.Message = "Get States Data SuccessFully";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                //string SqlQuery = @"select st.StateName from Country c left join State as st on where c.@CountryID = st.CountryId";
                //string SqlQuery = @" SELECT P.*,C.* FROM States AS P INNER JOIN Country AS C ON P.CountryId = C.CountryId";
                /* select c.CountryName, st.StateName from country c

         left join state as st on(c.CountryId = st.CountryId)  where c.CountryId = 1*/
                var SqlQuery = "SELECT C.*,P.* FROM Country AS P INNER JOIN State AS C ON (P.CountryId = C.CountryId) where P.CountryId = " + CountryID; // if pass 1 GET Proper Data

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.States = new List<GetStates>();

                            while (await dataReader.ReadAsync())
                            {
                                GetStates data = new GetStates();

                                data.StateId = Convert.ToInt32(dataReader["StateId"]);
                                data.StateName = dataReader["StateName"].ToString();
                                data.CountryId = Convert.ToInt32(dataReader["CountryId"]);

                                /*  data.MobileNumber = dataReader["MobileNumber"] != DBNull.Value ? Convert.ToString(dataReader["MobileNumber"]) : string.Empty;
                                  data.Salary = dataReader["Salary"] != DBNull.Value ? Convert.ToString(dataReader["Salary"]) : string.Empty;
                                  data.Gender = dataReader["Gender"] != DBNull.Value ? Convert.ToString(dataReader["Gender"]) : string.Empty;
                                  data.IsActive = dataReader["IsActive"] != DBNull.Value ? Convert.ToBoolean(dataReader["IsActive"]) : false;
  */
                                response.States.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<CityResponce> StateId(int StateId)
        {
            CityResponce response = new CityResponce();
            //response. = true;
            response.Message = "Get Cities Data SuccessFully";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                var SqlQuery = "SELECT C.*,P.* FROM State AS P INNER JOIN City AS C ON (P.StateId = C.StateId) where P.StateId = " + StateId; // if pass 1 GET Proper Data

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Cities = new List<Cities>();

                            while (await dataReader.ReadAsync())
                            {
                                Cities data = new Cities();

                                data.CityId = Convert.ToInt32(dataReader["CityId"]);
                                data.CityName = dataReader["CityName"].ToString();
                                data.StateId = Convert.ToInt32(dataReader["StateId"]);
                                response.Cities.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<MandalResponce> CityId(int CityId)
        {
            MandalResponce response = new MandalResponce();
            //response. = true;
            response.Message = "Get Mandals Data SuccessFully";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                var SqlQuery = "SELECT C.*,P.* FROM City AS P INNER JOIN Mandal AS C ON (P.CityId = C.CityId) where P.CityId = " + CityId; // if pass 1 GET Proper Data

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Mandals = new List<Mandals>();

                            while (await dataReader.ReadAsync())
                            {
                                Mandals data = new Mandals();

                                data.MandalId = Convert.ToInt32(dataReader["MandalId"]);
                                data.MandalName = dataReader["MandalName"].ToString();
                                data.CityId = Convert.ToInt32(dataReader["CityId"]);
                                response.Mandals.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }

        public async Task<VillageResponce> MandalId(int MandalId)
        {
            VillageResponce response = new VillageResponce();
            //response. = true;
            response.Message = "Get Villages Data SuccessFully";
            // GetInformation userResponce = new GetInformation();
            try
            {
                if (_SqlConnection.State != System.Data.ConnectionState.Open)
                {
                    await _SqlConnection.OpenAsync();
                }

                var SqlQuery = "SELECT C.*,P.* FROM Mandal AS P INNER JOIN Village AS C ON (P.MandalId = C.MandalId) where P.MandalId = " + MandalId; // if pass 1 GET Proper Data

                using (SqlCommand sqlCommand = new SqlCommand(SqlQuery, _SqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.CommandTimeout = 180;
                    using (DbDataReader dataReader = await sqlCommand.ExecuteReaderAsync())
                    {
                        if (dataReader.HasRows)
                        {
                            response.Villages = new List<Villages>();

                            while (await dataReader.ReadAsync())
                            {
                                Villages data = new Villages();

                                data.VillageId = Convert.ToInt32(dataReader["VillageId"]);
                                data.VillageName = dataReader["VillageName"].ToString();
                                data.MandalId = Convert.ToInt32(dataReader["MandalId"]);
                                response.Villages.Add(data);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }
            finally
            {
                await _SqlConnection.CloseAsync();
                await _SqlConnection.DisposeAsync();
            }

            return response;
        }
    }

}
