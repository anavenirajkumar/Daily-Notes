﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;
using OfficeOpenXml;
using OfficeOpenXml.Core.ExcelPackage;

namespace WebAPI.Interfaces
{
    public interface IUser
    {
        public Task<RegisterUserResponse> RegisterUser(RegisterUserRequest request);
        public Task<UserLoginResponse> UserLogin(UserLoginRequest request);
        public Task<GetInfoByEmail> GetLoggedUser(int userId);
        public Task<UserAddressResponce> UserDetails(UserLoginResponse user);
        public Task<AddInformationResponse> AddInformation(AddInformationRequest request);
        public Task<GetInformationResponse> GetInformation();
        public Task<GetInformation> GetUserInfo(int id);
        public Task<UpdateUserInformation> UpdateUserInformation(UpdateUserInformation updateUser);

         // for User Multiple Images Upload
        public Task<AddUser> AddUser(AddUser request);
        public Task<GetUsers> GetUsers();
        public Task<GetUser> GetUserById(int id);
        public Task<AddUser> UpdateUser(AddUser request);
        public Task<UserAddressResponce> DeleteUserById(int id);

        public Task<bool> DeleteSpecificImage(int id);

        // for only upload multiple images
        public Task<ImageUser> UploadImages(ImageUser request);


        // 
        public Task<AddNewUserRequest> AddNewUserRequest(AddNewUserRequest request);
        Task<IEnumerable<GetNewUsers>> GetNewUsers();
        Task<GetNewUsers> GetNewUserById(int UserId);
        public Task<AddNewUserRequest> UpdateNewUserRequest(AddNewUserRequest request);
        public Task<bool> DeleteNewUserById(int id);
        public Task<bool> DeleteUserImage(int id);
        public Task<UpdateUserImages> UpdateImages(UpdateUserImages request);

        // Logout User && LastLagin
        public Task<string> LogoutUser(UserLoginResponse user, string token);

        // Xml Download
        public Task<OfficeOpenXml.ExcelPackage> GetUsersXMLFile();

    }
}
