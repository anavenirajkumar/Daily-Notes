﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Models;

namespace WebAPI.Interfaces
{
    public interface ICountry
    {
        public Task<CountryResponce> Country(Country country);
        public Task<StateResponce> State(State state);
        public Task<CityResponce> City(City city);
        public Task<MandalResponce> Mandal(Mandal mandal);
        public Task<VillageResponce> Village(Village village);

        // Get Data
        public Task<CountryResponce> GetCountries();
        public Task<StateResponce> CountryId(int CountryID);
        public Task<CityResponce> StateId(int StateId);
        public Task<MandalResponce> CityId(int CityId);
        public Task<VillageResponce> MandalId(int MandalId);
    }
}
