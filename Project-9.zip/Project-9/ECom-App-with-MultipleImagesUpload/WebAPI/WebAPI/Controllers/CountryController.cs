﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebAPI.Interfaces;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        public readonly ICountry _country;
        public CountryController(ICountry country)
        {
            _country = country;
        }

        [HttpPost("AddCountry")]
        [AllowAnonymous]

        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddCountry(Country country) // Get All Users Information
        {
            CountryResponce response = new CountryResponce();
            try
            {
                response = await _country.Country(country);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpPost("AddState")]
        [AllowAnonymous]

        // [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddState(State state) // Get All Users Information
        {
            StateResponce response = new StateResponce();
            try
            {
                response = await _country.State(state);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPost("AddCity")]
        [AllowAnonymous]

        // [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddCity(City city) // Get All Users Information
        {
            CityResponce response = new CityResponce();
            try
            {
                response = await _country.City(city);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPost("AddMandal")]
        [AllowAnonymous]

        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddMandal(Mandal mandal) // Get All Users Information
        {
            MandalResponce response = new MandalResponce();
            try
            {
                response = await _country.Mandal(mandal);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpPost("AddVillage")]
        [AllowAnonymous]

        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddVillage(Village village) // Get All Users Information
        {
            VillageResponce response = new VillageResponce();
            try
            {
                response = await _country.Village(village);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpGet("Countries")]
        [AllowAnonymous]

        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetCountries() // Get All Users Information
        {
            CountryResponce response = new CountryResponce();
            try
            {
                response = await _country.GetCountries();
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpGet("States/{id}")]
        [AllowAnonymous]

        // [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetStates(int CountryID) // Get All Users Information
        {
            //var Id = Convert.ToInt32(CountryID);
            StateResponce response = new StateResponce();
            try
            {
                response =  await _country.CountryId(CountryID);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("Cities")]
        [AllowAnonymous]
        //[Authorize(Roles = "Admin")]

        public async Task<IActionResult> GetCities(int StateID) // Get All Users Information
        {
            //var Id = Convert.ToInt32(CountryID);
            CityResponce response = new CityResponce();
            try
            {
                response =  await _country.StateId(StateID);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }


        [HttpGet("Mandals")]
        [AllowAnonymous]
        //[Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetMandal(int CityID) // Get All Users Information
        {
            //var Id = Convert.ToInt32(CountryID);
            MandalResponce response = new MandalResponce();
            try
            {
                response =  await _country.CityId(CityID);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }

        [HttpGet("Villages")]
        [AllowAnonymous]
        //[Authorize(Roles = "Admin")]

        public async Task<IActionResult> GetVillages(int VillageID) // Get All Users Information
        {
            //var Id = Convert.ToInt32(CountryID);
            VillageResponce response = new VillageResponce();
            try
            {
                response =  await _country.MandalId(VillageID);
            }
            catch (Exception ex)
            {
                //response.IsSuccess = false;
                response.Message = ex.Message;
            }

            return Ok(response);
        }
    }
}
