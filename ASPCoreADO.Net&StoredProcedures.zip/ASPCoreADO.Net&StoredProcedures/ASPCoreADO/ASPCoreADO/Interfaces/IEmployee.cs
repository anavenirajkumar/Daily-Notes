﻿using ASPCoreADO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCoreADO.Interfaces
{
    interface IEmployee
    {
        Task<List<Employee>> GetAllEmployees();
        Task<Employee> GetEmployeeByID(int id);
        Task<Employee> AddEmployee(Employee emp);
        Task<Employee> EditEmployee(Employee emp);
        Task<int> DeleteEmployee(int id);
    }
}
