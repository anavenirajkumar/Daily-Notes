﻿using ASPCoreADO.Interfaces;
using ASPCoreADO.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCoreADO.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        EmpDAL _customerRep = new EmpDAL();

        // GET api/values
        [HttpGet]
        public async Task<List<Employee>> GetAllEmployees()
        {
            return await _customerRep.GetAllEmployees();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetEmployeeByID(int id)
        {
            return await _customerRep.GetEmployeeByID(id);
        }

        [HttpPost]
        public async Task<ActionResult<Employee>> AddEmployee([FromBody] Employee customer)
        {
            if (customer == null || !ModelState.IsValid)
            {
                return BadRequest("Invalid State");
            }

            return await _customerRep.AddEmployee(customer);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<Employee>> EditEmployee([FromBody] Employee customer)
        {
            if (customer == null || !ModelState.IsValid)
            {
                return BadRequest("Invalid State");
            }

            return await _customerRep.EditEmployee(customer);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<int>> DeleteEmployee(int id)
        {
            return await _customerRep.DeleteEmployee(id);
        }


    }
}
