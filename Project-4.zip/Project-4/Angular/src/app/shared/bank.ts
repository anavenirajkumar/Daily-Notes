export interface IBank {
    bankAccountID : number | any,
    accountNumber: string,
    accountHolder: string,
    bankID: number | any
    IFSC:string
}